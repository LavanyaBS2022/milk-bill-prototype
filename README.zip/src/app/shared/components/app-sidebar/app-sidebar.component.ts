import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebarss',
  templateUrl: './app-sidebar.component.html'
})
export class AppSidebarComponent { }
