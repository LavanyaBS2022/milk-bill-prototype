import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardService } from '../../shared/service/guard/auth-guard.service';

// Import Containers 
import {
    AdminLayoutComponent,
    FullLayoutComponent,
    SimpleLayoutComponent
} from '../../containers';

import { AccessMappingComponent } from './rbac/access-mapping/access-mapping.component';
import { AddUserComponent } from './user/add-user/add-user.component';
import { ListUserComponent } from './user/list-user/list-user.component';
import { EditUserComponent } from './user/edit-user/edit-user.component';
const routes: Routes = [
    {
        path: 'access-mapping',
        component: AccessMappingComponent,
        data: {
          title: 'RBAC Access Mapping',
          permission : ''
        },
        // canActivate: [AuthGuardService]
    },
    {
        path: 'add-user',
        component: AddUserComponent,
        data: {
          title: 'User Add',
          module: 'rbac',
          permission : 'addUser'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'edit-user',
        component: EditUserComponent,
        data: {
          title: 'User Edit',
          module: 'rbac',
          permission : 'editUser'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'list-user',
        component: ListUserComponent,
        data: {
          title: 'User List',
          module: 'rbac',
          permission : 'listUser'
        },
        canActivate: [AuthGuardService]
    },
];

@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ],
    exports: [
        RouterModule
    ]
})

export class UsersRoutingModule { }
