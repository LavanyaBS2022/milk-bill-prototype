import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormArray, Validators, FormBuilder, FormGroupDirective, NgForm, ValidatorFn, ValidationErrors } from '@angular/forms';
import { Common } from '../../../../shared/service/common/common';
import { RbacRolesService } from '../../../../shared/service/users/rbac/rbac-roles.service';
import { UsersService } from '../../../../shared/service/users/user/users.service';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-add-user',
    templateUrl: './add-user.component.html',
    styleUrls: ['./add-user.component.scss']
})

export class AddUserComponent implements OnInit {
    private submitted: boolean = true;
    private isSubmit: boolean = false;
    public usersForm: FormGroup;
    public userType;
    private roles = [];
    public franchiseList = [];
    public showFranchise: boolean = false;
    private showCustomers: boolean = false;
    // public franchiseId;
    constructor(
        public common: Common,
        private rbacRolesService: RbacRolesService,
        private usersService: UsersService,
        public formBuilder: FormBuilder,
        private mastersService: MastersService,
        private router: Router
    ) { }

    ngOnInit() {
        this.createUsersForm();
        this.getRoles();
        let obj = {};
        this.usersService.listUsers(obj).subscribe(data => {
            // console.log('received data',data);
            //this.common.openSnackBar('User Added Successfully', '', 'success-snackbar');
            this.resetPage();
        },
            sError => {
                this.common.apiError(sError);
            });
    }

    get formData() {
        return this.usersForm.controls;
    }

    // initialize the Filter Form
    public createUsersForm() {
        this.usersForm = new FormGroup({
            firstName: new FormControl('', [Validators.required]),
            lastName: new FormControl('', Validators.required),
            email: new FormControl('', [Validators.required, Validators.email]),
            password: new FormControl('', Validators.required),
            confirmPassword: new FormControl('', [Validators.required]),
            mobile: new FormControl('', []),
            roleId: new FormControl('', [Validators.required]),
            franchiseId: new FormControl('', []),
            //salesCustomerIds: new FormControl('', [])
        });
    }

    // to get All the Roles
    public getRoles() {
        this.rbacRolesService.getRoles().subscribe(data => {
            // console.log('roles data',data);
            if (data.data != false) {
                this.roles = data.data;
            }
        },
            sError => {
                // console.log("Project Error",sError);
            });
    }

    checkPasswords(group: FormGroup) { // here we have the 'passwords' group
        let pass = group.controls.password.value;
        let confirmPass = group.controls.confirmPassword.value;
        // console.log('I have reached here');
        return pass === confirmPass ? null : { notSame: true }
    }

    public onSubmit() {
        this.submitted = true;

        if (this.usersForm.valid) {
            // if user has selected franchise they pass user type as 2
            let type;
            let franchiseType = "";
            if (this.userType == 'Customer') {
                type = 2;
                franchiseType = "Secondary User";
            }
            else if (this.userType == 'RBAC') {
                type = 1
                franchiseType = "Primary User";
            }
            else {
                type = 1
                franchiseType = "Primary User";
            }
            let usersData = this.usersForm.value;

            let obj = {
                firstName: usersData.firstName,
                lastName: usersData.lastName,
                email: usersData.email,
                password: usersData.password,
                confirmPassword: usersData.confirmPassword,
                mobile: usersData.mobile,
                roleId: usersData.roleId,
                franchiseId: usersData.franchiseId,
                user_type: type,
                franchise_type: franchiseType,
                //sales_customer: usersData.salesCustomerIds
            };

            // let usersData = this.usersForm.value;
            if (usersData.password != usersData.confirmPassword) {
                this.common.openSnackBar('Password and Confirm Password does not match', '', 'danger-snackbar')
            }
            else {
                console.log(obj);

                // usersService
                this.usersService.addUsers(obj).subscribe(data => {
                    // console.log('data',data);
                    this.common.openSnackBar('User Added Successfully', '', 'success-snackbar');
                    this.router.navigateByUrl("/users/list-user");

                    // this.resetPage();
                },
                    sError => {
                        this.common.apiError(sError);
                    });
            }
            console.log('usersData', usersData);
        }

    }

    public resetPage() {

        this.usersForm.reset();
    }

    public getFranchiseList(userType) {
        //save selected user time value for future use
        console.log(userType);
        
        this.userType = userType;
        //   this.selectedRole = userType;
        if (this.userType == 'Customer') {
            this.showCustomers = false;
            this.showFranchise = true;
            this.usersForm.controls["franchiseId"].setValidators(Validators.required);

            this.mastersService.getlistFranchise().subscribe(
                sResponseModel => {
                    // console.log('franchiseList', sResponseModel);
                    if (sResponseModel.data != false) {
                        this.franchiseList = sResponseModel.data;
                    }
                },
                sError => {
                    this.common.apiError(sError);
                }
            );
        } else if (this.userType == 'Sales') {
            this.showFranchise = false;
            //this.getSalesList();
        }
        else {
            this.usersForm.controls["franchiseId"].clearValidators();
            this.showFranchise = false;
            this.usersForm.patchValue({
                franchiseId: ''
            })
        }
    }

    public getSalesList() {
        if (this.userType == 'Sales') {

            this.showCustomers = true;
            this.usersForm.controls["salesCustomerIds"].setValidators(Validators.required);
            this.mastersService.getlistFranchise().subscribe(
                sResponseModel => {
                    // console.log('franchiseList', sResponseModel);
                    if (sResponseModel.data != false) {
                        this.franchiseList = sResponseModel.data;
                    }
                },
                sError => {
                    this.common.apiError(sError);
                }
            );
        }
        else {
            this.usersForm.controls["salesCustomerIds"].clearValidators();
            this.showCustomers = false;
            this.usersForm.patchValue({
                salesCustomerIds: []
            })
        }
    }
}
