import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AngularMaterialModule } from "../../angular.material.module";
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';

import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material';
import { MatSortModule } from '@angular/material/sort';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';


import { ReportsRoutingModule } from './reports-routing.module';
import { BrandAnalysisComponent } from './brand-analysis/brand-analysis/brand-analysis.component';
import { ReportFilterComponent } from './report-filter/report-filter.component';
import { Category1AnalysisComponent } from './category1-analysis/category1-analysis.component';
import { Category4AnalysisComponent } from './category4-analysis/category4-analysis.component';
import { GenderAnalysisComponent } from './gender-analysis/gender-analysis.component';
import { SiloAnalysisComponent } from './silo-analysis/silo-analysis.component';
import { OrderCategoryComponent } from './order-category/order-category.component';
import { OrderLaunchMonthComponent } from './order-launch-month/order-launch-month.component';

@NgModule({
  imports: [
    CommonModule,
    AngularMaterialModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    SharedModule,
    ReportsRoutingModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatFormFieldModule,
    MatInputModule
  ],
  declarations: [
    BrandAnalysisComponent,
    ReportFilterComponent,
    Category1AnalysisComponent,
    Category4AnalysisComponent,
    GenderAnalysisComponent,
    SiloAnalysisComponent,
    OrderCategoryComponent,
    OrderLaunchMonthComponent
  ]
})
export class ReportsModule { }
