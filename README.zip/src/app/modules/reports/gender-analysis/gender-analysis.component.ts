import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from "@angular/router";
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from "@angular/material";
import { ReportsService } from "../../../shared/service/reports/reports.service";
import { Common } from './../../../shared/service/common/common';

@Component({
  selector: 'app-gender-analysis',
  templateUrl: './gender-analysis.component.html',
  styleUrls: ['./gender-analysis.component.scss']
})
export class GenderAnalysisComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  public genderAnalysis_datasource = new MatTableDataSource();
  genderAnalysisDisplayedColumns: string[] = ['gender', 'totalqty', 'totalamount','estimated_USD','estimated_SGD'];

  public seasonId: any;
  public userDetails: any;

  constructor(public reportService: ReportsService, public router: Router, public common: Common) {
    this.userDetails = this.common.getUserDetails();
    this.seasonId = this.userDetails.activeSeason;
  }

  ngOnInit() {
    this.getGenderAnalysis();
  }

  applyFilter(filterValue: string) {
    this.genderAnalysis_datasource.filter = filterValue.trim().toLowerCase();
    // console.log('this.genderAnalysis_datasource.filter:', this.genderAnalysis_datasource);
  }

  public getGenderAnalysis() {
    this.reportService.getGenderAnalysis(this.seasonId).subscribe(
      sResponseModel => {
        // console.log('Gender Analysis Data:', sResponseModel.data);
        if (sResponseModel.data) {
          this.genderAnalysis_datasource.data = sResponseModel.data;
          this.genderAnalysis_datasource.paginator = this.paginator;
        }
      }, sError => {
        this.common.apiError(sError);
      }
    );
  }

}
