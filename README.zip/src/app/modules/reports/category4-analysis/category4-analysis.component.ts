import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from "@angular/router";
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from "@angular/material";
import { ReportsService } from "../../../shared/service/reports/reports.service";
import { Common } from './../../../shared/service/common/common';

@Component({
  selector: 'app-category4-analysis',
  templateUrl: './category4-analysis.component.html',
  styleUrls: ['./category4-analysis.component.scss']
})
export class Category4AnalysisComponent implements OnInit {

  public seasonId: any;
  public userDetails: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  public category4Analysis_datasource = new MatTableDataSource();
  category4AnalysisDisplayedColumns: string[] = ['category4', 'totalqty', 'totalamount','estimated_USD','estimated_SGD'];

  constructor(public reportService: ReportsService, public router: Router, public common: Common) {
    this.userDetails = this.common.getUserDetails();
    this.seasonId = this.userDetails.activeSeason;
  }

  ngOnInit() {
    this.getCategory4Analysis();
  }

  applyFilter(filterValue: string) {
    this.category4Analysis_datasource.filter = filterValue.trim().toLowerCase();
  }

  public getCategory4Analysis() {
    this.reportService.getCategory4Analysis(this.seasonId).subscribe(
      sResponseModel => {
        // console.log('Category4 Analysis Data:', sResponseModel.data);
        if (sResponseModel.data) {
          this.category4Analysis_datasource.data = sResponseModel.data;
          this.category4Analysis_datasource.paginator = this.paginator;
        }
      }, sError => {
        this.common.apiError(sError);
      }
    );
  }

}
