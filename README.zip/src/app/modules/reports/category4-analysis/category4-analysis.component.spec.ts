import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Category4AnalysisComponent } from './category4-analysis.component';

describe('Category4AnalysisComponent', () => {
  let component: Category4AnalysisComponent;
  let fixture: ComponentFixture<Category4AnalysisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Category4AnalysisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Category4AnalysisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
