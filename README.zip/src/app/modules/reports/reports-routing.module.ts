import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from "../../shared/service/guard/auth-guard.service";

import { AdminLayoutComponent, FullLayoutComponent, SimpleLayoutComponent } from "../../containers";
import { CanActivate } from "@angular/router/src/utils/preactivation";

import { BrandAnalysisComponent } from "./brand-analysis/brand-analysis/brand-analysis.component";
import { Category1AnalysisComponent } from './category1-analysis/category1-analysis.component';
import { Category4AnalysisComponent } from './category4-analysis/category4-analysis.component';
import { GenderAnalysisComponent } from './gender-analysis/gender-analysis.component';
import { SiloAnalysisComponent } from './silo-analysis/silo-analysis.component';
import { OrderCategoryComponent } from './order-category/order-category.component';
import { OrderLaunchMonthComponent } from './order-launch-month/order-launch-month.component';

const routes: Routes = [
  {
    path: 'reportBrandAnalysis',
    component: BrandAnalysisComponent,
    data: {
      title: 'Brand Analysis',
      module: 'Reports',
      permission: 'reportBrandAnalysis'
    },
    // canActivate: [AuthGuardService]
  },
  {
    path: 'reportCategory1Analysis',
    component: Category1AnalysisComponent,
    data: {
      title: 'Category1 Analysis',
      module: 'Reports',
      permission: 'reportCategory1Analysis'
    },
    // canActivate: [AuthGuardService]
  },
  {
    path: 'reportCategory4Analysis',
    component: Category4AnalysisComponent,
    data: {
      title: 'Category4 Analysis',
      module: 'Reports',
      permission: 'reportCategory4Analysis'
    },
    // canActivate: [AuthGuardService]
  },
  {
    path: 'reportGenderAnalysis',
    component: GenderAnalysisComponent,
    data: {
      title: 'Gender Analysis',
      module: 'Reports',
      permission: 'reportGenderAnalysis'
    },
    // canActivate: [AuthGuardService]
  },
  {
    path: 'reportSiloAnalysis',
    component: SiloAnalysisComponent,
    data: {
      title: 'Silo Analysis',
      module: 'Reports',
      permission: 'reportSiloAnalysis'
    },
    canActivate: [AuthGuardService]
  },
  {
    path: 'orderByCategory',
    component: OrderCategoryComponent,
    data: {
      title: 'Order By Category',
      module: 'Reports',
      permission: 'orderByCategory'
    },
    //  canActivate: [AuthGuardService]
  },

  {
    path: 'orderByLaunchMonth',
    component: OrderLaunchMonthComponent,
    data: {
      title: 'Order By Category',
      module: 'Reports',
      permission: 'orderByCategory'
    },
    //  canActivate: [AuthGuardService]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
