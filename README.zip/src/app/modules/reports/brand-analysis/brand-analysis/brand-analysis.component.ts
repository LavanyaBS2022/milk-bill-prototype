import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from "@angular/router";
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from "@angular/material";
import { ReportsService } from "../../../../shared/service/reports/reports.service";
import { Common } from './../../../../shared/service/common/common';

@Component({
  selector: 'app-brand-analysis',
  templateUrl: './brand-analysis.component.html',
  styleUrls: ['./brand-analysis.component.scss']
})
export class BrandAnalysisComponent implements OnInit {
  public seasonId: any;
  public userDetails: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  public brandAnalysis_datasource = new MatTableDataSource();
  brandAnalysisDisplayedColumns: string[] = ['brand', 'totalqty', 'totalamount','estimated_USD','estimated_SGD'];

  constructor(public reportService: ReportsService, public router: Router, public common: Common) {
    this.userDetails = this.common.getUserDetails();
    this.seasonId = this.userDetails.activeSeason;
  }

  ngOnInit() {
    this.getBrandAnalysis();
  }

  applyFilter(filterValue: string) {
    this.brandAnalysis_datasource.filter = filterValue.trim().toLowerCase();
  }

  public getBrandAnalysis() {
    this.reportService.getBrandAnalysis(this.seasonId).subscribe(
      sResponseModel => {
        // console.log('Brand Analysis Data:', sResponseModel.data);
        if (sResponseModel.data) {
          this.brandAnalysis_datasource.data = sResponseModel.data;
          this.brandAnalysis_datasource.paginator = this.paginator;
        }
      }, sError => {
        this.common.apiError(sError);
      }
    );
  }

}
