import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { ReportsService } from "../../../shared/service/reports/reports.service";
import { Common } from './../../../shared/service/common/common';

@Component({
  selector: 'app-report-filter',
  templateUrl: './report-filter.component.html',
  styleUrls: ['./report-filter.component.scss']
})
export class ReportFilterComponent implements OnInit {
  public text: any = 'Show Filter';
  public changeText(): void {
    if (this.text === 'Collapse Filter') {
      this.text = 'Show Filter';
    } else {
      this.text = 'Collapse Filter';
    }
  }
  step = 0;
  setStep(index: number) {
    this.step = index;
  }
  nextStep() {
    this.step++;
  }
  prevStep() {
    this.step--;
  }

  @Input('xpandStatus') xpandStatus: boolean = false;
  @Input('brandFilter') brandFilter: boolean = false;
  @Input('divisionFilter') divisionFilter: boolean = false;
  @Input('genderFilter') genderFilter: boolean = false;
  @Input('category1Filter') category1Filter: boolean = false;
  @Input('category4Filter') category4Filter: boolean = false;
  @Input('siloFilter') siloFilter: boolean = false;
  @Input('seasonFilter') seasonFilter: boolean = false;

  @Output() search = new EventEmitter<object>();
  @Output() clear = new EventEmitter<object>();

  public reportFilterForm: FormGroup;

  public brand: string[];
  public division = [];
  public gender = [];
  public category1 = [];
  public category4 = [];
  public silo = [];
  public season = [];

  constructor(public reportService: ReportsService, public router: Router, public common: Common) { }

  ngOnInit() {
    this.generateReportFilterFrom();
    this.patchReportFilterForm();

    this.brandFilter ? this.getBrand() : '';
    this.divisionFilter ? this.getDivision() : '';
    this.genderFilter ? this.getGender() : '';
    this.category1Filter ? this.getCategory1() : '';
    this.category4Filter ? this.getCategory4() : '';
    // this.siloFilter ? this.getSilo() : '';
    // this.seasonFilter ? this.getSeason() : '';
  }

  public generateReportFilterFrom() {
    this.reportFilterForm = new FormGroup({
      brand: new FormControl('', Validators.required),
      division: new FormControl('', Validators.required),
      gender: new FormControl('', Validators.required),
      category1: new FormControl('', Validators.required),
      category4: new FormControl('', Validators.required),
      silo: new FormControl('', Validators.required),
      season: new FormControl('', Validators.required)
    });
  }

  public patchReportFilterForm() {
    this.reportFilterForm.patchValue({
      brand: '0',
      division: '0',
      gender: '0',
      category1: '0',
      category4: '0',
      silo: '0',
      season: '0'
    });
  }

  public getBrand() {
    this.reportService.getReportFilterMasterData('brand').subscribe(sResponseModel => {
      // console.log('Brand Drop Down Data:', sResponseModel.data);
      if (sResponseModel.data) {
        this.brand = sResponseModel.data;
      }
    },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public getDivision() {
    this.reportService.getReportFilterMasterData('division').subscribe(sResponseModel => {
      // console.log('Division Drop Down Data:', sResponseModel.data);
      if (sResponseModel.data) {
        this.division = sResponseModel.data;
      }
    },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public getGender() {
    this.reportService.getReportFilterMasterData('gender').subscribe(sResponseModel => {
      // console.log('Gender Drop Down Data:', sResponseModel.data);
      if (sResponseModel.data) {
        this.gender = sResponseModel.data;
      }
    },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public getCategory1() {
    this.reportService.getReportFilterMasterData('category1').subscribe(sResponseModel => {
      // console.log('Category1 Drop Down Data:', sResponseModel.data);
      if (sResponseModel.data) {
        this.category1 = sResponseModel.data;
      }
    },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public getCategory4() {
    this.reportService.getReportFilterMasterData('category4').subscribe(sResponseModel => {
      // console.log('Category4 Drop Down Data:', sResponseModel.data);
      if (sResponseModel.data) {
        this.category4 = sResponseModel.data;
      }
    },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public getSilo() {
    this.reportService.getReportFilterMasterData('silo').subscribe(sResponseModel => {
      // console.log('Silo Drop Down Data:', sResponseModel.data);
      if (sResponseModel.data) {
        this.silo = sResponseModel.data;
      }
    },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public getSeason() {
    this.reportService.getReportFilterMasterData('season').subscribe(sResponseModel => {
      // console.log('Season Drop Down Data:', sResponseModel.data);
      if (sResponseModel.data) {
        this.season = sResponseModel.data;
      }
    },
      sError => {
        this.common.apiError(sError);
      }
    );
  }



  public onSubmit() {
    const orderReportData = JSON.parse(JSON.stringify(this.reportFilterForm.value));
    this.search.emit(orderReportData);
  }

  public clearAll() {
    this.patchReportFilterForm();
  }

}
