import { Component, OnInit, ViewChild } from '@angular/core';
import { ReportsService } from '../../../shared/service/reports/reports.service';
import { Common } from '../../../shared/service/common/common';
import { DatePipe } from '@angular/common';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-order-launch-month',
  templateUrl: './order-launch-month.component.html',
  styleUrls: ['./order-launch-month.component.scss']
})
export class OrderLaunchMonthComponent implements OnInit {
  userDetails: any;
 // @ViewChild(MatPaginator) paginator: MatPaginator;
  public order_datasource = new MatTableDataSource();
  orderDisplayedColumns: string[] = ['countryName', 'customerName', 'totalAmt'];
  constructor(private reportService: ReportsService, private common: Common, private datePipe: DatePipe) {
    this.userDetails = common.getUserDetails();
  }

  ngOnInit() {
    this.getOrderByLaunchMonth();
  }

  getOrderByLaunchMonth() {
    this.reportService.getOrderByLaunch(this.userDetails.activeSeason).subscribe((sResponseModel: any) => {
      if (sResponseModel.data.length > 0) {
        this.order_datasource.data = sResponseModel.data;
      //  this.order_datasource.paginator = this.paginator;
      }
    }, sError => {
      this.common.openSnackBar("Error occcured while loading data", '', 'danger-snackbar')
    })
  }

  onClickExport() {
    const date = this.datePipe.transform(new Date(), 'dd_MMM_yy')
    this.reportService.getOrderLaunchMonthExcel(this.userDetails.activeSeason).subscribe((sResponse: any) => {
      if (sResponse) {
        saveAs(sResponse, 'order_launch_month -' + date + '.xlsx');
      }
    }, sError => {
      this.common.openSnackBar("Error occcured while loading data", '', 'danger-snackbar')
    })

  }
}
