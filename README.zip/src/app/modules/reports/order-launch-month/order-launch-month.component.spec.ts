import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderLaunchMonthComponent } from './order-launch-month.component';

describe('OrderLaunchMonthComponent', () => {
  let component: OrderLaunchMonthComponent;
  let fixture: ComponentFixture<OrderLaunchMonthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderLaunchMonthComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderLaunchMonthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
