import { Component, OnInit, ViewChild } from '@angular/core';
import { ReportsService } from '../../../shared/service/reports/reports.service';
import { Common } from '../../../shared/service/common/common';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { instantiateDefaultStyleNormalizer } from '@angular/platform-browser/animations/src/providers';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { saveAs } from 'file-saver';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-order-category',
  templateUrl: './order-category.component.html',
  styleUrls: ['./order-category.component.scss']
})
export class OrderCategoryComponent implements OnInit {
  division: any[];
  selectedDivision: any;
  reportFilterForm: FormGroup;
  userDetails: any;
  // @ViewChild(MatPaginator) paginator: MatPaginator;
  public order_datasource = new MatTableDataSource();
  orderDisplayedColumns: string[] = ['countryName', 'customerName', 'categoryName', 'totalAmt'];
  public text: any = 'Show Filter';
  constructor(private reportService: ReportsService, private common: Common, private datePipe: DatePipe) {
    this.userDetails = common.getUserDetails();
  }

  ngOnInit() {
    this.getDivision();
    this.initForm()
  }


  public changeText(): void {
    if (this.text === 'Collapse Filter') {
      this.text = 'Show Filter';
    } else {
      this.text = 'Collapse Filter';
    }
  }


  public initForm() {
    this.reportFilterForm = new FormGroup({
      division: new FormControl('', Validators.required),
    });
  }

  onSelectionChange(event) {
    if (event.value) {
      this.selectedDivision = event.value
      //   this.getOrderByCategory();
    }


  }


  public getDivision() {
    this.reportService.getReportFilterMasterData('division').subscribe(sResponseModel => {
      console.log('Division Drop Down Data:', sResponseModel.data);
      if (sResponseModel.data) {
        this.division = sResponseModel.data;
        this.selectedDivision = this.division[0];
        if (this.selectedDivision) {
          this.getOrderByCategory()
        }
      }
    },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  getOrderByCategory() {
    this.reportService.getOrderByCategory(this.userDetails.activeSeason, this.selectedDivision.id).subscribe((sResponseModel: any) => {
      if (sResponseModel.data.length > 0) {
        const flterData = sResponseModel.data.filter((o) => (!o.isTotal));
        this.order_datasource.data = flterData;
        //  this.order_datasource.paginator = this.paginator;
      }
    }, sError => {
      this.common.openSnackBar("Error occcured while loading data", '', 'danger-snackbar')
    })
  }

  onSubmit() {
    this.getOrderByCategory();
  }


  onClickExport() {
    const date = this.datePipe.transform(new Date(), 'dd_MMM_yy')
    this.reportService.getOrderByCategoryExcel(this.userDetails.activeSeason, this.selectedDivision.id, this.selectedDivision.name).subscribe((sResponse: any) => {
      //  const flterData = sResponseModel.data.filter((o) => (!o.isTotal));
      //  this.order_datasource.data = flterData;
      // this.order_datasource.paginator = this.paginator;
      if (sResponse) {
        saveAs(sResponse, this.selectedDivision.name.toUpperCase() + '-' + date + '.xlsx');
      }
    }, sError => {
      this.common.openSnackBar("Error occcured while loading data", '', 'danger-snackbar')
    })

  }









}
