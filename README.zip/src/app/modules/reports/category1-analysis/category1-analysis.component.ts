import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from "@angular/router";
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from "@angular/material";
import { ReportsService } from "../../../shared/service/reports/reports.service";
import { Common } from './../../../shared/service/common/common';

@Component({
  selector: 'app-category1-analysis',
  templateUrl: './category1-analysis.component.html',
  styleUrls: ['./category1-analysis.component.scss']
})
export class Category1AnalysisComponent implements OnInit {

  public seasonId: any;
  public userDetails: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  public category1Analysis_datasource = new MatTableDataSource();
  category1AnalysisDisplayedColumns: string[] = ['category1', 'totalqty', 'totalamount', 'estimated_USD', 'estimated_SGD'];

  constructor(public reportService: ReportsService, public router: Router, public common: Common) {
    this.userDetails = this.common.getUserDetails();
    this.seasonId = this.userDetails.activeSeason;
  }

  ngOnInit() {
    this.getCategory1Analysis();
  }

  applyFilter(filterValue: string) {
    this.category1Analysis_datasource.filter = filterValue.trim().toLowerCase();
  }

  public getCategory1Analysis() {
    this.reportService.getCategory1Analysis(this.seasonId).subscribe(
      sResponseModel => {
        console.log('Category1 Analysis Data:', sResponseModel.data);
        if (sResponseModel.data) {
          this.category1Analysis_datasource.data = sResponseModel.data;
          this.category1Analysis_datasource.paginator = this.paginator;
        }
      }, sError => {
        this.common.apiError(sError);
      }
    );
  }

}
