import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Category1AnalysisComponent } from './category1-analysis.component';

describe('Category1AnalysisComponent', () => {
  let component: Category1AnalysisComponent;
  let fixture: ComponentFixture<Category1AnalysisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Category1AnalysisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Category1AnalysisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
