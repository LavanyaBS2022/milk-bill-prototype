import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-silo-analysis',
  templateUrl: './silo-analysis.component.html',
  styleUrls: ['./silo-analysis.component.scss']
})
export class SiloAnalysisComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
