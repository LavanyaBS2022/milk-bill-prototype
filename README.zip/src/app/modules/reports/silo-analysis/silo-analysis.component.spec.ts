import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiloAnalysisComponent } from './silo-analysis.component';

describe('SiloAnalysisComponent', () => {
  let component: SiloAnalysisComponent;
  let fixture: ComponentFixture<SiloAnalysisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiloAnalysisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiloAnalysisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
