import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListRbuComponent } from './list-rbu.component';

describe('ListRbuComponent', () => {
  let component: ListRbuComponent;
  let fixture: ComponentFixture<ListRbuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListRbuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListRbuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
