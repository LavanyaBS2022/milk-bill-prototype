import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Router } from '@angular/router';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-list-rbu',
  templateUrl: './list-rbu.component.html',
  styleUrls: ['./list-rbu.component.scss']
})
export class ListRbuComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  public rbuList_datasource = new MatTableDataSource();
  rbuDisplayedColumns: string[] = ['SNo', 'name', 'action'];

  constructor(private masterService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService) { }

  ngOnInit() {
    this.getRBUList();
  }

  applyFilter(filterValue: string) {
    this.rbuList_datasource.filter = filterValue.trim().toLowerCase();
  }

  public getRBUList() {
    this.spinner.show();
    this.masterService.getListRBU().subscribe(
      sResponseModel => {
        this.spinner.hide();
        if (sResponseModel.data) {
          this.rbuList_datasource.data = sResponseModel.data;
          this.rbuList_datasource.paginator = this.paginator;
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public editRBU(id) {
    const editId = btoa(id);
    this.router.navigate(['masters/edit-rbu'], { queryParams: { editId } });
  }

  public deleteRBU(rbuId) {
    this.common.openConfirmDialog('Are you sure to delete this Category4 ?')
      .afterClosed().subscribe(res => {
        if (res) {
          let rbuIndex = this.rbuList_datasource.data.findIndex(key => key['id'] == rbuId)
          this.masterService.getDeleteRBU(rbuId).subscribe((data) => {
            if (data.data) {
              this.rbuList_datasource.data.splice(rbuIndex, 1);
              this.rbuList_datasource.data = this.rbuList_datasource.data;
              this.common.openSnackBar('Category4 Deleted Successfully', '', 'success-snackbar');
            }
            else {
              this.common.openSnackBar('Could Not Delete Category4', '', 'danger-snackbar');

            }
          },
          sError => {
            this.common.apiError(sError);
          });
        }
      });
  }

}
