import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditRbuComponent } from './edit-rbu.component';

describe('EditRbuComponent', () => {
  let component: EditRbuComponent;
  let fixture: ComponentFixture<EditRbuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditRbuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditRbuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
