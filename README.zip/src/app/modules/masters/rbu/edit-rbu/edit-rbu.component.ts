import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-edit-rbu',
  templateUrl: './edit-rbu.component.html',
  styleUrls: ['./edit-rbu.component.scss']
})
export class EditRbuComponent implements OnInit {

  public rbuEditForm: FormGroup;
  public editrbuId: any;
  public editRBUData: any;
  public isSubmitted = false;

  constructor(private formBuilder: FormBuilder, public route: ActivatedRoute, public mastersService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService) {
    this.route.queryParams.subscribe(params => {
      this.editrbuId = (atob(params.editId));
      this.getEditRBUData(this.editrbuId);
    });
  }

  ngOnInit() {
    this.rbuEditForm = this.formBuilder.group({
      rbuName: ['', [Validators.required, Validators.maxLength(50)]]
    });
  }

  public get get() {
    return this.rbuEditForm.controls;
  }

  getEditRBUData(editId: any) {
    this.mastersService.getListRBUbyId(editId).subscribe((data) => {
      this.editRBUData = data.data;
      this.rbuEditForm.patchValue({
        rbuName: this.editRBUData[0].name
      });
    },
    sError => {
      this.common.apiError(sError);
    });
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.rbuEditForm.get("rbuName").value.trim() == "") {
      this.common.openSnackBar('Please fill all the mandatory fields','', 'danger-snackbar');
      return 
      // this.rbuEditForm.controls["rbuName"].setErrors({ emptyValidateError: "Category4 Name cannot be empty." });
    }

    if (this.rbuEditForm.valid && this.rbuEditForm.get("rbuName").value.trim() != "") {
      this.spinner.show();
      this.rbuEditForm.value['rbuId'] = this.editrbuId;
      const postData = JSON.parse(JSON.stringify(this.rbuEditForm.value));
      this.mastersService.postEditRBU(postData).subscribe((data) => {
        this.spinner.hide();
        if (data.status) {
          this.router.navigate(['masters/list-rbu']);
          this.common.openSnackBar('Category4 Updated Successfuly', '', 'success-snackbar');
        }
        else {
          this.rbuEditForm.controls["rbuName"].setErrors({ serverValidateError: "Category4 Name is duplicate" });
        }
      },
      sError => {
        this.common.apiError(sError);
      });
    }
  }

  onReset() {
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
    this.isSubmitted = false;
    this.rbuEditForm.reset();
  }

}
