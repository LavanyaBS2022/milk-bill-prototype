import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddRbuComponent } from './add-rbu.component';

describe('AddRbuComponent', () => {
  let component: AddRbuComponent;
  let fixture: ComponentFixture<AddRbuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddRbuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddRbuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
