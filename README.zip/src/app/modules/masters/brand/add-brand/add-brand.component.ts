import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormGroup, FormControl, Validators, FormBuilder } from "@angular/forms";
import { MastersService } from "./../../../../shared/service/masters/masters.service";
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";


@Component({
  selector: 'app-add-brand',
  templateUrl: './add-brand.component.html',
  styleUrls: ['./add-brand.component.scss']
})
export class AddBrandComponent implements OnInit {

  public brandAddForm: FormGroup;
  public isSubmitted: boolean = false;

  constructor(private formBuilder: FormBuilder, public masterService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService
    ) {
  }

  ngOnInit() {
    this.brandAddForm = this.formBuilder.group({
      brandName: ['', [Validators.required, Validators.maxLength(50)]]
    });
  }

  public get get() {
    return this.brandAddForm.controls;
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.brandAddForm.get("brandName").value.trim() == "") {
      this.common.openSnackBar('Please fill all the mandatory fields','', 'danger-snackbar');
      return 
    }
    if (this.brandAddForm.valid && this.brandAddForm.get("brandName").value.trim() != "") {
      this.spinner.show();
      const postData = JSON.parse(JSON.stringify(this.brandAddForm.value));
      this.masterService.postAddBrand(postData).subscribe((data) => {
        this.spinner.hide();
        if (data.status) {
          this.router.navigate(['masters/listBrand']);
          this.common.openSnackBar('Brand Inserted Successfully', '', 'success-snackbar');
        } else {
          this.brandAddForm.controls["brandName"].setErrors({ serverValidateError: "Brand Name Data is duplicate" });
        }
      },
      sError => {
        this.common.apiError(sError);
      });
    }
  }
  onReset() {
    this.isSubmitted = false;
    this.brandAddForm.reset();
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
  }

}
