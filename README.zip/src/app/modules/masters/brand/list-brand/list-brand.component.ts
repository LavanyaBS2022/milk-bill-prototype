import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Router } from '@angular/router';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-list-brand',
  templateUrl: './list-brand.component.html',
  styleUrls: ['./list-brand.component.scss']
})
export class ListBrandComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  public brandList_datasource = new MatTableDataSource();
  brandDisplayedColumns: string[] = ['SNo', 'name', 'action'];

  constructor(private masterService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService
    ) { }

  ngOnInit() {
    this.getBrandList();
  }

  applyFilter(filterValue: string) {
    this.brandList_datasource.filter = filterValue.trim().toLowerCase();
  }

  public getBrandList() {
    this.spinner.show();
    this.masterService.getListBrand().subscribe(
      sResponseModel => {
        this.spinner.hide();
        if (sResponseModel.data) {
          this.brandList_datasource.data = sResponseModel.data;
          this.brandList_datasource.paginator = this.paginator;
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public editBrand(id) {
    const editId = btoa(id);
    this.router.navigate(['masters/editBrand'], { queryParams: { editId } });
  }

  public deleteBrand(brandId) {
    this.common.openConfirmDialog('Are you sure to delete this Brand ?')
      .afterClosed().subscribe(res => {
        if (res) {
          let brandIndex = this.brandList_datasource.data.findIndex(key => key['id'] == brandId)
          this.masterService.getDeleteBrand(brandId).subscribe((data) => {
            if (data.data) {
              this.brandList_datasource.data.splice(brandIndex, 1);
              this.brandList_datasource.data = this.brandList_datasource.data;
              this.common.openSnackBar('Brand Deleted Successfully', '', 'success-snackbar');
            }
            else {
              this.common.openSnackBar('Could Not Delete This Brand', '', 'danger-snackbar');
            }
          },
          sError => {
            this.common.apiError(sError);
          })
        }
      });
  }

}
