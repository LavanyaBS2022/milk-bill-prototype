import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-edit-brand',
  templateUrl: './edit-brand.component.html',
  styleUrls: ['./edit-brand.component.scss']
})
export class EditBrandComponent implements OnInit {

  public brandEditForm: FormGroup;
  public editBrandId: any;
  public editBrandData: any;
  public isSubmitted: boolean = false;

  constructor(private formBuilder: FormBuilder, public route: ActivatedRoute, public mastersService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService) {
    this.route.queryParams.subscribe(params => {
      this.editBrandId = (atob(params.editId));
      this.getEditBrandData(this.editBrandId);
    });
  }

  ngOnInit() {
    this.brandEditForm = this.formBuilder.group({
      brandName: ['', [Validators.required, Validators.maxLength(50)]]
    });
  }

  public get get() {
    return this.brandEditForm.controls;
  }

  getEditBrandData(editId: any) {
    this.mastersService.getListBrandbyId(editId).subscribe((data) => {
      this.editBrandData = data.data;
      this.brandEditForm.patchValue({
        brandName: this.editBrandData[0].name
      });
    },
    sError => {
      this.common.apiError(sError);
    });
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.brandEditForm.get("brandName").value.trim() == "") {
      this.common.openSnackBar('Please fill all the mandatory fields','', 'danger-snackbar');
      return
    }

    if (this.brandEditForm.valid && this.brandEditForm.get("brandName").value.trim() != "") {
      this.brandEditForm.value['editBrandId'] = this.editBrandId;
      const postData = JSON.parse(JSON.stringify(this.brandEditForm.value));
      this.spinner.show();
      this.mastersService.postUpdateBrand(postData).subscribe((data) => {
        this.spinner.hide();
        if (data.status) {
          this.router.navigate(['masters/listBrand']);
          this.common.openSnackBar('Brand Updated Successfully', '', 'success-snackbar');
        } else {
          this.brandEditForm.controls["brandName"].setErrors({ serverValidateError: "Brand Name Data is duplicate" });
        }
      },
      sError => {
        this.common.apiError(sError);
      });
    }
  }

  onReset() {
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');

    this.isSubmitted = false;
    this.brandEditForm.reset();
  }

}
