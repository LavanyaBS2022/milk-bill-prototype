import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddProdutTypeComponent } from './add-produt-type.component';

describe('AddProdutTypeComponent', () => {
  let component: AddProdutTypeComponent;
  let fixture: ComponentFixture<AddProdutTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddProdutTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddProdutTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
