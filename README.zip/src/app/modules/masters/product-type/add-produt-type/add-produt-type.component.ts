import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormGroup, FormControl, Validators, FormBuilder } from "@angular/forms";
import { MastersService } from "./../../../../shared/service/masters/masters.service";
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-add-produt-type',
  templateUrl: './add-produt-type.component.html',
  styleUrls: ['./add-produt-type.component.scss']
})
export class AddProdutTypeComponent implements OnInit {

  public producttypeAddForm: FormGroup;
  public isSubmitted: boolean = false;

  constructor(private formBuilder: FormBuilder, public masterService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService) {
  }

  ngOnInit() {
    this.producttypeAddForm = this.formBuilder.group({
      prodtypeName: ['', [Validators.required, Validators.maxLength(50)]]
    });
  }

  public get get() {
    // console.log('UIError:', this.producttypeAddForm);
    return this.producttypeAddForm.controls;
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.producttypeAddForm.get("prodtypeName").value.trim() == "") {
      this.common.openSnackBar('Please fill all the mandatory fields','', 'danger-snackbar');
      return
    }

    if (this.producttypeAddForm.valid && this.producttypeAddForm.get("prodtypeName").value.trim() != "") {
      const postData = JSON.parse(JSON.stringify(this.producttypeAddForm.value));
      this.masterService.postAddProductType(postData).subscribe((data) => {
        if (data.status) {
          this.router.navigate(['masters/listProductType']);
          this.common.openSnackBar('Successfully Inserted the record!!!', '', 'success-snackbar');
        } else {
          this.producttypeAddForm.controls["prodtypeName"].setErrors({ serverValidateError: "Category4 Name Data is duplicate" });
        }
      },
      sError => {
        this.common.apiError(sError);
      });
    }
  }

  onReset() {
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
    this.isSubmitted = false;
    this.producttypeAddForm.reset();
  }

}
