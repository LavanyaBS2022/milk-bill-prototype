import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";


@Component({
  selector: 'app-edit-produt-type',
  templateUrl: './edit-produt-type.component.html',
  styleUrls: ['./edit-produt-type.component.scss']
})
export class EditProdutTypeComponent implements OnInit {

  public producttypeEditForm: FormGroup;
  public editProductTypeId: any;
  public editProductTypeData: any;
  public isSubmitted: boolean = false;

  constructor(private formBuilder: FormBuilder, public route: ActivatedRoute, public mastersService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService) {
    this.route.queryParams.subscribe(params => {
      this.editProductTypeId = (atob(params.editId));
      this.getEditProductTypeData(this.editProductTypeId);
    });
  }

  ngOnInit() {
    this.producttypeEditForm = this.formBuilder.group({
      producttypeName: ['', [Validators.required, Validators.maxLength(50)]]
    });
  }

  public get get() {
    return this.producttypeEditForm.controls;
  }

  getEditProductTypeData(editId: any) {
    this.mastersService.getListProductTypebyId(editId).subscribe((data) => {
      this.editProductTypeData = data.data;
      this.producttypeEditForm.patchValue({
        producttypeName: this.editProductTypeData[0].name
      });
    },
    sError => {
      this.common.apiError(sError);
    });
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.producttypeEditForm.get("producttypeName").value.trim() == "") {
      this.common.openSnackBar('Please fill all the mandatory fields','', 'danger-snackbar');
      return;
    }

    if (this.producttypeEditForm.valid && this.producttypeEditForm.get("producttypeName").value.trim() != "") {
      this.spinner.show();
      this.producttypeEditForm.value['editProdTypeId'] = this.editProductTypeId;
      const postData = JSON.parse(JSON.stringify(this.producttypeEditForm.value));
      this.mastersService.postUpdateProductType(postData).subscribe((data) => {
        this.spinner.hide();
        if (data.status) {
          this.router.navigate(['masters/listProductType']);
          this.common.openSnackBar('Category1 Updated Successfully', '', 'success-snackbar');
        } else {
          this.producttypeEditForm.controls["producttypeName"].setErrors({ serverValidateError: "Category1 Name is duplicate" });
        }

      },
      sError => {
        this.common.apiError(sError);
      });
    }
  }

  onReset() {
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
    this.isSubmitted = false;
    this.producttypeEditForm.reset();
  }

}
