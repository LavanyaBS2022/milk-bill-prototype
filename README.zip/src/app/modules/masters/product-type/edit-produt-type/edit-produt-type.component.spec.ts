import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditProdutTypeComponent } from './edit-produt-type.component';

describe('EditProdutTypeComponent', () => {
  let component: EditProdutTypeComponent;
  let fixture: ComponentFixture<EditProdutTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditProdutTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditProdutTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
