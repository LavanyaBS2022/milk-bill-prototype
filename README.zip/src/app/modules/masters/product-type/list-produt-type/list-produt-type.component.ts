import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Router } from '@angular/router';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-list-produt-type',
  templateUrl: './list-produt-type.component.html',
  styleUrls: ['./list-produt-type.component.scss']
})
export class ListProdutTypeComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  public producttypeList_datasource = new MatTableDataSource();
  producttypeDisplayedColumns: string[] = ['SNo', 'name', 'action'];

  constructor(private masterService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService) { }

  ngOnInit() {
    this.getProductTypeList();
  }

  applyFilter(filterValue: string) {
    this.producttypeList_datasource.filter = filterValue.trim().toLowerCase();
  }

  public getProductTypeList() {
    this.spinner.show();
    this.masterService.getListProductType().subscribe(
      sResponseModel => {
        this.spinner.hide();
        if (sResponseModel.data) {
          this.producttypeList_datasource.data = sResponseModel.data;
          this.producttypeList_datasource.paginator = this.paginator;
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public editProductType(id) {
    // console.log('Edit Method Called id is:', id);
    const editId = btoa(id);
    this.router.navigate(['masters/editProductType'], { queryParams: { editId } });
  }

  public deleteProductType(producttypeId) {
    this.common.openConfirmDialog('Are you sure to delete this Category1 ?')
      .afterClosed().subscribe(res => {
        if (res) {
          let producttypeIndex = this.producttypeList_datasource.data.findIndex(key => key['id'] == producttypeId)
          this.masterService.getDeleteProductType(producttypeId).subscribe((data) => {
            if (data.data) {
              this.producttypeList_datasource.data.splice(producttypeIndex, 1);
              this.producttypeList_datasource.data = this.producttypeList_datasource.data;
              this.common.openSnackBar('Category1 deleted Successfully', '', 'success-snackbar');
            }
            else {
              this.common.openSnackBar('Could Not Delete Category1', '', 'danger-snackbar');
            }
          })
        }
      },
      sError => {
        this.common.apiError(sError);
      });
  }

}
