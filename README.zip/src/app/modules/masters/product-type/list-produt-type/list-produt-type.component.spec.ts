import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListProdutTypeComponent } from './list-produt-type.component';

describe('ListProdutTypeComponent', () => {
  let component: ListProdutTypeComponent;
  let fixture: ComponentFixture<ListProdutTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListProdutTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListProdutTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
