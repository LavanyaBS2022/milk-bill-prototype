import { Component, OnInit } from '@angular/core';
import { MastersService } from '../../../shared/service/masters/masters.service';

@Component({
  selector: 'app-article-import',
  templateUrl: './article-import.component.html',
  styleUrls: ['./article-import.component.scss']
})
export class ArticleImportComponent {
  fileData: any;
  msg: any;
  constructor(private masterSrv: MastersService) { }

  fileInputChange(fileInputEvent: any, typeFor?: any) {
    if (fileInputEvent.target.files.length > 0) {
      this.fileData = fileInputEvent.target.files[0];
    }
  }

  onSubmit() {
    if (this.fileData) {
      const form = new FormData();
      form.append('fileName', this.fileData);
      this.masterSrv.importArticleImages(form).subscribe((sResponse: any) => {
        // console.log(sResponse);
        this.msg = "Successfully Uploaded Images";
      }, sError => {
        this.msg = "Error while uploading images";
      })
    } else {
      this.msg = "Please select the file for uploading";
    }
  }

}
