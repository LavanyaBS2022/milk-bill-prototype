import { Component, OnInit } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { MastersService } from '../../../shared/service/masters/masters.service';
import { ActivatedRoute } from '@angular/router';
import { Common } from '../../../shared/service/common/common';

@Component({
  selector: 'app-suggested-articles',
  templateUrl: './suggested-articles.component.html',
  styleUrls: ['./suggested-articles.component.scss']
})
export class SuggestedArticlesComponent implements OnInit {
  public getmessage;
  public seasonId:any='';
  public fileType: string = 'suggestedArticleFW';
  public orderWindowId:any='';
  public seasonList = [];
  public orderWindowList = [];
  public rows;
  public fileData;

  constructor(private maseterService: MastersService, private route: ActivatedRoute,
    private common:Common) {}

  ngOnInit() {
    let userDetails=this.common.getUserDetails();
    this.getSeasons();
  }

  fileInputChange(fileInputEvent: any,typeFor?:any) {
    if (fileInputEvent.target.files.length > 0) { 
        this.fileData= fileInputEvent.target.files[0];
    }
  }

  getSeasons() {
    this.maseterService.getlistSeason().subscribe((sRespone:any)=>{
       //console.log('seasons',sRespone.data);
      this.seasonList=sRespone.data;
    },
    sError => {
      this.common.apiError(sError);
    });
  }

  getOrderWindowList() {
    const onlyActive = 0;
    this.maseterService.getOrderWindowSeasonList(onlyActive).subscribe((data)=>{
      //console.log('getOrderWindowList',data.data);
      let result = data.data;
      this.orderWindowList=result.filter(item=>item.season_id==this.seasonId);
      //console.log('orderWindowList',this.orderWindowList);
    },
    sError => {
      this.common.apiError(sError);
    });
  }

  importData() {
    this.common.showSpinner();
    let form = new FormData();
    let seasonId:any = this.seasonId;
    let orderWindowId:any = this.orderWindowId;
    form.append('fileName', this.fileData);
    form.append('seasonId', seasonId);
    form.append('orderWindowId', orderWindowId);
    form.append('fileType', this.fileType);
    this.maseterService.importSuggestedData(form).subscribe((sRespone: any) => {
      // console.log(sRespone);
      if (sRespone.data) {
        this.getmessage = sRespone.data.setmessage;
        this.rows = sRespone.data;
        this.common.hideSpinner();
      }
      
    },
    sError => {
      this.common.apiError(sError);
    });
   
  }

}
