import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-add-franchise',
  templateUrl: './add-franchise.component.html',
  styleUrls: ['./add-franchise.component.scss']
})
export class AddFranchiseComponent implements OnInit {
  public franchiseAddForm: FormGroup;
  public submitted = false;
  public isDuplicateFound: boolean = false;
  public regionListDropdown;
  public countryListDropdown;
  public stateListDropdown;
  public cityListDropdown;
  public franchiseTypeListDropdown;
  public brandListDropdown;
  public salesPersonListDropdown;
  public subsidiaryList;
  public mailcustypeList;
  public moqstatusList=[
    {id:0,name:'No'},
    {id:1,name:'Yes'}
  ]
  constructor(private formBuilder: FormBuilder, public mastersService: MastersService, public router: Router, private common: Common, private spinner:NgxSpinnerService) {
    this.getSeasonListDropdown();
    this.getfranchiseTypeDropdown();
  }
  getSeasonListDropdown() {
    this.mastersService.getRegion().subscribe((data) => {
      // console.log('dropdown', data.data);
      if(data.data){
        this.regionListDropdown = data.data;
      }
    },
    sError => {
      this.common.apiError(sError);
    });
  }
  getfranchiseTypeDropdown() {
    this.mastersService.getFranchiseeType().subscribe((data) => {
      console.log('dropdown', data.data);
      if(data.data){
        this.franchiseTypeListDropdown = data.data;
      }
      else{
        //no franchise type
        this.franchiseTypeListDropdown = [];
      }
    },
    sError => {
      this.common.apiError(sError);
    });
  }

  getCountryListDropdown(regionId) {
    // console.log('reached',this.get.regionId.value);
    this.mastersService.getCountry(this.get.regionId.value).subscribe((data) => {
      //console.log('country',data.data);
      
      if(data.data){
        this.countryListDropdown = data.data;
        this.stateListDropdown = [];
        this.cityListDropdown = [];
      }
      else{
        //no country found
        this.countryListDropdown = [];
        this.stateListDropdown = [];
        this.cityListDropdown = [];
      }
    },
    sError => {
      this.common.apiError(sError);
    });
  }
  getStateListDropdown(countryId) {
    //console.log('reached',this.get.countryId.value);
    this.mastersService.getState(this.get.countryId.value).subscribe((data) => {
      if( data.data){
        this.stateListDropdown = data.data;
        this.cityListDropdown = [];      
      }
      else{
        //no state found
        this.stateListDropdown = [];
        this.cityListDropdown = [];      
      }
    },
    sError => {
      this.common.apiError(sError);
    });
  }
  getCityListDropdown(stateid) {
    this.mastersService.getCity(this.get.stateId.value).subscribe((data) => {
      if( data.data){
        this.cityListDropdown = data.data;
      }
      else{
        //no city found
        this.cityListDropdown = [];
      }
    },
    sError => {
      this.common.apiError(sError);
    });
  }

  ngOnInit() {

    this.franchiseAddForm = this.formBuilder.group({
      franchiseName: ['', Validators.required],
      franchiseCode: [''],
      franchiseType: ['', Validators.required],
      mobile: [''],
      email: ['', Validators.required],
      address: [''],
      contactPerson: [''],
      regionId: ['', Validators.required],
      countryId: ['', Validators.required],
      salesuserId: ['', Validators.required],
      subsidiaryId:['', Validators.required],
      stateId: [''],
      cityId: [''],
      brandSelected: ['', Validators.required],
      ratio: ['', Validators.required],
      moqStatus: ['', Validators.required],
      customerType:['',Validators.required]
    });
    this.getBrandList();
    this.getSalespersons();
    this.getSubsidiaries();
    this.getmailCustype();
  }
  get get() { return this.franchiseAddForm.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.franchiseAddForm.invalid) {
      this.common.openSnackBar('Please fill all the mandatory fields','', 'danger-snackbar');
      return;
    }
    else {
      this.spinner.show();
      const postData = {
        "franchiseName": this.get.franchiseName.value,
        "franchiseCode": this.get.franchiseCode.value,
        "franchiseType": this.get.franchiseType.value,
        "mobile": this.get.mobile.value,
        "email": this.get.email.value,
        "address": this.get.address.value,
        "contactPerson": this.get.contactPerson.value,
        "regionId": this.get.regionId.value,
        "countryId": this.get.countryId.value,
        "stateId": this.get.stateId.value,
        "cityId": this.get.cityId.value,
        "brandSelected": this.get.brandSelected.value,
        "ratio": this.get.ratio.value,
        "createdUser": 1,
        "createdDate": new Date(),
        "status": 1,
        "salesuserId":this.get.salesuserId.value,
        "subsidiaryId":this.get.subsidiaryId.value,
        "customer_type":this.get.customerType.value,
        "moq":this.get.moqStatus.value
      };
      //console.log('postData', postData);
      //return;
      this.mastersService.postAddFranchise(postData).subscribe((data) => {
        //console.log('data',data);
        this.spinner.hide();

        if(data.data){
          this.router.navigate(['masters/listFranchise']);
          this.common.openSnackBar('New Customer Added Successfully','', 'success-snackbar');
        }
        else{
          this.common.openSnackBar('Could Not Add Customer','', 'danger-snackbar');
          this.spinner.hide();
        }
        

      },
      sError => {
        this.common.apiError(sError);
      });
    }

  }

  reset() {
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
    this.franchiseAddForm.reset();
  }

  public getBrandList() {
    this.mastersService.getListBrand().subscribe(
      sResponseModel => {
        if (sResponseModel.data) {
          this.brandListDropdown = sResponseModel.data;
          // console.log('brandListDropdown', this.brandListDropdown);
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public getSalespersons(){
    this.mastersService.getSalesPerson().subscribe((sResponse:any)=>{
      this.salesPersonListDropdown=sResponse.data;
      console.log('Sales persons',sResponse.data);
    }, sError => {
      this.common.openSnackBar('No sales person found','', 'danger-snackbar');
    });
  }

  public getSubsidiaries(){
    this.mastersService.getSubsidiaries().subscribe((sResponse:any)=>{
      this.subsidiaryList=sResponse.data;
     // console.log('Subsidiary',sResponse);
    }, sError => {
      this.common.openSnackBar('No Subsidiaries person found','', 'danger-snackbar');
    });
  }

  public getmailCustype(){
    this.mastersService.getmailCusTpe().subscribe((sResponse:any)=>{
      this.mailcustypeList=sResponse.data;
      console.log(this.mailcustypeList);
    }, sError => {
      this.common.openSnackBar('No Subsidiaries person found','', 'danger-snackbar');
    });
  }

  selectSubsbsidiary(sid){
    //console.log('Subid',sid);
    if(sid){
      this.get.subsidiaryId.setValue(sid);
    }
    
  }
}
