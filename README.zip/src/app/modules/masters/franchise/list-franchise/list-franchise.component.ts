import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Router } from '@angular/router';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";


@Component({
  selector: 'app-list-franchise',
  templateUrl: './list-franchise.component.html',
  styleUrls: ['./list-franchise.component.scss']
})
export class ListFranchiseComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;

  public franchiseList = new MatTableDataSource();
  public userDetails: any;
  public roleId;
  public userId;

  displayedColumns: string[] = ['sno', 'franchise_name', 'franchise_type', 'region', 'country', 'state', 'city', 'actions'];
  
  constructor(private mastersService: MastersService, private router: Router, public dialog: MatDialog, private common: Common ,private spinner:NgxSpinnerService) {
    this.userDetails = this.common.getUserDetails();
    this.roleId=this.userDetails.roleId;
    this.userId=this.userDetails.user_id;
  }
  ngOnInit() {
    this.getFranchiseListData();
  }
  applyFilter(filterValue: string) {
    this.franchiseList.filter = filterValue.trim().toLowerCase();
  }
  public getFranchiseListData() {
    this.spinner.show();
    //console.log('roleId',this.roleId);
    //console.log('userId',this.userId);
    
    
    this.mastersService.getlistFranchise(this.roleId,this.userId).subscribe(
      sResponseModel => {
        //console.log('sResponseModelll', sResponseModel);
        if (sResponseModel.data != false) {
          this.spinner.hide();
          this.franchiseList.data = sResponseModel.data;
          this.franchiseList.paginator = this.paginator;
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }
  public editFranchise(id) {
    const editId = btoa(id);
    this.router.navigate(['masters/editFranchise'], { queryParams: { editId } });
  }
  public deleteFranchise(franchiseId) {
    this.common.openConfirmDialog('Are you sure to delete this Customer ?')
    .afterClosed().subscribe(res =>{
      if(res){
        let franchiseIndex = this.franchiseList.data.findIndex(key => key['id'] == franchiseId)
        this.mastersService.getDeleteFranchise(franchiseId).subscribe((data) => {
          if (data.data) {
            this.franchiseList.data.splice(franchiseIndex, 1);
            this.franchiseList.data = this.franchiseList.data;
            this.common.openSnackBar('Customer Deleted Successfully','', 'success-snackbar');
          }
          else{
            this.common.openSnackBar('Could Not Delete Customer','', 'danger-snackbar');
          }
        },
        sError => {
          this.common.apiError(sError);
        });
      }
    });

  }

  onExportClicked(reportType?: any, filterKey?: any, filterValue?: any) {
    this.common.exportAsExcelFile(reportType, filterKey, filterValue);
  }
}
