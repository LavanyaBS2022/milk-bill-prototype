import { Component, OnInit,ViewChild,Inject } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort ,MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { MastersService } from '../../../shared/service/masters/masters.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Common } from '../../../shared/service/common/common';


@Component({
  selector: 'orderWindowPopUp',
  templateUrl: 'orderWindowPopUp.html',
  styleUrls: ['./orderwindow-popup.scss']
})
export class DialogOrderWindowPopUpComponent {

  constructor(
    public dialogRef: MatDialogRef<DialogOrderWindowPopUpComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  onNoClick(): void {
    this.dialogRef.close();
  }
}

@Component({
  selector: 'app-edit-view',
  templateUrl: './edit-view.component.html',
  styleUrls: ['./edit-view.component.scss']
})
export class EditViewComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;

  public sizeList = new MatTableDataSource();
  public articleData:any='';
 public articleId:any='';
 public sizeInfo:any='';
 public viewDetail:any='';
 public season_id:any='';
 public order_window_id:any='';

 displayedColumns: string[] = ['sNo','Sizes','Actions'];

  constructor(private activatedRoute: ActivatedRoute,private masterService: MastersService,
    private common: Common, public dialog: MatDialog) { 
    this.articleId = this.activatedRoute.snapshot.queryParams['aid'];
    this.season_id= this.activatedRoute.snapshot.queryParams['sid'];
    this.order_window_id= this.activatedRoute.snapshot.queryParams['owid'];
    //console.log(this.articleId);
    
  }

  ngOnInit() {
    this.getArticle();
  }

  getArticle(){
    this.masterService.getArticleDetails(this.articleId,this.season_id,this.order_window_id).subscribe((sResponse:any)=>{
    //console.log('articleDetail',sResponse.data);
    if(sResponse.data){
     this.articleData=sResponse.data[0];
     let szarr=this.articleData.sizes.split(',');
     let szarrobj=[];
     szarr.forEach(val => {
       let obj={
        size:val
       }
      szarrobj.push(obj);
     });
     //console.log(this.articleData);
     this.sizeList.data=szarrobj;
     this.viewDetail=[
       {label:'Description',value:this.articleData.article_description},
       {label:'Category 1',value:this.articleData.category_1},
       {label:'Category 4',value:this.articleData.category_4}
     ]
    // console.log(this.viewDetail);
     
     }else{
      this.common.openSnackBar('No record found','', 'danger-snackbar');
    }
    },
    sError => {
      this.common.apiError(sError);
    }
    );
  }
  infoSize(size,chk?){
    let season_id=this.articleData.season_id;
    let order_window_id=this.articleData.order_window_id;
   this.masterService.getSizeInformation(size,this.articleId,season_id,order_window_id).subscribe((sResponse:any)=>{
     //console.log('InfosizeData',sResponse.data);
     if(sResponse.data){
     this.sizeInfo=sResponse.data;
     //console.log('sizeInfo',this.sizeInfo);
     if(chk){
       this.openDialog(size);
     }
     
     }else{
      this.common.openSnackBar('No record found','', 'danger-snackbar');
     }
   },
   sError => {
    this.common.apiError(sError);
  });
    
  }
  deleteSize(size){
    this.common.openConfirmDialog('Are you sure to delete this Size!! ?')
    .afterClosed().subscribe(res =>{
    if(res){
      this.common.showSpinner();
  let sizeObj={
   size:size,
   articleId:this.articleId,
   seasonId:this.articleData.season_id,
   orderWindowId:this.articleData.order_window_id
  }
  this.masterService.deleteArticleSize(sizeObj).subscribe((sResponse:any)=>{
    // console.log(sResponse);
    if(sResponse.data==true){
     this.getArticle();
     this.common.hideSpinner();
    }else{
      this.common.openSnackBar('Error in remove size','', 'danger-snackbar');
    }
  },sError => {
    this.common.apiError(sError);
  });
    }
   });
  }

  openDialog(size): void {
    const dialogRef = this.dialog.open(DialogOrderWindowPopUpComponent, {
      disableClose: true,
      width: '800px',
      data: {
        sizeinfoList: this.sizeInfo,
        onSize:size
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      //console.log('The dialog was closed', result);
    });

  }

}
