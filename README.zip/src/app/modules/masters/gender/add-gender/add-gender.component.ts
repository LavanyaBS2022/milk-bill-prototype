import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormGroup, FormControl, Validators, FormBuilder } from "@angular/forms";
import { MastersService } from "./../../../../shared/service/masters/masters.service";
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-add-gender',
  templateUrl: './add-gender.component.html',
  styleUrls: ['./add-gender.component.scss']
})
export class AddGenderComponent implements OnInit {

  public genderAddForm: FormGroup;
  public isSubmitted: boolean = false;

  constructor(private formBuilder: FormBuilder, public masterService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService) {
  }

  ngOnInit() {
    this.genderAddForm = this.formBuilder.group({
      genderName: ['', [Validators.required, Validators.maxLength(50)]]
    });
  }

  public get get() {
    return this.genderAddForm.controls;
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.genderAddForm.get("genderName").value.trim() == "") {
      return this.genderAddForm.controls["genderName"].setErrors({ emptyValidateError: "This field is mandatory" });
    }

    if (this.genderAddForm.valid && this.genderAddForm.get("genderName").value.trim() != "") {
      this.spinner.show();
      const postData = JSON.parse(JSON.stringify(this.genderAddForm.value));
      this.masterService.postAddGender(postData).subscribe((data) => {
        this.spinner.hide();
        if (data.status) {
          this.router.navigate(['masters/listGender']);
          this.common.openSnackBar('Gender Added Successfully', '', 'success-snackbar');
        } else {
          this.genderAddForm.controls["genderName"].setErrors({ serverValidateError: "This gender is already Exist.Try with different name " });
        }
      },
      sError => {
        this.common.apiError(sError);
      });
    }
  }

  onReset() {
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
    this.isSubmitted = false;
    this.genderAddForm.reset();
  }


}
