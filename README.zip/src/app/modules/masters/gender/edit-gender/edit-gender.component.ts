import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-edit-gender',
  templateUrl: './edit-gender.component.html',
  styleUrls: ['./edit-gender.component.scss']
})
export class EditGenderComponent implements OnInit {

  public genderEditForm: FormGroup;
  public editGenderId: any;
  public editGenderData: any;
  public isSubmitted: boolean = false;

  constructor(private formBuilder: FormBuilder, public route: ActivatedRoute, public mastersService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService) {
    this.route.queryParams.subscribe(params => {
      this.editGenderId = (atob(params.editId));
      this.getEditGenderData(this.editGenderId);
    });
  }

  ngOnInit() {
    this.genderEditForm = this.formBuilder.group({
      genderName: ['', [Validators.required, Validators.maxLength(50)]]
    });
  }

  public get get() {
    return this.genderEditForm.controls;
  }

  getEditGenderData(editId: any) {
    this.mastersService.getListGenderbyId(editId).subscribe((data) => {
      this.editGenderData = data.data;
      this.genderEditForm.patchValue({
        genderName: this.editGenderData[0].name
      });
    },
    sError => {
      this.common.apiError(sError);
    });
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.genderEditForm.get("genderName").value.trim() == "") {
      return this.genderEditForm.controls["genderName"].setErrors({ emptyValidateError: "This field is mandatory" });
    }

    if (this.genderEditForm.valid && this.genderEditForm.get("genderName").value.trim() != "") {
      this.spinner.show();
      this.genderEditForm.value['editGenderId'] = this.editGenderId;
      const postData = JSON.parse(JSON.stringify(this.genderEditForm.value));
      this.mastersService.postUpdateGender(postData).subscribe((data) => {
        this.spinner.hide();
        if (data.status) {
          this.router.navigate(['masters/listGender']);
          this.common.openSnackBar('Gender Updated Successfully', '', 'success-snackbar');
        } else {
          this.genderEditForm.controls["genderName"].setErrors({ serverValidateError: "This gender is already exist. Try with different name" });
        }
      },
      sError => {
        this.common.apiError(sError);
      });
    }
  }

  onReset() {
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
    this.isSubmitted = false;
    this.genderEditForm.reset();
  }

}
