import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Router } from '@angular/router';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-list-gender',
  templateUrl: './list-gender.component.html',
  styleUrls: ['./list-gender.component.scss']
})
export class ListGenderComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  public genderList_datasource = new MatTableDataSource();
  genderDisplayedColumns: string[] = ['SNo', 'name', 'action'];

  constructor(private masterService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService) { }

  ngOnInit() {
    this.getGenderList();
  }

  applyFilter(filterValue: string) {
    this.genderList_datasource.filter = filterValue.trim().toLowerCase();
  }

  public getGenderList() {
    this.spinner.show();
    this.masterService.getListGender().subscribe(
      sResponseModel => {
        this.spinner.hide();
        if (sResponseModel.data) {
          this.genderList_datasource.data = sResponseModel.data;
          this.genderList_datasource.paginator = this.paginator;
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public editGender(id) {
    // console.log('Edit Method Called id is:', id);
    const editId = btoa(id);
    this.router.navigate(['masters/editGender'], { queryParams: { editId } });
  }

  public deleteGender(genderId) {
    this.common.openConfirmDialog('Are you sure to delete this Gender ?')
      .afterClosed().subscribe(res => {
        if (res) {
          let genderIndex = this.genderList_datasource.data.findIndex(key => key['id'] == genderId)
          this.masterService.getDeleteGender(genderId).subscribe((data) => {
            if (data.data) {
              this.genderList_datasource.data.splice(genderIndex, 1);
              this.genderList_datasource.data = this.genderList_datasource.data;
              this.common.openSnackBar('Gender Deleted Successfully', '', 'success-snackbar');
            }
            else {
              this.common.openSnackBar('Could Not Delete This Gender', '', 'success-snackbar');
            }
          },
          sError => {
            this.common.apiError(sError);
          });
        }
      });
  }

}
