import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Common } from '../../../../shared/service/common/common';

@Component({
  selector: 'app-edit-order-window',
  templateUrl: './edit-order-window.component.html',
  styleUrls: ['./edit-order-window.component.scss']
})
export class EditOrderWindowComponent implements OnInit {
  public orderWindowEditForm : FormGroup;
  public editId;
  public submitted = false;
  public isDuplicateFound: boolean = false;
  public maxDate ;
  public minDate;
  public seasonListDropdown;
  public editedData;
  public orderwindoType=[
    {id:1,name:"FW"},
    {id:2,name:"APEQ"}
  ];

  constructor(private formBuilder: FormBuilder,public route :ActivatedRoute, public mastersService:MastersService,public router: Router,public common: Common) { 
    this.route.queryParams.subscribe(params=>{
      this.editId   = (atob(params.editId));
      this.getseasonListDropdown();
      this.getEditOrderWindowData(this.editId);
    });
  }

  ngOnInit() {
    this.orderWindowEditForm = this.formBuilder.group({
      orderWindowName : ['', Validators.required] ,
      seasonId :  ['', Validators.required] ,
      startDate :  ['', Validators.required] ,
      endDate :  ['', Validators.required],
      owtypeId :  ['']
    });
  }
  updateMaxDate() {
    this.maxDate = new Date(this.get.endDate.value);
    this.maxDate.setDate(this.maxDate.getDate() - 1);
  }
  updateMinDate() {
    this.minDate = new Date(this.get.startDate.value);
    this.minDate.setDate(this.minDate.getDate() + 1);
  }
  get get() { return this.orderWindowEditForm.controls; }

getseasonListDropdown(){
    this.mastersService.getlistSeason().subscribe((data)=>{
      // console.log('dropdown',data.data);
      this.seasonListDropdown=data.data;
    },
    sError => {
      this.common.apiError(sError);
    });
  }
  onSubmit(){
    this.submitted = true;
    if (this.orderWindowEditForm.invalid) {
      this.common.openSnackBar('Please fill all the mandatory fields','', 'danger-snackbar');
      return;
  }
  else{
    // console.log(this.orderWindowEditForm.value);
    // const postData = JSON.parse(JSON.stringify(this.seasonEditForm.value));

    const postData = {
      "orderWindowId": this.editId,
      "orderWindowName"	: this.get.orderWindowName.value,
      "seasonId"        : this.get.seasonId.value,
      "startDate"       : this.get.startDate.value,
      "endDate"         : this.get.endDate.value,
      "updatedUser"    : 1,
      "updatedDate"    : new Date(),
      "status"         : 1,
     "order_window_type":this.get.owtypeId.value
   };
    this.mastersService.postEditOrderWindow(postData).subscribe((data)=>{
      // console.log("sResponseModel",data);
      if(data.status){
        this.router.navigate(['masters/listOrderWindow']);
        this.common.openSnackBar('Order Window Updated Successfully','', 'success-snackbar');
      }
      else{
        this.common.openSnackBar('Order Window Updated UnSuccessfully','', 'danger-snackbar');
      }
      
    },
    sError => {
      this.common.apiError(sError);
    });
  }
   
  }
  getEditOrderWindowData(editId){
    // console.log(editId);
    this.mastersService.getlistOrderWindowById(editId).subscribe((data)=>{

      this.editedData =  data.data;
      // console.log(data.data);
      // console.log( 'season type',this.editedData[0].name)
      // this.seasonEditForm.patchValue({
      //   seasonType: res[0].season_type,
      //   seasonName : res[0].season_name
      // });
      this.minDate = new Date(this.editedData[0].from_date);
      this.minDate.setDate( this.minDate.getDate() + 1 );

      this.maxDate =new Date(this.editedData[0].to_date);
      this.maxDate.setDate( this.maxDate.getDate() - 1 );

      this.orderWindowEditForm.patchValue({
        orderWindowName: this.editedData[0].name,
        seasonId:this.editedData[0].season_id,
        startDate:this.editedData[0].start_date,
        endDate:this.editedData[0].end_date,
        owtypeId:this.editedData[0].ow_type
      });
      // this.router.navigate(['masters/list-season']);
    },
    sError => {
      this.common.apiError(sError);
    });
  }
  reset(){
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
    this.orderWindowEditForm.reset();
  }



}
