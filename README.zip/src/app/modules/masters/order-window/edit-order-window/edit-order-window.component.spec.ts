import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditOrderWindowComponent } from './edit-order-window.component';

describe('EditOrderWindowComponent', () => {
  let component: EditOrderWindowComponent;
  let fixture: ComponentFixture<EditOrderWindowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditOrderWindowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditOrderWindowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
