import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort ,MatDialog} from '@angular/material';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import {Router} from '@angular/router';
import { Common } from '../../../../shared/service/common/common';

@Component({
  selector: 'app-list-order-window',
  templateUrl: './list-order-window.component.html',
  styleUrls: ['./list-order-window.component.scss']
})
export class ListOrderWindowComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;

  public orderWindowList = new MatTableDataSource();
  displayedColumns: string[] = ['sNo','name', 'season_name','start_date', 'end_date' ,'Actions'];

  constructor(private mastersService:MastersService, private router:Router,public dialog: MatDialog,public common: Common){
  }
  ngOnInit() {
    this.getOrderWindowListData();
  }
  applyFilter(filterValue: string) {
    this.orderWindowList.filter = filterValue.trim().toLowerCase();
  }
  public getOrderWindowListData(){
    this.mastersService.getlistOrderWindow().subscribe(sResponseModel => {
      // console.log('sResponseModel',sResponseModel);
      if(sResponseModel.status){
            this.orderWindowList.data =sResponseModel.data;
            this.orderWindowList.paginator = this.paginator;
        }
      else{
        this.common.openSnackBar('No Data Found','', 'danger-snackbar');
      }
    },
    sError => {
      this.common.apiError(sError);
    });
  }
  public editOrderWindow(id){
    const editId = btoa(id);
    this.router.navigate(['masters/editOrderWindow'],{queryParams:{editId}});
  }
  public deleteOrderWindow(orderWindowId){
    this.common.openConfirmDialog('Are you sure to delete this Order Window ?')
    .afterClosed().subscribe(res =>{
    if(res){
      let orderIndex=this.orderWindowList.data.findIndex(key=>key['id'] == orderWindowId)
      this.mastersService.getDeleteOrderWindow(orderWindowId).subscribe((data)=>{
        // console.log("sResponseModel",data);
        if(data.status){
          // console.log('orderWindowList',this.orderWindowList.data);
          this.orderWindowList.data.splice(orderIndex,1);
          this.orderWindowList.data = this.orderWindowList.data;
          this.common.openSnackBar('Order Window Deleted Successfully','', 'success-snackbar');
        }
        else{
          this.common.openSnackBar('Could Not Delete Order Window','', 'danger-snackbar');
        }
      },
      sError => {
        this.common.apiError(sError);
      });
    }
    });
  }
}
