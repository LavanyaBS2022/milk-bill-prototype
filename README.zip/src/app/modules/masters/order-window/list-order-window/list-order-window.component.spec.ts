import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListOrderWindowComponent } from './list-order-window.component';

describe('ListOrderWindowComponent', () => {
  let component: ListOrderWindowComponent;
  let fixture: ComponentFixture<ListOrderWindowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListOrderWindowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListOrderWindowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
