import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Common } from '../../../../shared/service/common/common';

@Component({
  selector: 'app-add-order-window',
  templateUrl: './add-order-window.component.html',
  styleUrls: ['./add-order-window.component.scss']
})
export class AddOrderWindowComponent implements OnInit {
  public orderWindowAddForm : FormGroup;
  public submitted = false;
  public isDuplicateFound: boolean = false;
  public maxDate ;
  public minDate;
  public seasonListDropdown;
  public orderwindoType=[
    {id:1,name:"FW"},
    {id:2,name:"APEQ"}
  ];
  constructor(private formBuilder: FormBuilder, public mastersService:MastersService,public router: Router,public common: Common) { 
    this.getSeasonListDropdown();
  }
  getSeasonListDropdown(){
    this.mastersService.getlistSeason().subscribe((data)=>{
      // console.log('dropdown',data.data);
      this.seasonListDropdown=data.data;
    },
    sError => {
      this.common.apiError(sError);
    });
  }
  updateMaxDate(){
    this.maxDate =new Date(this.get.endDate.value);
    this.maxDate.setDate( this.maxDate.getDate() - 1 );
  }
  updateMinDate(){
    this.minDate = new Date(this.get.startDate.value);
    this.minDate.setDate( this.minDate.getDate() + 1 );
  }
  ngOnInit() {
  
    this.orderWindowAddForm = this.formBuilder.group({
      orderWindowName : ['', Validators.required] ,
      seasonId :  ['', Validators.required] ,
      startDate :  ['', Validators.required] ,
      endDate :  ['', Validators.required],
      owtypeId :  ['']
    });
  }
  get get() { return this.orderWindowAddForm.controls; }

  onSubmit(){
    this.submitted = true;
    //  console.log(this.orderWindowAddForm.controls.orderWindowName.invalid);
    if (this.orderWindowAddForm.invalid) {
      this.common.openSnackBar('Please fill all the mandatory fields','', 'danger-snackbar');
      return;
    }
    else{
      const postData = {
          "orderWindowName"	        : this.get.orderWindowName.value,
          "seasonId"         : this.get.seasonId.value,
          "startDate"       : this.get.startDate.value,
          "endDate"         : this.get.endDate.value,
          "createdUser"          : 1,
          "createdDate"          : new Date(),
          "status"        : 1,
          "order_window_type":this.get.owtypeId.value
      };
      // console.log('postData',postData);
      // return;
      this.mastersService.postAddOrderWindow(postData).subscribe((data)=>{
         console.log('data',data);
        if(data.status){
          this.router.navigate(['masters/listOrderWindow']);
          this.common.openSnackBar('New Order Window Added Successfully','', 'success-snackbar');
        }
        else{
          this.common.openSnackBar('New Order Window Added UnSuccessfully','', 'danger-snackbar');
        }
      },
      sError => {
        this.common.apiError(sError);
      });
    }
    
  }

  reset(){
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
    this.orderWindowAddForm.reset();
  }
  

}
