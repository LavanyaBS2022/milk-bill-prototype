import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddOrderWindowComponent } from './add-order-window.component';

describe('AddOrderWindowComponent', () => {
  let component: AddOrderWindowComponent;
  let fixture: ComponentFixture<AddOrderWindowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddOrderWindowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddOrderWindowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
