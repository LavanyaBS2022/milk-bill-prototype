import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Common } from '../../../../shared/service/common/common';

@Component({
  selector: 'app-edit-season',
  templateUrl: './edit-season.component.html',
  styleUrls: ['./edit-season.component.scss']
})
export class EditSeasonComponent implements OnInit {
  public seasonEditForm : FormGroup;
  public editId;
  public submitted = false;
  public isDuplicateFound: boolean = false;
  public maxDate ;
  public minDate;
  public seasonTypeDropdown;
  public editedData;

  constructor(private formBuilder: FormBuilder,public route :ActivatedRoute, public mastersService:MastersService,public router: Router,public common: Common) { 
    this.route.queryParams.subscribe(params=>{
      this.editId   = (atob(params.editId));
      this.getSeasonTypeDropDown();
      this.getEditSeasonData(this.editId);
    });
  }

  ngOnInit() {
    this.seasonEditForm = this.formBuilder.group({
      seasonType : ['', Validators.required] ,
      seasonName :  ['', Validators.required] ,
      seasonCode : ['', [Validators.required],this.validateSeasonCode.bind(this)],
      fromDate :  ['', Validators.required] ,
      toDate :  ['', Validators.required]
    });
  }
  updateMaxDate() {
    this.maxDate = new Date(this.get.toDate.value);
    this.maxDate.setDate(this.maxDate.getDate() - 1);
  }
  updateMinDate() {
    this.minDate = new Date(this.get.fromDate.value);
    this.minDate.setDate(this.minDate.getDate() + 1);
  }
  get get() { return this.seasonEditForm.controls; }
  validateSeasonCode(control : FormControl)
  {
    const q = new Promise((resolve, reject) => {
        this.mastersService.getValidateSeasonCode(control.value).subscribe((data)=>{
          // console.log('validateSeasonCode',data.data)
          if(data.data == true && this.editedData[0].code!=this.get.seasonCode.value){
            this.isDuplicateFound = true;
            resolve({ 'isSeasonCodeExist': 'This Season Code is already Taken'  })
          }
          else{
            this.isDuplicateFound = false;
            resolve(null)
          }
        },
        sError => {
            this.common.apiError(sError);
        });
    });
    return q;
}
  getSeasonTypeDropDown(){
    this.mastersService.getSeasonTypelist().subscribe((data)=>{
      // console.log('dropdown',data.data);
      this.seasonTypeDropdown=data.data;
    },
    sError => {
        this.common.apiError(sError);
    });
  }
  onSubmit(){
    // console.log(new Date('2012-03-21'));
    this.submitted = true;
    if (this.seasonEditForm.invalid) {
      this.common.openSnackBar('Please fill all the mandatory fields','', 'danger-snackbar');
      return;
  }
  else{
    // console.log(this.seasonEditForm.value);
    // const postData = JSON.parse(JSON.stringify(this.seasonEditForm.value));
    const bindData = {
        "seasonId"  : this.editId,
        "seasonType": this.get.seasonType.value,
        "seasonName": this.get.seasonName.value,
        "seasonCode": this.get.seasonCode.value,
        "fromDate"  : new Date(this.get.fromDate.value),
        "toDate"    : new Date(this.get.toDate.value), 
        "createdUser": 1,
        "createdDate": new Date(),
        "status"     : 1
    };
    this.mastersService.postEditSeason(bindData).subscribe((data)=>{
      console.log('data',data);
      if(data.status){
        this.router.navigate(['masters/list-season']);
        this.common.openSnackBar('Season Updated Successfully','', 'success-snackbar');
      } 
      else{
        this.common.openSnackBar('Could Not Update Season','', 'danger-snackbar');
      }
    },
    sError => {
        this.common.apiError(sError);
    });
  }
   
  }
  getEditSeasonData(editId){


    // console.log(editId);
    this.mastersService.getlistSeasonById(editId).subscribe((data)=>{
      this.editedData =  data.data;
      // console.log(data.data);
      // console.log( 'season type',this.editedData[0].name)
      // this.seasonEditForm.patchValue({
      //   seasonType: res[0].season_type,
      //   seasonName : res[0].season_name
      // });


      this.seasonEditForm.patchValue({
        seasonName: this.editedData[0].name,
        seasonCode:this.editedData[0].code,
        fromDate:this.editedData[0].from_date,
        toDate:this.editedData[0].to_date,
        seasonType :this.editedData[0].season_type,
      });
      // this.updateMaxDate();
      // this.updateMinDate();
        //  this.minDate = new Date(this.editedData[0].from_date);
        //  console.log("min date",this.minDate )
        // this.minDate.setDate( this.minDate.getDate() + 1 );

        // this.maxDate =new Date(this.editedData[0].to_date);
        // this.maxDate.setDate( this.maxDate.getDate() - 1 );
      // this.router.navigate(['masters/list-season']);
    },
    sError => {
        this.common.apiError(sError);
    });
  }
  reset(){
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
    this.seasonEditForm.reset();
  }


}
