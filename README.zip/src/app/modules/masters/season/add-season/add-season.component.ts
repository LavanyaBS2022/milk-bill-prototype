import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Common } from '../../../../shared/service/common/common';

@Component({
  selector: 'app-add-season',
  templateUrl: './add-season.component.html',
  styleUrls: ['./add-season.component.scss']
})
export class AddSeasonComponent implements OnInit {
  public seasonAddForm: FormGroup;
  public submitted = false;
  public isDuplicateFound: boolean = false;
  public maxDate;
  public minDate;
  public seasonTypeDropdown;
  constructor(private formBuilder: FormBuilder, public mastersService: MastersService, public router: Router, public common: Common) {
    this.getSeasonTypeDropDown();
  }
  getSeasonTypeDropDown() {
    // console.log("reached");
    this.mastersService.getSeasonTypelist().subscribe((data) => {
      // console.log('dropdown', data);
      this.seasonTypeDropdown = data.data;
    })
  }
  updateMaxDate() {
    this.maxDate = new Date(this.get.toDate.value);

    this.maxDate.setDate(this.maxDate.getDate() - 1);
  }
  updateMinDate() {
    this.minDate = new Date(this.get.fromDate.value);
    // console.log("min date",this.minDate )

    this.minDate.setDate(this.minDate.getDate() + 1);
  }
  ngOnInit() {

    this.seasonAddForm = this.formBuilder.group({
      seasonType: ['', Validators.required],
      seasonName: ['', Validators.required],
      seasonCode: ['', [Validators.required], this.validateSeasonCode.bind(this)],
      fromDate: ['', Validators.required],
      toDate: ['', Validators.required]
    });
  }
  get get() { return this.seasonAddForm.controls; }

  validateSeasonCode(control: FormControl) {
    const q = new Promise((resolve, reject) => {
      this.mastersService.getValidateSeasonCode(control.value).subscribe((data) => {
        // console.log('validateSeasonCode', data.data)
        if (data.data == true) {
          this.isDuplicateFound = true;
          resolve({ 'isSeasonCodeExist': 'This Season Code is already Taken' })
        }
        else {
          this.isDuplicateFound = false;
          resolve(null)
        }
      },
      sError => {
          this.common.apiError(sError);
      });
    });
    return q;
  }
  onSubmit() {
    this.submitted = true;
    // console.log(this.seasonAddForm.controls.seasonCode.invalid);
    if (this.seasonAddForm.invalid) {
      this.common.openSnackBar('Please fill all the mandatory fields','', 'danger-snackbar');
      return;
    }
    else {
      const postData = {
        "seasonType": this.get.seasonType.value,
        "seasonName": this.get.seasonName.value,
        "seasonCode": this.get.seasonCode.value,
        "fromDate": this.get.fromDate.value,
        "toDate": this.get.toDate.value,
        "createdUser": 1,
        "createdDate": new Date(),
        "status": 1
      };
      // console.log('postData', postData);
      // return;
      this.mastersService.postAddSeason(postData).subscribe((data) => {
        console.log(data);
        if(data.status){
          this.router.navigate(['masters/list-season']);
          this.common.openSnackBar('New Season Added Successfully','', 'success-snackbar');
        }
        else{
          this.common.openSnackBar('Could Not Add Season','', 'danger-snackbar');
        }
      },
      sError => {
          this.common.apiError(sError);
      });
    }

  }

  reset() {
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
    this.seasonAddForm.reset();
  }

}
