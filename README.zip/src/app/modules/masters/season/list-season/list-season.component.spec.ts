import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListSeasonComponent } from './list-season.component';

describe('ListSeasonComponent', () => {
  let component: ListSeasonComponent;
  let fixture: ComponentFixture<ListSeasonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListSeasonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListSeasonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
