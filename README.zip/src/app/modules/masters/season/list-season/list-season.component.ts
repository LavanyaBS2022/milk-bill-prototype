import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort ,MatDialog} from '@angular/material';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import {Router} from '@angular/router';
import { Common } from '../../../../shared/service/common/common';

@Component({
  selector: 'app-list-season',
  templateUrl: './list-season.component.html',
  styleUrls: ['./list-season.component.scss']
})
export class ListSeasonComponent implements OnInit {
  
  @ViewChild(MatPaginator) paginator: MatPaginator;

  public seasonList = new MatTableDataSource();
  // public seasonActiveStatus:boolean = false;
  public seasonActiveStatus=[];
  displayedColumns: string[] = ['sNo','name', 'from_date', 'to_date' ,'Actions'];

  displayedColumns2: string[] = ['position', 'name', 'weight', 'symbol'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  public data =[];

  constructor(private mastersService:MastersService, private router:Router,public dialog: MatDialog,public common: Common){
  }


  ngOnInit() {
    this.getSeasonListData();
    this.dataSource.paginator = this.paginator;
  }
  applyFilter(filterValue: string) {
    this.seasonList.filter = filterValue.trim().toLowerCase();
  }
  public getSeasonListData(){
    // console.log("reached");
    this.mastersService.getlistSeason().subscribe(
      sResponseModel => {
        //  console.log("sResponseModel.data",sResponseModel);
          if(sResponseModel.status){
            this.data=sResponseModel.data;
            //filter season id which is active and set toggle as true
            let filterActiveSeason=sResponseModel.data.find(item=>item.active_season==1);
            if(filterActiveSeason!=undefined){
              this.seasonActiveStatus[filterActiveSeason.id]=true;
            }
            this.seasonList.data =sResponseModel.data;
            this.seasonList.paginator = this.paginator;
          }
          else{
            this.common.openSnackBar('No record found','', 'danger-snackbar');
          }
      },
      sError => {
        this.common.apiError(sError);
      });
  }
  public editSeason(id){
    const editId = btoa(id);
    this.router.navigate(['masters/edit-season'],{queryParams:{editId}});
  }
  public deleteSeason(seasonId){
    this.common.openConfirmDialog('Are you sure to delete this Season ?')
    .afterClosed().subscribe(res =>{
    if(res){
      let seasonIndex=this.seasonList.data.findIndex(key=>key['id'] == seasonId)
      this.mastersService.getDeleteSeason(seasonId).subscribe((data)=>{
        if(data.status){
          this.seasonList.data.splice(seasonIndex,1);
          this.seasonList.data = this.seasonList.data;
          this.common.openSnackBar('Season Deleted Successfully','', 'success-snackbar');
        }
        else{
          this.common.openSnackBar('Could Not Deleted This Season','', 'danger-snackbar');
        }
      },
      sError => {
          this.common.apiError(sError);
      });
    }
    });
  }

  updateSeasonActiveStatus(seasonId){
    
    // console.log("this.data",this.data);
    
    let status=0;
    if(this.seasonActiveStatus[seasonId]==true){
      status = 1
    }
    // console.log("seasonId",seasonId);
    // console.log("active status",this.seasonActiveStatus[seasonId]);
    // console.log("filtered ",this.data.filter(x=>x.active_season==1));
    let activeSeasonList=this.data.filter(x=>x.active_season==1); 
    // console.log("activeSeasonList",activeSeasonList[0].id)
    // console.log("seasonId",seasonId)

     //if already any season is active
     if(activeSeasonList.length>0 && activeSeasonList[0].id!=seasonId){
      this.seasonActiveStatus[seasonId]=false;
      this.common.openSnackBar('Already '+activeSeasonList[0].name+' season is active','', 'danger-snackbar');
    }
    else{
      let obj={
        active_season:status,
        seasonId:seasonId
      }
      this.mastersService.updateActiveSeasonStatus(obj).subscribe(sResponseModel => {
        // console.log('this.data.filter(item=>item.id==seasonId)',this.data.filter(item=>item.id==seasonId));
        let test = this.data.filter(item=>item.id==seasonId);
        test[0].active_season=status;
        // console.log("this.data",this.data)
        // console.log('sResponseModel',sResponseModel);
      },
      sError => {
        this.common.apiError(sError);
      });
    }
  }
}
export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
  {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He'},
  {position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li'},
  {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
  {position: 5, name: 'Boron', weight: 10.811, symbol: 'B'},
  {position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C'},
  {position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N'},
  {position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O'},
  {position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F'},
  {position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne'},
  {position: 11, name: 'Sodium', weight: 22.9897, symbol: 'Na'},
  {position: 12, name: 'Magnesium', weight: 24.305, symbol: 'Mg'},
  {position: 13, name: 'Aluminum', weight: 26.9815, symbol: 'Al'},
  {position: 14, name: 'Silicon', weight: 28.0855, symbol: 'Si'},
  {position: 15, name: 'Phosphorus', weight: 30.9738, symbol: 'P'},
  {position: 16, name: 'Sulfur', weight: 32.065, symbol: 'S'},
  {position: 17, name: 'Chlorine', weight: 35.453, symbol: 'Cl'},
  {position: 18, name: 'Argon', weight: 39.948, symbol: 'Ar'},
  {position: 19, name: 'Potassium', weight: 39.0983, symbol: 'K'},
  {position: 20, name: 'Calcium', weight: 40.078, symbol: 'Ca'},
];