import { Component, OnInit } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { saveAs } from 'file-saver';
import { MastersService } from '../../../shared/service/masters/masters.service';
import { Common } from '../../../shared/service/common/common';
@Component({
  selector: 'app-export-master',
  templateUrl: './export-master.component.html',
  styleUrls: ['./export-master.component.scss']
})
export class ExportMasterComponent implements OnInit {
  public seasonId;
  public orderWindowId;
  public brandId;
  private userDetails: any;
  constructor(private maseterService: MastersService, private common: Common) { }
  public sug_article = false;
  public orderWindowType:any;

  ngOnInit() {
    this.userDetails = this.common.getUserDetails();
    // console.log(this.userDetails);
    this.seasonId = this.userDetails.seasonId;
    this.orderWindowId = this.userDetails.orderWindowId;
    this.brandId = this.userDetails.brandId;
    this.orderWindowType = this.userDetails.orderWindowType;
  }

  exportMasters(form: NgForm) {
    if (!form.value.mType) {
      this.common.openSnackBar('Please select any one option!!!', '', 'danger-snackbar');
    }
    else {
      this.common.showSpinner();
      let fileType = form.value.mType;
      let seasonId: any = this.seasonId;
      let orderWindowId: any = this.orderWindowId;
      let suggested_article = 0;
      if (this.sug_article == true) {
        suggested_article = 1;
      }
      const seasonName = (this.userDetails.seasonName) ? this.userDetails.seasonName : '';
      const orderWindowName = (this.userDetails.orderWindowName) ? this.userDetails.orderWindowName : '';
      const sheetName = seasonName ;
      // + orderWindowName
      this.maseterService.exportOrders(
        fileType, seasonId,
        orderWindowId,
        this.brandId,
        this.userDetails.countryId,
        this.userDetails.franchiseDetails.franchise_name,
        this.userDetails.franchiseDetails.franchise_code,
        suggested_article,
        this.userDetails.franchiseId,
        sheetName
      ).subscribe((sResponse: any) => {
        // console.log(sResponse);
        if (sResponse) {
          const seasonName = (this.userDetails.seasonName) ? this.userDetails.seasonName + '_' : '';
          const orderWindowId = (this.userDetails.orderWindowName) ? this.userDetails.orderWindowName + '_' : '';
          let fileTypeName = '';
          if(fileType == 'footwareConsolidatedOrders'){
            fileTypeName = 'Footwear Consolidated Orders';
          }
          else{
            fileTypeName = 'Apparel Equipment Consolidated Orders';
          }
          const fileName = seasonName + orderWindowId + fileTypeName;
          saveAs(sResponse, fileName + '.xlsx');
          this.common.openSnackBar('File Downloaded!!!', '', 'success-snackbar');
          this.common.hideSpinner();
        }
      },
        sError => {
          // console.log("error",sError);
          this.common.openSnackBar('Could not Downloaded File!!!', '', 'danger-snackbar');
          this.common.hideSpinner();
        });
    }
  }

}
