import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Router } from '@angular/router';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-list-division',
  templateUrl: './list-division.component.html',
  styleUrls: ['./list-division.component.scss']
})
export class ListDivisionComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  public divisionList_datasource = new MatTableDataSource();
  divisionDisplayedColumns: string[] = ['SNo', 'name', 'shortname', 'action'];

  constructor(private masterService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService) { }

  ngOnInit() {
    this.getDivisionList();
  }

  public getDivisionList() {
    this.spinner.show();
    this.masterService.getListDivision().subscribe(
      sResponseModel => {
        this.spinner.hide();
        if (sResponseModel.data) {
          this.divisionList_datasource.data = sResponseModel.data;
          this.divisionList_datasource.paginator = this.paginator;
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public editDivision(id) {
    // console.log('Edit Method Called id is:', id);
    const editId = btoa(id);
    this.router.navigate(['masters/editDivision'], { queryParams: { editId } });
  }

  public deleteDivision(divisionId) {
    this.common.openConfirmDialog('Are you sure to delete this Division ?')
      .afterClosed().subscribe(res => {
        if (res) {
          let divisionIndex = this.divisionList_datasource.data.findIndex(key => key['id'] == divisionId)
          this.masterService.getDeleteDivision(divisionId).subscribe((data) => {
            if (data.data) {
              this.divisionList_datasource.data.splice(divisionIndex, 1);
              this.divisionList_datasource.data = this.divisionList_datasource.data;
              this.common.openSnackBar('Division Deleted Successfully', '', 'success-snackbar');
            }
            else {
              this.common.openSnackBar('Could Not Delete This Division', '', 'danger-snackbar');
            }
          },
          sError => {
            this.common.apiError(sError);
          })
        }
      });
  }

  applyFilter(filterValue: string) {
    this.divisionList_datasource.filter = filterValue.trim().toLowerCase();
  }

}
