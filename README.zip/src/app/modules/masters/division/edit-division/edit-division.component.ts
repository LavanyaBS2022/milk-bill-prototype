import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";


@Component({
  selector: 'app-edit-division',
  templateUrl: './edit-division.component.html',
  styleUrls: ['./edit-division.component.scss']
})
export class EditDivisionComponent implements OnInit {

  public divisionEditForm: FormGroup;
  public isSubmitted: boolean = false;
  public editDivisionID: any;
  public editDivisionData: any;

  constructor(private formBuilder: FormBuilder, public route: ActivatedRoute, public mastersService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService) {
    this.route.queryParams.subscribe(params => {
      this.editDivisionID = (atob(params.editId));
      this.getEditDivisionData(this.editDivisionID);
    });
  }

  ngOnInit() {
    this.divisionEditForm = this.formBuilder.group({
      divisionName: ['', [Validators.required, Validators.maxLength(50)]],
      divisionShortName: ['', [Validators.required, Validators.maxLength(50)]]
    });
  }

  public get get() {
    return this.divisionEditForm.controls;
  }

  getEditDivisionData(editId: any) {
    this.mastersService.getListDivisionbyId(editId).subscribe((data) => {
      this.editDivisionData = data.data;

      this.divisionEditForm.patchValue({
        divisionName: this.editDivisionData[0].name,
        divisionShortName: this.editDivisionData[0].short_name
      });
    },
    sError => {
      this.common.apiError(sError);
    });
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.divisionEditForm.get("divisionName").value.trim() == "") {
      return this.divisionEditForm.controls["divisionName"].setErrors({ emptyValidateError: "This filed is mandatory" });
    }
    if (this.divisionEditForm.get("divisionShortName").value.trim() == "") {
      return this.divisionEditForm.controls["divisionShortName"].setErrors({ emptyValidateError: "This filed is mandatory" });
    }

    if (this.divisionEditForm.valid && this.divisionEditForm.get("divisionName").value.trim() != "") {
      this.spinner.show();
      this.divisionEditForm.value['editDivisionId'] = this.editDivisionID;
      const postData = JSON.parse(JSON.stringify(this.divisionEditForm.value));
      this.mastersService.postUpdateDivision(postData).subscribe((data) => {
        this.spinner.hide();
        if (data.status) {
          this.router.navigate(['masters/listDivision']);
          this.common.openSnackBar('Division Updated Successfully', '', 'success-snackbar');
        }
        else {
          this.divisionEditForm.controls["divisionName"].setErrors({ serverValidateError: "This division is already exist. Try with different name" });
        }
      },
      sError => {
        this.common.apiError(sError);
      })
    }
  }

  onReset() {
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
    this.isSubmitted = false;
    this.divisionEditForm.reset();
  }


}
