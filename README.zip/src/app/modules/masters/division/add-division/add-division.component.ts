import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormGroup, FormBuilder, FormControl, Validators } from "@angular/forms";
import { MastersService } from "./../../../../shared/service/masters/masters.service";
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-add-division',
  templateUrl: './add-division.component.html',
  styleUrls: ['./add-division.component.scss']
})
export class AddDivisionComponent implements OnInit {

  public divisionAddForm: FormGroup;
  public isSubmitted: boolean = false;

  constructor(private formBuilder: FormBuilder, public masterService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService) {

  }

  ngOnInit() {
    this.divisionAddForm = this.formBuilder.group({
      divisionName: ['', [Validators.required, Validators.maxLength(50)]],
      divisionShortName: ['', [Validators.required, Validators.maxLength(50)]]
    });
  }

  public get get() {
    return this.divisionAddForm.controls;
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.divisionAddForm.get("divisionName").value.trim() == "") {
      return this.divisionAddForm.controls["divisionName"].setErrors({ emptyValidateError: "This Field is mandatory" });
    }
    if (this.divisionAddForm.get("divisionShortName").value.trim() == "") {
      return this.divisionAddForm.controls["divisionShortName"].setErrors({ emptyValidateError: "This Field is mandatory" });
    }

    if (this.divisionAddForm.valid && this.divisionAddForm.get("divisionName").value.trim() != "") {
      this.spinner.show();
      const postData = JSON.parse(JSON.stringify(this.divisionAddForm.value));
      this.masterService.postAddDivision(postData).subscribe((data) => {
        this.spinner.hide();
        if (data.status) {
          this.router.navigate(['masters/listDivision']);
          this.common.openSnackBar('Division Added Successfully', '', 'success-snackbar');
        }
        else {
          this.divisionAddForm.controls["divisionName"].setErrors({ serverValidateError: "This division is already exist. Try with different name" });
        }
      },
      sError => {
        this.common.apiError(sError);
      });
    }
  }

  onReset() {
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
    this.isSubmitted = false;
    this.divisionAddForm.reset();
  }

}
