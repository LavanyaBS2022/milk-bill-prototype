import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, NgForm, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { MastersService } from '../../../shared/service/masters/masters.service';
import { ActivatedRoute } from '@angular/router';
import { Common } from '../../../shared/service/common/common';

@Component({
  selector: 'app-article-list',
  templateUrl: './article-list.component.html',
  styleUrls: ['./article-list.component.scss']
})
export class ArticleListComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  public articleList_datasource = new MatTableDataSource();
  articleListDisplayedColumns: string[] = ['sku', 'articleDesc', 'distTier', 'brand', 'silo1', 'silo2', 'sizeGroup', 'moq', 'mandatory','action']//, 'image']; //, 'action'];

  public articleListFilterForm: FormGroup;

  public submitted:boolean;
  public seasonList = [];
  public orderWindowList = [];
  public seasonId: any = '';
  public orderWindowId: any = '';
  public divisionId: any = '';
  public genderId: any = '';
  public category1Id: any = '';
  public category4Id: any = '';
  public brandList = [];
  public divisionList = [];
  public genderList = [];
  public category1List = [];
  public category4List = [];
  
  constructor(private formBuilder: FormBuilder, private masterService: MastersService, private route: ActivatedRoute, private common: Common) { }

  public text: any = 'Show Filter';
  public changeText(): void {
    if (this.text === 'Collapse Filter') {
      this.text = 'Show Filter';
    } else {
      this.text = 'Collapse Filter';
    }
  }
  step = 0;
  setStep(index: number) {
    this.step = index;
  }
  nextStep() {
    this.step++;
  }
  prevStep() {
    this.step--;
  }

  ngOnInit() {
    let userDetails = this.common.getUserDetails();
    this.generateArticleListFormFilter();
    this.getSeasons();
  }

  applyFilter(filterValue: string) {
    this.articleList_datasource.filter = filterValue.trim().toLowerCase();
  }

  

  generateArticleListFormFilter() {
    this.articleListFilterForm = this.formBuilder.group({
      seasonId: ['', Validators.required],
      orderWindowId: ['',Validators.required],
      divisionId: [''],
      genderId: ['',],
      category1Id: [''],
      category4Id: [''],
    });
   
  }


  public get get() {
    return this.articleListFilterForm.controls;
  }

  getSeasons() {
    this.masterService.getlistSeason().subscribe((sRespone: any) => {
      // // console.log('seasons', sRespone.data);
      this.seasonList = sRespone.data;
      
    })
  }

  getOrderWindowList(value) {
    this.seasonId=value;
    const onlyActive = 0;
    this.masterService.getOrderWindowSeasonList(onlyActive).subscribe((data) => {
      // // console.log('getOrderWindowList', data.data);
      let result = data.data;
      this.orderWindowList = result.filter(item => item.season_id == this.seasonId);
      // // console.log('orderWindowList', this.orderWindowList);
    },
    sError => {
      this.common.apiError(sError);
    });
  }

  public getDivisionListSeasonOwWise(value?) {
    this.orderWindowId=value;
    this.masterService.getDivisionListSeasonOwWise(this.seasonId, this.orderWindowId).subscribe(
      sResponseModel => {
         //console.log('Division DropDown Data:', sResponseModel.data);
        if (sResponseModel.data) {
          this.divisionList = sResponseModel.data;
        }
      },
      sError => {
        this.common.apiError(sError);
      });
  }

  public getGenderListSeasonOwWise(value) {
    this.divisionId=value;
    this.masterService.getGenderListSeasonOwWise(this.seasonId, this.orderWindowId, this.divisionId).subscribe(
      sResponseModel => {
        // console.log('Gender DropDown Data:', sResponseModel.data);
        if (sResponseModel.data) {
          this.genderList = sResponseModel.data;
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public getCategory1ListSeasonOwWise(value) {
    this.genderId=value;
    this.masterService.getCategory1ListSeasonOwWise(this.seasonId, this.orderWindowId, this.divisionId, this.genderId).subscribe(
      sResponseModel => {
        // console.log('Category1 DropDown Data:', sResponseModel.data);
        if (sResponseModel.data) {
          this.category1List = sResponseModel.data;
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public getCategory4ListSeasonOwWise(val) {
    this.category1Id=val;
    this.masterService.getCategory4ListSeasonOwWise(this.seasonId, this.orderWindowId, this.divisionId, this.genderId, this.category1Id).subscribe(
      sResponseModel => {
        // console.log('Category4 DropDown Data:', sResponseModel.data);
        if (sResponseModel.data) {
          this.category4List = sResponseModel.data;
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }
  setCat4(val){
    this.category4Id=val;
  }

  onSubmitArticle() {
    this.submitted = true;
    // console.log('form invalid', this.articleListFilterForm.invalid);
    if (this.articleListFilterForm.valid) {
      this.masterService.getArticleListSeasonOwWise(this.seasonId, this.orderWindowId, this.divisionId, this.genderId, this.category1Id, this.category4Id).subscribe(
        sResponseModel => {
          // console.log('ArticleList Data:', sResponseModel.data);
          if (sResponseModel.data) {
            this.articleList_datasource.data = sResponseModel.data;
            this.articleList_datasource.paginator = this.paginator;
          }
        },
        sError => {
          this.common.apiError(sError);
        }
      );
    }
    else {
      this.common.openSnackBar('Please select All the Mandatory Fields', '', 'danger-snackbar');
      //this.common.hideSpinner();
    }

  }

  clearData(){
    this.orderWindowList = [];
    this.divisionList = [];
    this.genderList = [];
    this.category1List = [];
    this.category4List = [];
    this.orderWindowId='';
    this.divisionId='';
    this.genderId='';
    this.category1Id='';
    this.category4Id='';
  
  }

  

}
