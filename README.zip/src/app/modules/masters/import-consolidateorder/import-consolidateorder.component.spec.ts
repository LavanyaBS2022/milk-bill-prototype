import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportConsolidateorderComponent } from './import-consolidateorder.component';

describe('ImportConsolidateorderComponent', () => {
  let component: ImportConsolidateorderComponent;
  let fixture: ComponentFixture<ImportConsolidateorderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportConsolidateorderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportConsolidateorderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
