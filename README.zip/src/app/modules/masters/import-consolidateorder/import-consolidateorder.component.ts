import { Component, OnInit } from '@angular/core';
import { MastersService } from '../../../shared/service/masters/masters.service';
import { OrdersService } from '../../../shared/service/orders/orders.service';
import { Common } from '../../../shared/service/common/common';
import { TargetService } from '../../../shared/service/orders/target/target.service';
@Component({
  selector: 'app-import-consolidateorder',
  templateUrl: './import-consolidateorder.component.html',
  styleUrls: ['./import-consolidateorder.component.scss']
})
export class ImportConsolidateorderComponent implements OnInit {
  public seasonId;
  public orderWindowId;
  public getmessage;
  public consolidatefileData;
  public ConsolidatefileType: string = 'footwareConsolidatedOrders';
  public storeId;
  public franchiseId;
  public storeList = [];
  public orderId;
  public brandId;
  public countryId;
  public ratio;
  public orderStatus;
  private sheetName;
  public moqStatus;
  constructor(private maseterService: MastersService, private orderService: OrdersService,
    private common: Common, private targetService: TargetService) { }

  ngOnInit() {
    const userDetails = this.common.getUserDetails();
    const seasonName = (userDetails.seasonName) ? userDetails.seasonName : '';
    const orderWindowName = (userDetails.orderWindowName) ? userDetails.orderWindowName : '';
    this.sheetName = seasonName;
    // + orderWindowName
    this.seasonId = userDetails.seasonId;
    this.orderWindowId = userDetails.orderWindowId;
    this.franchiseId = userDetails.franchiseId;
    this.brandId = userDetails.brandId;
    this.countryId = userDetails.countryId;
    this.ratio = userDetails.franchiseDetails.ratio;
    this.moqStatus=userDetails.moqStatus;
    this.getStores();
  }

  fileInputChange(fileInputEvent: any, typeFor?: any) {
    if (fileInputEvent.target.files.length > 0) {
      this.consolidatefileData = fileInputEvent.target.files[0];
    }
  }

  importConsolidateData() {

    // // console.log(this.storeId);
    // return;
    if (!this.seasonId && !this.orderWindowId) {
      this.common.openSnackBar('Please select the Season / Orderwindow', '', 'danger-snackbar');
    } else {
      this.common.showSpinner();
      let form = new FormData();
      let seasonId: any = this.seasonId;
      let orderWindowId: any = this.orderWindowId;
      let franchaiseId: any = this.franchiseId;
      form.append('fileName', this.consolidatefileData);
      form.append('seasonId', seasonId);
      form.append('orderWindowId', orderWindowId);
      form.append('fileType', this.ConsolidatefileType);
      form.append('storeId', this.storeId);
      form.append('franchaiseId', franchaiseId);
      form.append('orderId', this.orderId);
      form.append('brandId', this.brandId);
      form.append('countryId', this.countryId);
      form.append('ratio', this.ratio);
      form.append('sheetName', this.sheetName);
      form.append('moqStatus', this.moqStatus);
      this.maseterService.importConsolidateOrder(form).subscribe((sRespone: any) => {
        // console.log(sRespone);
        if (sRespone.data) {
          this.getmessage = sRespone.data;
          //console.log(this.getmessage);
          //this.common.openSnackBar('File Processed!!!', '', 'success-snackbar');
          this.common.hideSpinner();
        }
      },
        sError => {
          this.common.apiError(sError);
        });
    }

  }

  getStores() {
    this.common.showSpinner();
    this.orderService.getFranchiseStoreList(this.franchiseId, this.orderWindowId, this.seasonId, this.brandId)
      .subscribe((sResponse: any) => {
        // console.log('sResponse',sResponse);

        if (sResponse.data) {
          this.storeList = sResponse.data;
          this.common.hideSpinner();
        } else {
          this.common.openSnackBar('Stores not found', '', 'danger-snackbar');
          this.common.hideSpinner();
        }
        // console.log(sResponse);

      },
        sError => {
          this.common.apiError(sError);
          this.common.hideSpinner();
        });

  }

  checkOrder() {
    this.common.showSpinner();
    let findData = this.storeList.find(item => item.store_id = this.storeId);
    // // console.log('findData',findData);
    // return;
    this.targetService.getOrder(this.seasonId, this.orderWindowId, this.franchiseId, this.storeId, this.brandId)
      .subscribe((sResponse: any) => {
        //console.log('orderId',sResponse.data[0]);
        if (sResponse.data[0].id) {
          // // console.log(sResponse);
          this.orderId = sResponse.data[0].id;
          this.orderStatus = sResponse.data[0].order_status;
          console.log('status',this.orderStatus);
          this.getmessage = [];
          if (this.orderStatus == 3) {
            this.getmessage = [{ type: 'error', message: 'Order for this store is under review' }];
          }
          else if (this.orderStatus == 4) {
            this.getmessage = [{ type: 'error', message: 'Order for this store is Approved' }];
          }
          else{
            this.getmessage = [];
          }

          this.common.hideSpinner();
        } else {
          let obj = {
            franchise_id: this.franchiseId,
            season_id: this.seasonId,
            order_window_id: this.orderWindowId,
            store_id: this.storeId,
            brand_id: this.brandId
          }
          this.targetService.saveOreder(obj).subscribe((sResponse: any) => {
            // // console.log(sResponse);
            this.orderId = sResponse.data.insertedOrderId;
          });
          this.common.hideSpinner();
        }
      },
        sError => {
          this.common.apiError(sError);
        });
  }

}
