import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditFranchiseStoreComponent } from './edit-franchise-store.component';

describe('EditFranchiseStoreComponent', () => {
  let component: EditFranchiseStoreComponent;
  let fixture: ComponentFixture<EditFranchiseStoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditFranchiseStoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditFranchiseStoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
