import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { OrdersService } from './../../../../shared/service/orders/orders.service';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-edit-franchise-store',
  templateUrl: './edit-franchise-store.component.html',
  styleUrls: ['./edit-franchise-store.component.scss']
})
export class EditFranchiseStoreComponent implements OnInit {
  public franchiseStoreEditForm: FormGroup;
  public editId;
  public submitted = false;
  public isDuplicateFound: boolean = false;
  public editedData;
  public franchiseList;
  public brandList = [];
  public selectedBrand;

  constructor(private formBuilder: FormBuilder, public route: ActivatedRoute, public mastersService: MastersService, public router: Router, public ordersService: OrdersService, private common: Common,private spinner:NgxSpinnerService
    ) {
    this.route.queryParams.subscribe(params => {
      this.editId = (atob(params.editId));
      this.getFranchiseList();
      this.getEditFranchiseData(this.editId);

    });
  }
  getFranchiseList() {
    this.mastersService.getlistFranchise().subscribe((data) => {
      // console.log('data', data);
      this.franchiseList = data.data
      // this.router.navigate(['masters/listFranchiseStore']);
    },
    sError => {
      this.common.apiError(sError);
    });

  }

  public getBrandList(franchiseId) {
    // console.log('reached getBrandList', this.get.franchiseId.value);
    this.mastersService.getBrandListByFranchiseId(this.get.franchiseId.value, 1).subscribe(
      sResponseModel => {
        if (sResponseModel.data) {
          this.brandList = sResponseModel.data;
          // console.log('getBrandListByFranchiseId', sResponseModel.data);
        }
        else {
          this.brandList = []
        }
      }, sError => {
        this.common.apiError(sError);
      }
    );
  }
  ngOnInit() {
    this.franchiseStoreEditForm = this.formBuilder.group({
      storeType: ['', Validators.required],
      storeName: ['', Validators.required],
      storeCode: [''],
      contactPerson: [''],
      phoneNo: [''],
      mobile: [''],
      franchiseId: ['', Validators.required],
      email: [''],
      address: [''],
      brandId: ['',Validators.required],
    });
  }
  get get() { return this.franchiseStoreEditForm.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.franchiseStoreEditForm.invalid) {
      this.common.openSnackBar('Please fill all the mandatory fields','', 'danger-snackbar');
      return;
    }
    else {
      // console.log(this.franchiseStoreEditForm.value);
      // const postData = JSON.parse(JSON.stringify(this.seasonEditForm.value));
      const postData = {
        "franchiseStoreId": this.editId,
        "storeType": this.get.storeType.value,
        "storeName": this.get.storeName.value,
        "storeCode": this.get.storeCode.value,
        "contactPerson": this.get.contactPerson.value,
        "phoneNo": this.get.phoneNo.value,
        "mobile": this.get.mobile.value,
        "email": this.get.email.value,
        "franchiseId": this.get.franchiseId.value,
        "address": this.get.address.value,
        "updatedUser": 1,
        "updatedDate": new Date(),
        "brandId": this.get.brandId.value,
        "status": 1
      };
      this.spinner.show();
      this.mastersService.postEditFranchiseStore(postData).subscribe((data) => {
        // console.log("sResponseModel", data);
        this.spinner.hide();
        if(data.status){
          this.router.navigate(['masters/listFranchiseStore']);
          this.common.openSnackBar('Store Updated Successfully','', 'success-snackbar');
        }
        else{
          this.common.openSnackBar('Could Not Update Store','', 'danger-snackbar');
        }
      },
      sError => {
        this.common.apiError(sError);
      });
    }

  }
  getEditFranchiseData(editId) {
    // console.log(editId);
    this.mastersService.getlistFranchiseStoreById(editId).subscribe((data) => {
      //get brand list on pageLoad
      this.editedData = data.data;

      // // console.log( 'season type',this.editedData[0].franchise_id);
      // const type=2;
      // this.mastersService.getBrandListByFranchiseId(this.editedData[0].id,type).subscribe((res)=>{
      //   if(res.data){
      //     this.selectedBrand = res.data.map(a => a.brand_id);
      //     this.get.brandId.setValue(this.selectedBrand);
      //   }
      //   // console.log('res',res);
      // })
      this.franchiseStoreEditForm.patchValue({
        storeType: this.editedData[0].store_type,
        storeName: this.editedData[0].store_name,
        storeCode: this.editedData[0].store_code,
        mobile: this.editedData[0].mobile,
        email: this.editedData[0].email,
        address: this.editedData[0].address,
        franchiseId: this.editedData[0].franchise_id,
        contactPerson: this.editedData[0].contact_person,
        phoneNo: this.editedData[0].phone_no,
        brandId: this.editedData[0].brand_id
      });
      this.getBrandList(this.get.franchiseId.value);

      // this.router.navigate(['masters/list-season']);
    },
    sError => {
      this.common.apiError(sError);
    });
  }
  reset() {
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
    this.franchiseStoreEditForm.reset();
  }
  // checkAlreadyExistingBrand(event){
  //   // console.log("reached");

  //   let franchiseId= this.get.franchiseId.value;
  //   let brandId= this.get.brandId.value;
  //   let storeId=this.editId;
  //   this.mastersService.checkStoreHasAlreadyThisBrand(franchiseId,brandId,storeId).subscribe(
  //     sResponseModel => {        
  //         if(sResponseModel.data != false){
  //           // // console.log("sResponseModel.data",sResponseModel.data);
  //           // console.log('already existing');
  //         }
  //         else{
  //           // console.log('no record is existing ');
  //         }
  //     },
  //     sError => {
  //         // // console.log("Store Error",sError);
  //     }
  //   );
  // }

  // validateSeasonCode(control: FormControl) {
  //   const q = new Promise((resolve, reject) => {
  //     // console.log("reached validation");

  //     let franchiseId= this.get.franchiseId.value;
  //     let brandId= control.value;
  //     let storeId=this.editId;
  //     this.mastersService.checkStoreHasAlreadyThisBrand(franchiseId,brandId,storeId).subscribe(
  //       sResponseModel => {     
  //         if(sResponseModel.data != false){
  //           this.isDuplicateFound = true;
  //           resolve({ 'isSeasonCodeExist': 'Already Brand Selected ' })
  //         }
  //         else {
  //           this.isDuplicateFound = false;
  //           resolve(null)
  //         }   
  //       },
  //       sError => {
  //           // // console.log("Store Error",sError);
  //       }
  //     );
  //   });
  //   return q;
  // }
}
