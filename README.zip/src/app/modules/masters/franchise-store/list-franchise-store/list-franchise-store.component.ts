import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Router } from '@angular/router';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-list-franchise-store',
  templateUrl: './list-franchise-store.component.html',
  styleUrls: ['./list-franchise-store.component.scss']
})
export class ListFranchiseStoreComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;

  public franchiseStoreList = new MatTableDataSource();
  displayedColumns: string[] = ['sNo', 'name', 'code', 'mobile', 'contactPerson', 'email', 'Actions'];

  constructor(private mastersService: MastersService, private router: Router, public dialog: MatDialog, private common: Common,private spinner:NgxSpinnerService) {
  }
  ngOnInit() {
    this.getFranchiseStoreListData();
  }
  applyFilter(filterValue: string) {
    this.franchiseStoreList.filter = filterValue.trim().toLowerCase();
  }
  public getFranchiseStoreListData() {
    this.spinner.show();
    this.mastersService.getlistFranchiseStore().subscribe(
      sResponseModel => {
        this.spinner.hide();
        // console.log('sResponseModel', sResponseModel);
        if (sResponseModel.status) {
          this.franchiseStoreList.data = sResponseModel.data;
          this.franchiseStoreList.paginator = this.paginator;
        }
        else{
          this.common.openSnackBar('No Store Found','', 'danger-snackbar');
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }
  public editFranchiseStore(id) {
    const editId = btoa(id);
    this.router.navigate(['masters/editFranchiseStore'], { queryParams: { editId } });
  }
  public deleteFranchiseStore(franchiseStoreId) {

    this.common.openConfirmDialog('Are you sure to delete this Store ?')
    .afterClosed().subscribe(res =>{
      if(res){
        let franchiseIndex = this.franchiseStoreList.data.findIndex(key => key['id'] == franchiseStoreId)
        this.mastersService.getDeleteFranchiseStore(franchiseStoreId).subscribe((data) => {
          if (data.status) {
            this.franchiseStoreList.data.splice(franchiseIndex, 1);
            this.franchiseStoreList.data = this.franchiseStoreList.data;
            this.common.openSnackBar('Store Deleted Successfully','', 'success-snackbar');
          }
          else {
            this.common.openSnackBar('Store Could Not Deleted','', 'danger-snackbar');
          }
        },
        sError => {
          this.common.apiError(sError);
        });
      }
    });


    
  }

  onExportClicked(reportType: any, filterKey?: any, filterValue?: any) {
    this.common.exportAsExcelFile(reportType, filterKey, filterValue);
  }

}
