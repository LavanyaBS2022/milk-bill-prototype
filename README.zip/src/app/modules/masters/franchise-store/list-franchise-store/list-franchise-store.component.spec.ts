import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListFranchiseStoreComponent } from './list-franchise-store.component';

describe('ListFranchiseStoreComponent', () => {
  let component: ListFranchiseStoreComponent;
  let fixture: ComponentFixture<ListFranchiseStoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListFranchiseStoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListFranchiseStoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
