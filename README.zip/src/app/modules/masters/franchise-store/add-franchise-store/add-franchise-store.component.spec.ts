import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddFranchiseStoreComponent } from './add-franchise-store.component';

describe('AddFranchiseStoreComponent', () => {
  let component: AddFranchiseStoreComponent;
  let fixture: ComponentFixture<AddFranchiseStoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddFranchiseStoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddFranchiseStoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
