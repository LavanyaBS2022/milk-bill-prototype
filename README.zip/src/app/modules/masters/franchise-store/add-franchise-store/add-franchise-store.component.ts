import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-add-franchise-store',
  templateUrl: './add-franchise-store.component.html',
  styleUrls: ['./add-franchise-store.component.scss']
})
export class AddFranchiseStoreComponent implements OnInit {
  public franchiseStoreAddForm: FormGroup;
  public submitted = false;
  public isDuplicateFound: boolean = false;
  public franchiseList;
  public brandList = [];
  constructor(private formBuilder: FormBuilder, public mastersService: MastersService, public router: Router, private common: Common,private spinner:NgxSpinnerService   ) {
    this.getFranchiseList();
  }
  getFranchiseList() {
    this.mastersService.getlistFranchise().subscribe((data) => {
      // console.log('data', data);
      this.franchiseList = data.data
      // this.router.navigate(['masters/listFranchiseStore']);
    },
    sError => {
      this.common.apiError(sError);
    });

  }

  ngOnInit() {

    this.franchiseStoreAddForm = this.formBuilder.group({
      storeType: ['', Validators.required],
      storeName: ['', Validators.required],
      storeCode: [''],
      contactPerson: [''],
      phoneNo: [''],
      franchiseId: ['', Validators.required],
      mobile: [''],
      email: [''],
      address: [''],
      brandId: ['', Validators.required],

    });
  }
  get get() { return this.franchiseStoreAddForm.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.franchiseStoreAddForm.invalid) {
      this.common.openSnackBar('Please fill all the mandatory fields','', 'danger-snackbar');
      return;
    }
    else {
      const postData = {
        "storeType": this.get.storeType.value,
        "storeName": this.get.storeName.value,
        "storeCode": this.get.storeCode.value,
        "contactPerson": this.get.contactPerson.value,
        "phoneNo": this.get.phoneNo.value,
        "mobile": this.get.mobile.value,
        "email": this.get.email.value,
        "address": this.get.address.value,
        "franchiseId": this.get.franchiseId.value,
        "brandId": this.get.brandId.value,
        "createdUser": 1,
        "createdDate": new Date(),
        "status": 1
      };
      // console.log('postData', postData);
      // return;
      this.spinner.show();
      this.mastersService.postAddFranchiseStore(postData).subscribe((data) => {
        this.spinner.hide();
        // console.log('data', data);
        if(data.status){
          this.router.navigate(['masters/listFranchiseStore']);
          this.common.openSnackBar('New Store Added Successfully','', 'success-snackbar');
        }
        else{
          this.common.openSnackBar('Could Not Add Store','', 'danger-snackbar');
        }
      },
      sError => {
        this.common.apiError(sError);
      });
    }
  }

  reset() {
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
    this.franchiseStoreAddForm.reset();
  }
  public getBrandList(franchiseId) {
    // console.log('reached getBrandList', this.get.franchiseId.value);
    this.mastersService.getBrandListByFranchiseId(this.get.franchiseId.value, 1).subscribe(
      sResponseModel => {
        if (sResponseModel.data) {
          this.brandList = sResponseModel.data;
          // console.log('getBrandListByFranchiseId', sResponseModel.data);
        }
      }, sError => {
        this.common.apiError(sError);
      }
    );
  }

}
