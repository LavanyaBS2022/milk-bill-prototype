import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AngularMaterialModule } from './../../angular.material.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MastersRoutingModule } from './masters.routing.module';
import { SharedModule } from './../../shared/shared.module';
import { NgJsonEditorModule } from 'ang-jsoneditor';
import { ToastModule } from 'primeng/toast';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material';
import { MatSortModule } from '@angular/material/sort';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { AddSeasonComponent } from './season/add-season/add-season.component';
import { ListSeasonComponent } from './season/list-season/list-season.component';
import { EditSeasonComponent } from './season/edit-season/edit-season.component';

import { AddOrderWindowComponent } from './order-window/add-order-window/add-order-window.component';
import { EditOrderWindowComponent } from './order-window/edit-order-window/edit-order-window.component';
import { ListOrderWindowComponent } from './order-window/list-order-window/list-order-window.component';

import { AddRbuComponent } from './rbu/add-rbu/add-rbu.component';
import { ListRbuComponent } from "./rbu/list-rbu/list-rbu.component";
import { EditRbuComponent } from "./rbu/edit-rbu/edit-rbu.component";

import { AddFranchiseComponent } from './franchise/add-franchise/add-franchise.component';
import { EditFranchiseComponent } from './franchise/edit-franchise/edit-franchise.component';
import { ListFranchiseComponent } from './franchise/list-franchise/list-franchise.component';

import { AddFranchiseStoreComponent } from './franchise-store/add-franchise-store/add-franchise-store.component';
import { ListFranchiseStoreComponent } from './franchise-store/list-franchise-store/list-franchise-store.component';
import { EditFranchiseStoreComponent } from './franchise-store/edit-franchise-store/edit-franchise-store.component';
import { ImportExportComponent } from './import-export/import-export.component';

import { AddProdutTypeComponent } from "./product-type/add-produt-type/add-produt-type.component";
import { EditProdutTypeComponent } from "./product-type/edit-produt-type/edit-produt-type.component";
import { ListProdutTypeComponent } from "./product-type/list-produt-type/list-produt-type.component";

import { AddBrandComponent } from "./brand/add-brand/add-brand.component";
import { EditBrandComponent } from "./brand/edit-brand/edit-brand.component";
import { ListBrandComponent } from "./brand/list-brand/list-brand.component";

import { AddDivisionComponent } from "./division/add-division/add-division.component";
import { EditDivisionComponent } from "./division/edit-division/edit-division.component";
import { ListDivisionComponent } from "./division/list-division/list-division.component";

import { AddGenderComponent } from "./gender/add-gender/add-gender.component";
import { EditGenderComponent } from "./gender/edit-gender/edit-gender.component";
import { ListGenderComponent } from "./gender/list-gender/list-gender.component";

import { AddRegionComponent } from "./region/add-region/add-region.component";
import { EditRegionComponent } from "./region/edit-region/edit-region.component";
import { ListRegionComponent } from "./region/list-region/list-region.component";
import { ImportOrdermasterComponent } from './import-ordermaster/import-ordermaster.component';
//import { ImportConsolidateorderComponent } from './import-consolidateorder/import-consolidateorder.component';
//import { ExportMasterComponent } from './export-master/export-master.component';
import { FileLogComponent } from './file-log/file-log.component';

import { ArticleListComponent } from "./article-list/article-list.component";
import { SuggestedArticlesComponent } from './suggested-articles/suggested-articles.component';

import { ImportSuggestedArticleComponent } from "./import-suggested-article/import-suggested-article.component";
import { EditViewComponent ,DialogOrderWindowPopUpComponent} from './edit-view/edit-view.component'
import { ArticleImportComponent } from './article-import/article-import.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        FlexLayoutModule,
        AngularMaterialModule,
        MastersRoutingModule,
        SharedModule,
        NgJsonEditorModule,
        ToastModule,
        MatTableModule,
        MatPaginatorModule,
        MatSortModule,
        MatFormFieldModule,
        MatInputModule,
        MatDialogModule,
        MatButtonModule

    ],
    entryComponents: [DialogOrderWindowPopUpComponent],
    declarations: [
        AddSeasonComponent,
        ListSeasonComponent,
        EditSeasonComponent,
        AddOrderWindowComponent,
        EditOrderWindowComponent,
        ListOrderWindowComponent,
        AddRbuComponent,
        ListRbuComponent,
        EditRbuComponent,
        AddFranchiseComponent,
        EditFranchiseComponent,
        ListFranchiseComponent,
        AddFranchiseStoreComponent,
        EditFranchiseStoreComponent,
        ListFranchiseStoreComponent,
        ImportExportComponent,

        AddProdutTypeComponent,
        EditProdutTypeComponent,
        ListProdutTypeComponent,
        AddBrandComponent,
        EditBrandComponent,
        ListBrandComponent,
        AddDivisionComponent,
        EditDivisionComponent,
        ListDivisionComponent,
        AddGenderComponent,
        EditGenderComponent,
        ListGenderComponent,
        AddRegionComponent,
        EditRegionComponent,
        ListRegionComponent,
        ImportOrdermasterComponent,
        FileLogComponent,

        ArticleListComponent,

        SuggestedArticlesComponent,
        ImportSuggestedArticleComponent,
        EditViewComponent,
        DialogOrderWindowPopUpComponent,
        ArticleImportComponent
    ],

    providers: [],
    bootstrap: [ListSeasonComponent]
})
export class MastersModule { }
