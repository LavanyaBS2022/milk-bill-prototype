import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormGroup, FormControl, Validators, FormBuilder } from "@angular/forms";
import { MastersService } from "./../../../../shared/service/masters/masters.service";
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-add-region',
  templateUrl: './add-region.component.html',
  styleUrls: ['./add-region.component.scss']
})
export class AddRegionComponent implements OnInit {


  public regionAddForm: FormGroup;
  public isSubmitted: boolean = false;

  constructor(private formBuilder: FormBuilder, public masterService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService) {
  }

  ngOnInit() {
    this.regionAddForm = this.formBuilder.group({
      regionName: ['', [Validators.required, Validators.maxLength(50)]]
    });
  }

  public get get() {
    return this.regionAddForm.controls;
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.regionAddForm.get("regionName").value.trim() == "") {
      this.common.openSnackBar('Please fill all the mandatory fields','', 'danger-snackbar');
      return 
      //this.regionAddForm.controls["regionName"].setErrors({ emptyValidateError: "Region Name cannot be empty." });
    }

    if (this.regionAddForm.valid && this.regionAddForm.get("regionName").value.trim() != "") {
      this.spinner.show();
      const postData = JSON.parse(JSON.stringify(this.regionAddForm.value));
      this.masterService.postAddRegion(postData).subscribe((data) => {
        this.spinner.hide();
        if (data.status) {
          this.router.navigate(['masters/listRegion']);
          this.common.openSnackBar('Region Added Successfully', '', 'success-snackbar');
        } else {
          this.regionAddForm.controls["regionName"].setErrors({ serverValidateError: "Region Name is duplicate" });
        }
      },
      sError => {
        this.common.apiError(sError);
      });
    }
  }

  onReset() {
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
    this.isSubmitted = false;
    this.regionAddForm.reset();
  }

}
