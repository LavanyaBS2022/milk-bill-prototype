import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Router } from '@angular/router';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-list-region',
  templateUrl: './list-region.component.html',
  styleUrls: ['./list-region.component.scss']
})
export class ListRegionComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  public regionList_datasource = new MatTableDataSource();
  regionDisplayedColumns: string[] = ['SNo', 'name', 'action'];

  constructor(private masterService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService
    ) { }

  ngOnInit() {
    this.getRegionList();
  }

  applyFilter(filterValue: string) {
    this.regionList_datasource.filter = filterValue.trim().toLowerCase();
  }

  public getRegionList() {
    this.spinner.show();
    this.masterService.getListRegion().subscribe(
      sResponseModel => {
        this.spinner.hide();
        if (sResponseModel.data) {
          this.regionList_datasource.data = sResponseModel.data;
          this.regionList_datasource.paginator = this.paginator;
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public editRegion(id) {
    const editId = btoa(id);
    this.router.navigate(['masters/editRegion'], { queryParams: { editId } });
  }

  public deleteRegion(regionId) {
    this.common.openConfirmDialog('Are you sure to delete this region ?')
      .afterClosed().subscribe(res => {
        if (res) {
          let regionIndex = this.regionList_datasource.data.findIndex(key => key['id'] == regionId)
          this.masterService.getDeleteRegion(regionId).subscribe((data) => {
            if (data.data) {
              this.regionList_datasource.data.splice(regionIndex, 1);
              this.regionList_datasource.data = this.regionList_datasource.data;
              this.common.openSnackBar('Region Deleted Successfully', '', 'success-snackbar');
            }
            else {
              this.common.openSnackBar('Region Could Not Delete', '', 'danger-snackbar');
            }
          })
        }
      },
      sError => {
        this.common.apiError(sError);
      });
  }

}
