import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { Common } from '../../../../shared/service/common/common';
import { NgxSpinnerService } from "ngx-spinner";


@Component({
  selector: 'app-edit-region',
  templateUrl: './edit-region.component.html',
  styleUrls: ['./edit-region.component.scss']
})
export class EditRegionComponent implements OnInit {

  public regionEditForm: FormGroup;
  public editRegionId: any;
  public editRegionData: any;
  public isSubmitted: boolean = false;

  constructor(private formBuilder: FormBuilder, public route: ActivatedRoute, public mastersService: MastersService, public router: Router, public common: Common,private spinner:NgxSpinnerService) {
    this.route.queryParams.subscribe(params => {
      this.editRegionId = (atob(params.editId));
      this.getEditRegionData(this.editRegionId);
    });
  }

  ngOnInit() {
    this.regionEditForm = this.formBuilder.group({
      regionName: ['', [Validators.required, Validators.maxLength(50)]]
    });
  }

  public get get() {
    return this.regionEditForm.controls;
  }

  getEditRegionData(editId: any) {
    this.mastersService.getListRegionbyId(editId).subscribe((data) => {
      this.editRegionData = data.data;
      this.regionEditForm.patchValue({
        regionName: this.editRegionData[0].name
      });
    },
    sError => {
      this.common.apiError(sError);
    });
  }

  onSubmit() {
    this.isSubmitted = true;
    if (this.regionEditForm.get("regionName").value.trim() == "") {
      this.common.openSnackBar('Please fill all the mandatory fields','', 'danger-snackbar');
      return 
      // this.regionEditForm.controls["regionName"].setErrors({ emptyValidateError: "Region Name cannot be empty." });
    }

    if (this.regionEditForm.valid && this.regionEditForm.get("regionName").value.trim() != "") {
      this.spinner.show();
      this.regionEditForm.value['editRegionId'] = this.editRegionId;
      const postData = JSON.parse(JSON.stringify(this.regionEditForm.value));
      this.mastersService.postUpdateRegion(postData).subscribe((data) => {
        this.spinner.hide();
        if (data.status) {
          this.router.navigate(['masters/listRegion']);
          this.common.openSnackBar('Region Updated Successfully', '', 'success-snackbar');
        }
        else {
          this.regionEditForm.controls["regionName"].setErrors({ serverValidateError: "Region Name is duplicate" });
        }
      },
      sError => {
        this.common.apiError(sError);
      });
    }
  }

  onReset() {
    this.common.openSnackBar('Form Reset Successfully','', 'success-snackbar');
    this.isSubmitted = false;
    this.regionEditForm.reset();
  }

}
