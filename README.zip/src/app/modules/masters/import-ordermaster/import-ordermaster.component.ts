import { Component, OnInit } from '@angular/core';
import { MastersService } from '../../../shared/service/masters/masters.service';
import { Common } from '../../../shared/service/common/common';

@Component({
  selector: 'app-import-ordermaster',
  templateUrl: './import-ordermaster.component.html',
  styleUrls: ['./import-ordermaster.component.scss']
})
export class ImportOrdermasterComponent implements OnInit {
  public ordersheetfileData;
  public seasonId:any='';
  public orderWindowId:any='';
  public seasonList = [];
  public orderWindowList = [];
  public getmessage;
  public orderSheetType: string;
  public rows;
  constructor(private maseterService: MastersService,private common:Common) {

   }

  ngOnInit() {
    this.getSeasons();
   
  }

  fileInputChange(fileInputEvent: any,typeFor?:any) {
    if (fileInputEvent.target.files.length > 0) { 
        this.ordersheetfileData= fileInputEvent.target.files[0];
    }
  }

  importOrdersheet() {
    if(!this.seasonId && !this.orderWindowId && !this.orderSheetType){
      this.common.openSnackBar('Please select all the column', '', 'danger-snackbar');
    }
    else{
      this.common.showSpinner();
      let form = new FormData();
      let seasonId:any = this.seasonId;
      let orderWindowId:any = this.orderWindowId;
      form.append('fileName', this.ordersheetfileData);
      form.append('seasonId', seasonId);
      form.append('orderWindowId', orderWindowId);
      form.append('fileType', this.orderSheetType);
      this.maseterService.importOrdersheet(form).subscribe((sResponse: any) => {
        // console.log(sResponse);
        if (sResponse.data) {
          this.getmessage = sResponse.data.setmessage;
          this.rows = sResponse.data;
          //console.log(this.getmessage);
          this.common.hideSpinner();
        }
      },
      sError => {
        this.common.apiError(sError);
      });
    }

    
    
  }

  getSeasons() {
    this.maseterService.getlistSeason().subscribe((sRespone:any)=>{
       //console.log('seasons',sRespone.data);
      this.seasonList=sRespone.data;
    },
    sError => {
      this.common.apiError(sError);
    });
  }

  getOrderWindowList() {
    const onlyActive = 0;
    this.maseterService.getOrderWindowSeasonList(onlyActive).subscribe((data)=>{
      //console.log('getOrderWindowList',data.data);
      let result = data.data;
      this.orderWindowList=result.filter(item=>item.season_id==this.seasonId);
      //console.log('orderWindowList',this.orderWindowList);
    },
    sError => {
      this.common.apiError(sError);
    });
  }

}
