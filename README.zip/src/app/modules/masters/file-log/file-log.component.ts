import { Component, OnInit,ViewChild } from '@angular/core';
import { MastersService } from '../../../shared/service/masters/masters.service';
import { MatTableDataSource, MatPaginator } from '@angular/material';
import { Common } from '../../../shared/service/common/common';
import { saveAs } from 'file-saver';
import { FormGroup, FormBuilder,Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-file-log',
  templateUrl: './file-log.component.html',
  styleUrls: ['./file-log.component.scss']
})
export class FileLogComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;

  public fileList = new MatTableDataSource();
  public userDetails;
  public userType:any='';
  displayedColumns: string[] = ['sNo','file_name', 'file_type', 'season_name','season_code','order_window_name','created_at','franchise','store' ,'Actions'];
  public fileLogFilterForm: FormGroup;
  public seasonList = [];
  public orderWindowList = [];
  public seasonId: any = '';
  public orderWindowId: any = '';
  public submitted:boolean;
  public franchaiseList=[];
  public maxDate;
  public minDate;

  constructor(private maseterService:MastersService,public common: Common,private formBuilder: FormBuilder,
    private masterService: MastersService,private datePipe:DatePipe) {
    this.maxDate= new Date();
   }
  
  public text: any = 'Show Filter';
  public changeText(): void {
    if (this.text === 'Collapse Filter') {
      this.text = 'Show Filter';
    } else {
      this.text = 'Collapse Filter';
    }
  }

  public fileTypes=[
    {key:'footwareMaster',value:'c8 Footware Master'},
    {key:'apparelEquipmentMaster',value:'c8 APEQ Master'},
    {key:'footwareOrdersheet',value:'FW Ordersheet'},
    {key:'apparelEquipmentOrdersheet',value:'APEQ Ordersheet'},
    {key:'footwareConsolidatedOrders',value:'FW Consolidated Orders'},
    {key:'apparelEquipmentConsolidatedOrders',value:'APEQ Consolidated Orders'},
  ]

  ngOnInit() {
    this.userDetails = this.common.getUserDetails();
    this.getFileLogs();
    this.generateFileLogFormFilter();
    this.getSeasons();
    this.getFranchise();
    
  }

  generateFileLogFormFilter() {
    this.fileLogFilterForm = this.formBuilder.group({
      seasonId: [''],
      orderWindowId: [''],
      fileType:[''],
      franchaiseId:[''],
      fromDate:[''],
      toDate:['']
    });
   
  }


  public get get() {
    return this.fileLogFilterForm.controls;
  }

  getSeasons() {
    this.masterService.getlistSeason().subscribe((sRespone: any) => {
       //console.log('seasons', sRespone.data);
      this.seasonList = sRespone.data;
    })
  }

  getFranchise() {
    this.masterService.getlistFranchise().subscribe((sResponse: any) => {
      // console.log('franchise', sResponse.data);
      this.franchaiseList = sResponse.data;
    })
  }

  getOrderWindowList(value) {
    this.seasonId=value;
    const onlyActive = 0;
    this.masterService.getOrderWindowSeasonList(onlyActive).subscribe((data) => {
      // // console.log('getOrderWindowList', data.data);
      let result = data.data;
      this.orderWindowList = result.filter(item => item.season_id == this.seasonId);
      // // console.log('orderWindowList', this.orderWindowList);
    },
    sError => {
      this.common.apiError(sError);
    });
  }


  getFileLogs(filterObj?) {
    let obj={};
    if (this.userDetails.franchiseId) {
      Object.assign(obj,{ franchise_id: this.userDetails.franchiseId });
      
    } else {
      this.userType=1;
      Object.assign(obj,{ user_type: 1 });
      if(filterObj){
        Object.assign(obj,filterObj);
      }
    }
    this.maseterService.getlistFilelogs(obj).subscribe((sRespone:any)=>{
      if(sRespone.data != false){
       //console.log("sResponseModel.data",sRespone.data);
        this.fileList.data =sRespone.data;
        this.fileList.paginator = this.paginator;
      }
      else{
        this.common.openSnackBar('No record found','', 'danger-snackbar');
      }
    },
    sError => {
      this.common.apiError(sError);
    });
  }

  downLoadFile(id: number,fileName) {
    this.maseterService.downloadFileLog(id).subscribe((sResponse: any) => {
       // console.log(sResponse);
      if (sResponse) {
        saveAs(sResponse, fileName);
      }
    },
    sError => {
      this.common.apiError(sError);
    });
  }

  onSubmitSearch(){
    this.submitted = true;
    // console.log('form invalid', this.articleListFilterForm.invalid);
    if (this.fileLogFilterForm.valid) {
      let obj={
        fileType:this.get.fileType.value,
        seasonId:this.get.seasonId.value,
        orderWindowid:this.get.orderWindowId.value,
        franchiseId:this.get.franchaiseId.value,
        fromDate:this.datePipe.transform(this.get.fromDate.value,'yyyy-MM-dd'),
        toDate:this.datePipe.transform(this.get.toDate.value,'yyyy-MM-dd'),
      }
      console.log('Obj',obj);
      this.getFileLogs(obj);
      
      
    }
    else {
      this.common.openSnackBar('Please select All the Mandatory Fields', '', 'danger-snackbar');
      this.common.hideSpinner();
    }
  }

  public applyFilter(event){
    this.minDate = new Date(event.value);
  }

  public resetSearch(){
    this.getFileLogs();
  }

}
