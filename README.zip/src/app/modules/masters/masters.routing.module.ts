import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardService } from '../../shared/service/guard/auth-guard.service';
import { AddSeasonComponent } from './season/add-season/add-season.component';
import { ListSeasonComponent } from './season/list-season/list-season.component';
import { EditSeasonComponent } from './season/edit-season/edit-season.component';

import { AddRbuComponent } from './rbu/add-rbu/add-rbu.component';
import { ListRbuComponent } from './rbu/list-rbu/list-rbu.component';
import { EditRbuComponent } from "./rbu/edit-rbu/edit-rbu.component";

import { AddOrderWindowComponent } from './order-window/add-order-window/add-order-window.component';
import { EditOrderWindowComponent } from './order-window/edit-order-window/edit-order-window.component';
import { ListOrderWindowComponent } from './order-window/list-order-window/list-order-window.component';


import { AddFranchiseComponent } from './franchise/add-franchise/add-franchise.component';
import { EditFranchiseComponent } from './franchise/edit-franchise/edit-franchise.component';
import { ListFranchiseComponent } from './franchise/list-franchise/list-franchise.component';


import { AddFranchiseStoreComponent } from './franchise-store/add-franchise-store/add-franchise-store.component';
import { ListFranchiseStoreComponent } from './franchise-store/list-franchise-store/list-franchise-store.component';
import { EditFranchiseStoreComponent } from './franchise-store/edit-franchise-store/edit-franchise-store.component';

import { AddProdutTypeComponent } from "./product-type/add-produt-type/add-produt-type.component";
import { EditProdutTypeComponent } from "./product-type/edit-produt-type/edit-produt-type.component";
import { ListProdutTypeComponent } from "./product-type/list-produt-type/list-produt-type.component";

import { AddBrandComponent } from "./brand/add-brand/add-brand.component";
import { EditBrandComponent } from "./brand/edit-brand/edit-brand.component";
import { ListBrandComponent } from "./brand/list-brand/list-brand.component";

import { AddDivisionComponent } from "./division/add-division/add-division.component";
import { EditDivisionComponent } from "./division/edit-division/edit-division.component";
import { ListDivisionComponent } from "./division/list-division/list-division.component";

import { AddGenderComponent } from "./gender/add-gender/add-gender.component";
import { EditGenderComponent } from "./gender/edit-gender/edit-gender.component";
import { ListGenderComponent } from "./gender/list-gender/list-gender.component";

import { AddRegionComponent } from "./region/add-region/add-region.component";
import { EditRegionComponent } from "./region/edit-region/edit-region.component";
import { ListRegionComponent } from "./region/list-region/list-region.component";

// Import Containers
import {
    AdminLayoutComponent,
    FullLayoutComponent,
    SimpleLayoutComponent
} from '../../containers';
import { ImportExportComponent } from './import-export/import-export.component';
import { ImportOrdermasterComponent } from './import-ordermaster/import-ordermaster.component';
// import { ImportConsolidateorderComponent } from './import-consolidateorder/import-consolidateorder.component';
// import { ExportMasterComponent } from './export-master/export-master.component';
import { FileLogComponent } from './file-log/file-log.component';

import { ArticleListComponent } from "./article-list/article-list.component";
import { SuggestedArticlesComponent } from './suggested-articles/suggested-articles.component';
import { ImportSuggestedArticleComponent } from "./import-suggested-article/import-suggested-article.component"
import { EditViewComponent } from './edit-view/edit-view.component';
import { ArticleImportComponent } from './article-import/article-import.component';

const routes: Routes = [
    {
        path: 'add-season',
        component: AddSeasonComponent,
        data: {
            title: 'Add Season',
            module: 'Masters',
            permission: 'addSeason'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'list-season',
        component: ListSeasonComponent,
        data: {
            title: 'List Season',
            module: 'Masters',
            permission: 'listSeason'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'edit-season',
        component: EditSeasonComponent,
        data: {
            title: 'Edit Season',
            module: 'Masters',
            permission: 'editSeason'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'addOrderWindow',
        component: AddOrderWindowComponent,
        data: {
            title: 'Add Order Window',
            module: 'Masters',
            permission: 'addOrderWindow'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'listOrderWindow',
        component: ListOrderWindowComponent,
        data: {
            title: 'List Order Window',
            module: 'Masters',
            permission: 'listOrderWindow'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'editOrderWindow',
        component: EditOrderWindowComponent,
        data: {
            title: 'Edit Order Window',
            module: 'Masters',
            permission: 'editOrderWindow'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'addFranchise',
        component: AddFranchiseComponent,
        data: {
            title: 'Add Franchise',
            module: 'Masters',
            permission: 'addFranchise'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'listFranchise',
        component: ListFranchiseComponent,
        data: {
            title: 'List Franchise',
            module: 'Masters',
            permission: 'listFranchise'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'editFranchise',
        component: EditFranchiseComponent,
        data: {
            title: 'Edit Franchise',
            module: 'Masters',
            permission: 'editFranchise'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'addFranchiseStore',
        component: AddFranchiseStoreComponent,
        data: {
            title: 'Add Franchise Store',
            module: 'Masters',
            permission: 'addFranchiseStore'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'listFranchiseStore',
        component: ListFranchiseStoreComponent,
        data: {
            title: 'List Franchise Store',
            module: 'Masters',
            permission: 'listFranchiseStore'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'editFranchiseStore',
        component: EditFranchiseStoreComponent,
        data: {
            title: 'Edit Franchise Store',
            module: 'Masters',
            permission: 'editFranchiseStore'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'masterImportExport',
        component: ImportExportComponent,
        data: {
            title: 'masterImportExport',
            module: 'Masters',
            permission: 'c8masterImportExport'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'importOrdermaster',
        component: ImportOrdermasterComponent,
        data: {
            title: 'importOrdermaster',
            module: 'Masters',
            permission: 'importOrdermaster'
        },
        canActivate: [AuthGuardService]
    },
    // {
    //     path: 'importConsolidateOrder',
    //     component: ImportConsolidateorderComponent,
    //     data: {
    //         title: 'importConsolidateOrder',
    //         module: 'Masters',
    //         permission: 'importConsolidateOrder'
    //     },
    //     canActivate: [AuthGuardService]
    // },
    // {
    //     path: 'exportMaster',
    //     component: ExportMasterComponent,
    //     data: {
    //         title: 'exportMaster',
    //         module: 'Masters',
    //         permission: 'OrderSheetExport'
    //     },
    //     canActivate: [AuthGuardService]
    // },
    {
        path: 'fileLog',
        component: FileLogComponent,
        data: {
            title: 'fileLogs',
            module: 'Masters',
            permission: 'fileLogs'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'add-rbu',
        component: AddRbuComponent,
        data: {
            title: 'Add Category4',
            module: 'Masters',
            permission: 'addCategory4'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'list-rbu',
        component: ListRbuComponent,
        data: {
            title: 'List Category4',
            module: 'Masters',
            permission: 'listCategory4'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'edit-rbu',
        component: EditRbuComponent,
        data: {
            title: 'Edit Category4',
            module: 'Masters',
            permission: 'editCategory4'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'addProductType',
        component: AddProdutTypeComponent,
        data: {
            title: 'Add Category1',
            module: 'Masters',
            permission: 'addCategory1'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'editProductType',
        component: EditProdutTypeComponent,
        data: {
            title: 'Edit category1',
            module: 'Masters',
            permission: 'editCategory1'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'listProductType',
        component: ListProdutTypeComponent,
        data: {
            title: 'List Category1',
            module: 'Masters',
            permission: 'listCategory1'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'addBrand',
        component: AddBrandComponent,
        data: {
            title: 'Add Brand',
            module: 'Masters',
            permission: 'addBrand'
        },
        canActivate: [AuthGuardService]

    },
    {
        path: 'editBrand',
        component: EditBrandComponent,
        data: {
            title: 'Edit Brand',
            module: 'Masters',
            permission: 'editBrand'
        },
        canActivate: [AuthGuardService]

    },
    {
        path: 'listBrand',
        component: ListBrandComponent,
        data: {
            title: 'List Brand',
            module: 'Masters',
            permission: 'listBrand'
        },
        canActivate: [AuthGuardService]

    },
    {
        path: 'addDivision',
        component: AddDivisionComponent,
        data: {
            title: 'Add Division',
            module: 'Masters',
            permission: 'addDivision'
        },
        canActivate: [AuthGuardService]

    },
    {
        path: 'editDivision',
        component: EditDivisionComponent,
        data: {
            title: 'Edit Division',
            module: 'Masters',
            permission: 'editDivision'
        },
        canActivate: [AuthGuardService]

    },
    {
        path: 'listDivision',
        component: ListDivisionComponent,
        data: {
            title: 'List Divivsion',
            module: 'Masters',
            permission: 'listDivision'
        },
        canActivate: [AuthGuardService]

    },
    {
        path: 'addGender',
        component: AddGenderComponent,
        data: {
            title: 'Add Gender',
            module: 'Masters',
            permission: 'addGender'
        },
        canActivate: [AuthGuardService]

    },
    {
        path: 'editGender',
        component: EditGenderComponent,
        data: {
            title: 'Edit Gender',
            module: 'Masters',
            permission: 'editGender'
        },
        canActivate: [AuthGuardService]

    },
    {
        path: 'listGender',
        component: ListGenderComponent,
        data: {
            title: 'List Gender',
            module: 'Masters',
            permission: 'listGender'
        },
        canActivate: [AuthGuardService]

    },
    {
        path: 'addRegion',
        component: AddRegionComponent,
        data: {
            title: 'Add Region',
            module: 'Masters',
            permission: 'addRegion'
        },
        canActivate: [AuthGuardService]

    },
    {
        path: 'editRegion',
        component: EditRegionComponent,
        data: {
            title: 'Edit Region',
            module: 'Masters',
            permission: 'editRegion'
        },
        canActivate: [AuthGuardService]

    },
    {
        path: 'listRegion',
        component: ListRegionComponent,
        data: {
            title: 'List Region',
            module: 'Masters',
            permission: 'listRegion'
        },
        canActivate: [AuthGuardService]

    },
    {
        path: 'listArticle',
        component: ArticleListComponent,
        data: {
            title: 'Article List',
            module: 'Masters',
            permission: 'listArticle'
        },
        canActivate: [AuthGuardService]

    },
    {
        path: 'suggestedArticle',
        component: SuggestedArticlesComponent,
        data: {
            title: 'Suggested Article',
            module: 'Masters',
            permission: 'c8masterImportExport'
        },
        canActivate: [AuthGuardService]

    },
    {
        path: 'editView',
        component: EditViewComponent,
        data: {
            title: 'Edit-View',
            module: 'Masters',
            permission: 'listArticle'
        },
        canActivate: [AuthGuardService]

    },
    { path: 'importSuggestedArticle',
        component: ImportSuggestedArticleComponent,
        data: {
            title: 'Import Suggested Article',
            module: 'Masters',
            permission: 'listArticle'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'importArticleImages',
        component: ArticleImportComponent,
        data: {
            title: 'Import Article Images',
            module: 'Masters',
            permission: 'fileLogs'
        },
        canActivate: [AuthGuardService]
    }

];

@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ],
    exports: [
        RouterModule
    ]
})

export class MastersRoutingModule { }
