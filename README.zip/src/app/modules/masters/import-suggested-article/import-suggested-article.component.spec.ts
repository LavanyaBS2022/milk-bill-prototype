import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportSuggestedArticleComponent } from './import-suggested-article.component';

describe('ImportSuggestedArticleComponent', () => {
  let component: ImportSuggestedArticleComponent;
  let fixture: ComponentFixture<ImportSuggestedArticleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportSuggestedArticleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportSuggestedArticleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
