import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-import-suggested-article',
  templateUrl: './import-suggested-article.component.html',
  styleUrls: ['./import-suggested-article.component.scss']
})
export class ImportSuggestedArticleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
