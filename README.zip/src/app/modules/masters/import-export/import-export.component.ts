import { Component, OnInit } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { MastersService } from '../../../shared/service/masters/masters.service';
import { ActivatedRoute } from '@angular/router';
import { Common } from '../../../shared/service/common/common';

@Component({
  selector: 'app-import-export',
  templateUrl: './import-export.component.html',
  styleUrls: ['./import-export.component.scss']
})
export class ImportExportComponent implements OnInit {
  public fileData;
  public fileType: string = 'footwareMaster';
  public getmessage;
  public seasonId:any='';
  public orderWindowId:any='';
  public seasonList = [];
  public orderWindowList = [];
  public rows;
  constructor(private maseterService: MastersService, private route: ActivatedRoute,
  private common:Common) {
    
      
   }
   

  ngOnInit() {
    let userDetails=this.common.getUserDetails();
    this.getSeasons();
    
  }

  fileInputChange(fileInputEvent: any,typeFor?:any) {
    if (fileInputEvent.target.files.length > 0) { 
        this.fileData= fileInputEvent.target.files[0];
    }
  }
  importData() {
    if(!this.seasonId && !this.orderWindowId){
      this.common.openSnackBar('Please select the Season / Orderwindow', '', 'danger-snackbar');
    }
    else{
      this.common.showSpinner();
      let form = new FormData();
      let seasonId:any = this.seasonId;
      let orderWindowId:any = this.orderWindowId;
      form.append('fileName', this.fileData);
      form.append('seasonId', seasonId);
      form.append('orderWindowId', orderWindowId);
      this.maseterService.importExcelData(form,this.fileType).subscribe((sRespone: any) => {
        // console.log(sRespone);
        if (sRespone.data) {
          this.getmessage = sRespone.data.setmessage;
          this.rows = sRespone.data;
          //console.log(this.getmessage);
          this.common.hideSpinner();
        }
        
      },
      sError => {
        this.common.apiError(sError);
      });
    }
    
    //console.log(form);
    //console.log(this.fileData);
    
    //console.log(this.fileData);
  }

  getSeasons() {
    this.maseterService.getlistSeason().subscribe((sRespone:any)=>{
       //console.log('seasons',sRespone.data);
      this.seasonList=sRespone.data;
    },
    sError => {
      this.common.apiError(sError);
    });
  }

  getOrderWindowList() {
    const onlyActive = 0;
    this.maseterService.getOrderWindowSeasonList(onlyActive).subscribe((data)=>{
      //console.log('getOrderWindowList',data.data);
      let result = data.data;
      this.orderWindowList=result.filter(item=>item.season_id==this.seasonId);
      //console.log('orderWindowList',this.orderWindowList);
    },
    sError => {
      this.common.apiError(sError);
    });
  }
  
}
