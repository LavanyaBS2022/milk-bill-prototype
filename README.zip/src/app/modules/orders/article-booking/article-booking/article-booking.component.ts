import { Component, Inject, OnInit, ViewChild, ElementRef, LOCALE_ID } from '@angular/core';
import { TargetService } from './../../../../shared/service/orders/target/target.service';
import { OrdersService } from './../../../../shared/service/orders/orders.service'
import { MastersService } from './../../../../shared/service/masters/masters.service';
import { FormGroup, FormControl, Validators, FormBuilder, FormArray, ControlContainer } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";
import * as math from 'mathjs';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { Common } from '../../../../shared/service/common/common';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatOption } from '@angular/material';
import { ConditionalExpr } from '@angular/compiler';
import { DecimalPipe, formatNumber } from "@angular/common";

@Component({
  selector: 'app-dialog-overview-example-dialog',
  templateUrl: 'app-dialog-overview-example-dialog.html',
  styleUrls: ['./article-booking.component.scss']
})
export class DialogOverviewExampleDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
@Component({
  selector: 'app-article-booking',
  templateUrl: './article-booking.component.html',
  styleUrls: ['./article-booking.component.scss']
})
export class ArticleBookingComponent implements OnInit {
  public text: any = 'Collapse Filter';
  public changeText(): void {
    if (this.text === 'Collapse Filter') {
      this.text = 'Show Filter';
    } else {
      this.text = 'Collapse Filter';
    }
  }
  step = 0;
  setStep(index: number) {
    this.step = index;
  }
  nextStep() {
    this.step++;
  }
  prevStep() {
    this.step--;
  }

  panelOpenState = false;
  public categoryPriorityRadioBtn = 1;
  public selecAllCategory1: boolean = false
  public devisionId;
  public genderId;
  public categoryType: number;
  public targetOrderList = [];
  public devisionDropdown = [];
  public genderDropdown = [];

  public category1Dropdown = [];
  public category2Dropdown = [];
  public allGender = [];
  public category1DropdownAllData = [];
  public category2DropdownAllData = [];
  public articleListDetails = [];
  public articleDetailsAllData = [];
  public divisionWisePriceRange = [];
  public category1Selected = [];
  public category4Selected = [];
  public showCategory1Dropdown: boolean = false;
  public showCategory4Dropdown: boolean = false;
  public DivisionGenderWiseCategory = []
  public orderId;
  public divisionWiseGender = [];
  public formatDivisionDetail = [];
  public articleList = [];
  public allArticlesList = []
  public storeList = [];
  public editedAnalysisArticleIndex = []
  public storeWiseAnalysis = [];
  public storeId;
  public copyStoreFromId;
  public copyStoreToId;
  public orderedArticles = [];
  public toDos;
  public currentBookingValue:any;
  public currentBookingValueDivisionWise = [];
  public currentStoreName;
  public filterArticleIdInput;
  public filterArticleIdControl = new FormControl();
  public filterArticleDescControl = new FormControl();
  public filterArticleIdList: Observable<any[]>;
  public filterArticleDescList: Observable<any[]>;
  public filteredArticleListArray = [];
  public filterArticleId;
  public filterArticleDesc;
  public mandatoryArticleInput;
  public suggestedArticleInput;

  public saveButton: boolean = false;
  public cancelButton: boolean = false;
  public submitButton: boolean = false;
  public franchiseStoreList = [];
  public orderWindowId;
  public seasonId;
  public brandId;
  public accessPriority;
  public countryId;
  public ratio;
  public franchiseId;
  public franchiseName;
  public minPriceFilter;
  public maxPriceFilter;
  public divisionIdList = [];

  public paramsOrderStatus: any;  //Rajendran Added for Asics Demo Feedback changes task
  public copyStoreButton: boolean = false;
  public currentOrderStatus = 0;
  public allTotalQty;
  public allTotalSku;
  public usd;
  public sgd;
  public allTotalUsd;
  public allTotalSgd;
  public orderSummaryList = [];

  public grandTotalUsd; // By Jaydeep
  public grandTotalSgd; // By Jaydeep
  public grandTotalBookingValue:any; // By Jaydeep
  public cusTypeIdStatus;
  public customerTypeId
  // public totalUsd;
  // public totalSgd;
  @ViewChild('allSelected') private allSelected: MatOption;

  constructor(public dialog: MatDialog, private spinner: NgxSpinnerService, private mastersService: MastersService, private ordersService: OrdersService, private targetService: TargetService, private formBuilder: FormBuilder, public route: ActivatedRoute, public router: Router, public common: Common, @Inject(LOCALE_ID) private locale: string) {

  }
  ngOnInit() {
    this.getMasterPriceRange();

    this.route.queryParams.subscribe(params => {
      this.orderId = params.orderId;
      this.storeId = params.storeId;
      let userDetails = this.common.getUserDetails();
      this.seasonId = userDetails.seasonId;
      this.orderWindowId = userDetails.orderWindowId;
      this.franchiseId = userDetails.franchiseId;
      this.accessPriority = userDetails.accessPriority;
      this.countryId = userDetails.franchiseDetails.country_id;
      this.usd = userDetails.franchiseDetails.usd;
      this.sgd = userDetails.franchiseDetails.sgd;
      this.ratio = userDetails.franchiseDetails.ratio;
      this.franchiseName=userDetails.franchiseDetails.franchise_name;
      this.brandId = params.brandId;
      this.customerTypeId=userDetails.customer_type_id;
      if(userDetails.customer_type_id==2){
        this.cusTypeIdStatus=6;
      }else{
        this.cusTypeIdStatus=3;
      }
      this.getFranchiseStoreList();
      this.getArticleDetails();

      this.paramsOrderStatus = params.orderStatus;

      if (this.paramsOrderStatus === "Cancelled") {
        this.copyStoreButton = true;
      } else {
        this.copyStoreButton = false;
      }

      // console.log('franchiseId', this.franchiseId);
      // console.log('orderWindowId', this.orderWindowId);
      // console.log('seasonId', this.seasonId);
      // console.log('accessPriority', this.accessPriority);
      // console.log('sgd', this.sgd);
      // console.log('copy Store button', this.copyStoreButton);

    });
    //to check current order status
    this.checkOrderStatus();
     console.log('articleDetailsAllData',this.articleDetailsAllData)


    this.filterArticleIdList = this.filterArticleIdControl.valueChanges
      .pipe(
        startWith(''),
        map(value => typeof value === 'string' ? value : value.sku),
        map(sku => sku ? this._filter(sku) : this.filteredArticleListArray.slice())
      );
    this.filterArticleDescList = this.filterArticleDescControl.valueChanges
      .pipe(
        startWith(''),
        map(value => typeof value === 'string' ? value : value.articleDescription),
        map(articleDescription => articleDescription ? this._filter1(articleDescription) : this.filteredArticleListArray.slice())
      );
  }

  //will get store List for franchise
  public getFranchiseStoreList() {
    this.ordersService.getFranchiseStoreList(this.franchiseId, this.orderWindowId, this.seasonId, this.brandId).subscribe(
      sResponseModel => {
        if (sResponseModel.data != false) {
           //console.log("franchiseStoreList",sResponseModel.data);
          this.franchiseStoreList = sResponseModel.data;
        }
        else {
          this.common.openSnackBar('No record found', '', 'danger-snackbar');
        }
      },
      sError => {
        // console.log("Store Error",sError);
      });
  }
  openDialog(): void {
    const dialogRef = this.dialog.open(DialogOverviewExampleDialogComponent, {
      width: '400px',
      data: {
        currentStoreName: this.currentStoreName,
        copyStoreFromId: this.copyStoreFromId,
        copyStoreToId: this.copyStoreToId,
        franchiseStoreList: this.franchiseStoreList
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed', result);
      if (result.copyStoreToId == undefined) {
        this.common.openSnackBar('Please Select Store Id to Copy..', '', 'danger-snackbar');
      }
      else {
        let obj = {
          seasonId: this.seasonId,
          orderWindowId: this.orderWindowId,
          franchiseeId: this.franchiseId,
          order_id: this.orderId,
          copyStoreFromId: parseInt(this.storeId),
          copyStoreToId: parseInt(result.copyStoreToId),
          created_user: 1,
          created_date: new Date(),
        }
        //check already have ordered for this store
        let object = {
          seasonId: this.seasonId,
          orderWindowId: this.orderWindowId,
          franchiseeId: this.franchiseId,
          brandId: this.brandId,
          storeId: parseInt(result.copyStoreToId),
        }
        this.targetService.getOrder(object.seasonId, object.orderWindowId, object.franchiseeId, object.storeId, object.brandId).subscribe((sResponse: any) => {
          let data = sResponse.data;
          console.log('order data',data);
          
          let storeData = this.franchiseStoreList.filter(item => item.store_id == result.copyStoreToId)
         // console.log(storeData,'storeData');
          
        if(storeData[0].order_status == "Approved"){
            this.common.openSnackBar('Unable to copy as order for this store has already been approved!!', '', 'danger-snackbar');
          }else{
          if (data[0].id) {
            //already 
            this.common.openConfirmDialog('Already Order Existing for "' + storeData[0].store_name + '" Store. Do you want to overwrite?')
              .afterClosed().subscribe(res => {
                if (res) {
                  this.ordersService.copyStoreData(obj).subscribe(copyStoreData => {
                    // console.log('copystore', copyStoreData)
                    if (copyStoreData) {
                      this.common.openSnackBar('Successfully Copied!!!', '', 'success-snackbar');
                      this.router.navigate(['orders/store-sales-analysis']);

                    }
                  },
                    sError => {
                      this.common.apiError(sError);
                    })
                }
              });
          }
          else {

            this.common.openConfirmDialog('Do you want to copy from "' + this.currentStoreName + '" store to "' + storeData[0].store_name + '" store?')
              .afterClosed().subscribe(res => {
                if (res) {
                  this.ordersService.copyStoreData(obj).subscribe(copyStoreData2 => {
                    // console.log('copystore', copyStoreData2)
                    if (copyStoreData2) {
                      this.common.openSnackBar('Successfully Copied!!!', '', 'success-snackbar');
                      this.router.navigate(['orders/store-sales-analysis']);

                    }
                  },
                    sError => {
                      this.common.apiError(sError);
                    })
                }
              });
           }
          }
        },
          sError => {
            this.common.apiError(sError);
          })
      }
    });

  }
  public checkOrderStatus() {
    this.ordersService.checkOrderStatus(this.orderId).subscribe(data => {
      let response = data.data;
      console.log('response',response);
      
      this.currentOrderStatus = response[0].order_status;
      if (response[0].order_status == 0) {
        this.cancelButton = true;
      }
      if (response[0].order_status == 1) {
        this.saveButton = false;
        this.cancelButton = false;
        this.submitButton = false
      }
      if (response[0].order_status == 2) {
        this.saveButton = true;
        this.cancelButton = true;
        this.submitButton = true
      }
      if (response[0].order_status == 3) { // pending for reveiw
        this.saveButton = true;
        this.cancelButton = true;
        this.submitButton = true
      }
      //Rajendran Added for Asics Demo Feedback changes task
      if (response[0].order_status == 4) {
        this.saveButton = true;
        this.cancelButton = true;
        this.submitButton = true
      }
      if (response[0].order_status == 5) { // rejection
        this.saveButton = false;
        this.cancelButton = false;
        this.submitButton = false
      }
      if (response[0].order_status == 6) { 
        this.saveButton = true;
        this.cancelButton = true;
        this.submitButton = true
      }
      if (response[0].order_status == 7) { 
        this.saveButton = true;
        this.cancelButton = true;
        this.submitButton = true
      }
      if (response[0].order_status == 8) { 
        this.saveButton = false;
        this.cancelButton = false;
        this.submitButton = false
      }
      // console.log('checkOrderStatus',data);      

    },
      sError => {
        this.common.apiError(sError);
      });
  }
  public isObject(item) {
    return (typeof item === "object" && !Array.isArray(item) && item !== null);
  }
  getMandatoryArticleList() {
    // console.log("getMandatoryArticleList");
    this.articleList = this.allArticlesList.filter(item => item.mandatoryArticle == 1)
  }
  filterArticle() {
    // this.filteredArticleListArray= this.articleList
    let filteredArticleList = [];

    // if(this.filterArticleDescControl.value === Array){
    if (this.isObject(this.filterArticleDescControl.value)) {
      // console.log('filterArticleDescControl',this.filterArticleDescControl.value);
      const filterDesc = this.filteredArticleListArray.filter(value => value.articleDescription.toLowerCase().includes(this.filterArticleDescControl.value.articleDescription.toLowerCase()));
      // console.log('filterDesc',filterDesc)
      // filteredArticleList.push(filterDesc)
      filteredArticleList.push.apply(filteredArticleList, filterDesc);
    }
    if (this.isObject(this.filterArticleIdControl.value)) {
      // console.log('filterArticleIdControl',this.filterArticleIdControl.value);
      const filterSku = this.filteredArticleListArray.filter(value => value.sku.toLowerCase().includes(this.filterArticleIdControl.value.sku.toLowerCase()));
      filteredArticleList.push.apply(filteredArticleList, filterSku);
    }
    this.articleList = this.removeDuplicates(filteredArticleList, 'articleId');
    // console.log('filteredArticleList',filteredArticleList)
    if (filteredArticleList.length > 0) {
      this.common.openSnackBar('Found Articles!!!', '', 'success-snackbar');
    }
    else {
      this.common.openSnackBar('No Article found for this', '', 'danger-snackbar');
    }
  }

  private _filter(search: string): any[] {
    return this.filteredArticleListArray.filter(value => value.sku.toLowerCase().includes(search.toLowerCase()))
  }
  displayFn(field?: any): string | undefined {
    return field ? field.sku : undefined;
  }
  private _filter1(search: string): any[] {
    return this.filteredArticleListArray.filter(value => value.articleDescription.toLowerCase().includes(search.toLowerCase()))
  }
  displayFn1(field?: any): string | undefined {
    return field ? field.articleDescription : undefined;
  }
  onGenderSelected(all) {
    if (this.allSelected.selected) {
      this.allSelected.deselect();
      return false;
    }
    if (this.genderId.length == this.genderDropdown.length)
      this.allSelected.select();
  }
  onAllSelectedChange() {
    // console.log("this.allSelected.selected", this.allSelected.selected);

    if (this.allSelected.selected) {
      //after all select call getCategoryData
      // console.log("reached if");
      this.genderId = this.genderDropdown.map(item => item.id);
      //push 0 to select "allSelect " checkbox
      this.genderId.push(0);
      this.getCategoryData();

    } else {
      // console.log("reached else");
      this.genderId = [];
    }
  }
  getGenderDropdown() {
    // console.log("reached", this.devisionId);
    // console.log('targetOrderList', this.targetOrderList);
    const selectedData = this.targetOrderList.find(rateCategory => rateCategory.division_id === parseInt(this.devisionId));
    // console.log('selectedData', selectedData.divisionGender)
    this.genderDropdown = selectedData.divisionGender;
  }
  public removeDuplicates(myArr, prop) {
    return myArr.filter((obj, pos, arr) => {
      return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
    });
  }
  //function used for select all category1
  checkIfAllCategory1Selected(event) {
    if (event.target.checked) {
      this.category1Dropdown.forEach(item => { item.checkedCategory1 = true })
      this.getCategoryDropDown();
      // this.getCategory4DropDown();
    }
    else {
      this.category1Dropdown.forEach(item => { item.checkedCategory1 = false })
      this.getCategoryDropDown();
    }
  }
  //function used for select all category2
  checkIfAllCategory2Selected(event) {
    if (event.target.checked) {
      this.category2Dropdown.forEach(item => { item.checkedCategory2 = true })
      this.getCategoryDropDown();
    }
    else {
      this.category2Dropdown.forEach(item => { item.checkedCategory2 = false })
      this.getCategoryDropDown();
    }
  }
  //this will get category based on choses category priority
  getCategoryDropDown() {
    if (this.categoryType == 1) {
      this.showCategory1Dropdown = true
      this.showCategory4Dropdown = false;
      //remove all duplicate product type
      this.category1DropdownAllData = this.removeDuplicates(this.DivisionGenderWiseCategory, 'product_type_id');
      this.category1Dropdown = this.category1DropdownAllData;

      //will give selected category1 product_type_id as array name category1Selected   
      this.getCategory1SelectedArray();
      if (this.category1Selected.length > 0) {
        //reset category2Dropdown
        this.category2Dropdown = []
        this.showCategory4Dropdown = true
        //filter all the category4(rbu_id) which includes selected category1(product_type_id)
        let filteredCategory2 = this.DivisionGenderWiseCategory.filter(item => this.category1Selected.includes(item.product_type_id));
        this.category2Dropdown = this.removeDuplicates(filteredCategory2, 'rbu_id');
      }
    }
    if (this.categoryType == 2) {
      this.showCategory1Dropdown = false
      this.showCategory4Dropdown = true;
      //remove all duplicate category4(rbu_id)
      this.category2DropdownAllData = this.removeDuplicates(this.DivisionGenderWiseCategory, 'rbu_id');
      this.category2Dropdown = this.category2DropdownAllData;

      //will give selected category4 rbu_id as array name category4Selected   
      this.getCategory4SelectedArray();
      if (this.category4Selected.length > 0) {
        //reset category1Dropdown
        this.category1Dropdown = []
        this.showCategory1Dropdown = true
        //filter all the category1(product_type_id) which includes selected category4(rbu_id)
        let fileterdCategory1 = this.DivisionGenderWiseCategory.filter(item => this.category4Selected.includes(item.rbu_id));
        this.category1Dropdown = this.removeDuplicates(fileterdCategory1, 'product_type_id');
      }
    }
  }
  //this will list all category based on division and gender
  getCategoryData() {
    this.editedAnalysisArticleIndex = [];
    this.category1Dropdown.map(function (x) { x.checkedCategory1 = false; });
    this.category2Dropdown.map(function (x) { x.checkedCategory2 = false; });
    const division = parseInt(this.devisionId);
    const gender = parseInt(this.genderId);
    if (this.devisionId) {
      // console.log('this.genderId', this.genderId);
      // console.log('this.formatDivisionDetail[division]', this.formatDivisionDetail[division]);

      this.DivisionGenderWiseCategory = this.formatDivisionDetail[division].filter(item => this.genderId.includes(item.gender_id));
      // console.log('DivisionGenderWiseCategory', this.DivisionGenderWiseCategory);
      this.getCategoryDropDown();
    } else {
      this.common.openSnackBar('Please select the Division!!!', '', 'warning-snackbar')
    }

  }
  getCategory1SelectedArray() {
    this.category1Selected = [];
    // console.log("category1Selected", this.category1Dropdown)
    this.category1Dropdown.forEach(item => {
      if (item.checkedCategory1) {
        this.category1Selected.push(item.product_type_id);
      }
    });
  }
  getCategory4SelectedArray() {
    this.category4Selected = [];
    this.category2Dropdown.forEach(item => {
      if (item.checkedCategory2) {
        this.category4Selected.push(item.rbu_id);
      }
    });
  }
  public getEditedCategoryData(product_type_id, rbu_id) {
    this.showCategory1Dropdown = false;
    this.showCategory4Dropdown = false;

    this.category1DropdownAllData = this.removeDuplicates(this.DivisionGenderWiseCategory, 'product_type_id');
    this.category1DropdownAllData.find(item => item.product_type_id === product_type_id).checkedCategory1 = true;
    this.category1Dropdown = this.category1DropdownAllData;
    this.category2Dropdown = this.DivisionGenderWiseCategory.filter(item => item.product_type_id === product_type_id);
    this.category2Dropdown = this.removeDuplicates(this.category2Dropdown, 'rbu_id');
    this.category2Dropdown.find(item => item.rbu_id === rbu_id).checkedCategory2 = true;

    this.category2DropdownAllData = this.removeDuplicates(this.DivisionGenderWiseCategory, 'rbu_id');
    this.category2DropdownAllData.find(item => item.rbu_id === rbu_id).checkedCategory2 = true;
    this.category2Dropdown = this.category2DropdownAllData;
    this.category1Dropdown = this.DivisionGenderWiseCategory.filter(item => item.rbu_id === rbu_id);
    this.category1Dropdown = this.removeDuplicates(this.category1Dropdown, 'product_type_id');
    this.category1Dropdown.find(item => item.product_type_id === product_type_id).checkedCategory1 = true;

  }
  //called one edit of article analysis screen 
  getArticleDetailedData(rowIndex) {
    //set category 1 as priority default
    this.common.showSpinner();
    this.categoryType = 0
    this.devisionId = this.articleListDetails[rowIndex].division_id;
    // this.genderId = [2];
    this.genderId = this.genderDropdown.map(item => this.articleListDetails[rowIndex].gender_id);


    this.getCategoryData();
    this.getEditedCategoryData(this.articleListDetails[rowIndex].product_type_id, this.articleListDetails[rowIndex].rbu_id);
    Object.assign(this.articleListDetails[rowIndex], { store_id: this.storeId });
    //filter article from allArticleList
    this.articleList = this.allArticlesList.filter(item => item.divisionId == this.articleListDetails[rowIndex].division_id && item.genderId == this.articleListDetails[rowIndex].gender_id && item.productTypeId == this.articleListDetails[rowIndex].product_type_id && item.rbuId == this.articleListDetails[rowIndex].rbu_id);
    if (this.articleList.length == 0) {
      this.common.openSnackBar('No Articles Found!!!', '', 'warning-snackbar')
    }
    // console.log('articleList',this.articleList);
    this.filteredArticleListArray = this.articleList;
    this.common.hideSpinner();
  }

  saveOrderArticle(orderStatus) {
    let orderAllocationArray = []
    let filterArticleDetailsAllData = this.articleDetailsAllData.filter(x => x.currentAllocation > 0);
    filterArticleDetailsAllData.forEach(val => {
      let obj = {
        id: val.allocation_id,
        division_id: val.division_id,
        gender_id: val.gender_id,
        rbu_id: val.rbu_id,
        product_type_id: val.product_type_id,
        current_allocation: val.currentAllocation,
        sku: val.sku ? parseInt(val.sku) : 0,
        quantity: val.quantity ? parseInt(val.quantity) : 0,
        total_price: val.totalPrice ? parseInt(val.totalPrice) : 0,
        sgd_total_price: val.totalPrice ? (parseInt(val.totalPrice) * this.sgd).toFixed(2) : 0,
        usd_total_price: val.totalPrice ? (parseInt(val.totalPrice) * this.usd).toFixed(2) : 0
      }
      orderAllocationArray.push(obj)
    });
    // console.log(this.articleDetailsAllData)
    // console.log('this.filterArticleDetailsAllData', filterArticleDetailsAllData)

    // this.orderedArticles=[];
    // console.log('this.allArticlesList',this.allArticlesList)
    // let obj;
    // let userId = 1;
    // this.allArticlesList.forEach(val=>{
    //   val.storeData[0].size.forEach(val2=>{
    //     obj = {
    //       order_id: parseInt(this.orderId),
    //       store_id:parseInt(this.storeId),
    //       article_id: val.articleId,
    //       size_code: val2.size,
    //       quantity : val2.quantity,
    //       billing_value:val2.billingPrice,
    //       billing_value_total:val2.billingQuantityTotalValue,
    //       // created_user: userId,
    //       // created_date:new Date(),
    //       status : 1
    //       // created_date:new Date(),
    //       // type:3
    //     }
    //     this.orderedArticles.push(obj);
    //   })
    // })
    // console.log('this.orderedArticles', this.orderedArticles);
    // console.log('this.divisionWisePriceRange 121212', this.divisionWisePriceRange);

   // console.log('Before grandTotalBookingValue',this.grandTotalBookingValue);

    let ObjData = {
      order_id: parseInt(this.orderId),
      store_id: parseInt(this.storeId),
      franchiseId:this.franchiseId,
      franchiseName:this.franchiseName,
      customerTypeId:this.customerTypeId,
      order_status: orderStatus,
      current_booking_value: (this.grandTotalBookingValue),
      price_range_json: this.divisionWisePriceRange,
      // division_allocation:this.storeWiseAnalysis[0].division_allocation,
      // current_allocation:this.storeWiseAnalysis[0].current_allocation,
      orderedArticles: this.orderedArticles,
      orderAllocation: orderAllocationArray,
      allTotalSgd: this.grandTotalSgd,
      allTotalUsd: this.grandTotalUsd,
      allTotalSku: this.allTotalSku,
      allTotalQty: this.allTotalQty
    };
    //console.log('ObjData',ObjData);
    // console.log('After grandTotalBookingValue',this.grandTotalBookingValue);
    // return;
    if (orderStatus == 2) {
      this.common.openConfirmDialog('Are you sure you want to cancel the order?')
        .afterClosed().subscribe(res => {
          if (res) {
            this.spinner.show();
            this.ordersService.saveOrderArticle(ObjData, 1).subscribe(sResponse => {
              //console.log('cancel Orde data', sResponse);
              this.spinner.hide();
              if (sResponse) {
                this.router.navigate(['/orders/store-sales-analysis']);
                this.checkOrderStatus();
                this.common.openSnackBar('Order Canceled Successfully', '', 'success-snackbar');
                // console.log(data)
              }
              else {
                this.common.openSnackBar('Order Cancelelation Failed', '', 'danger-snackbar');
              }
            },
              sError => {
                this.common.apiError(sError);
              })
          }
        });
    }
    else {
      this.spinner.show();
      this.ordersService.saveOrderArticle(ObjData, 1).subscribe(data => {
        this.spinner.hide();
        this.router.navigate(['/orders/store-sales-analysis']);
        this.checkOrderStatus();
        //console.log(data)
      },
        sError => {
          this.common.apiError(sError);
        })
    }
  }
  submit() {

    this.getCategory1SelectedArray();
    this.getCategory4SelectedArray();
    // console.log('c2',this.category1Selected.toString())
    // console.log('c2',this.category4Selected.toString())

    // this.spinner.show();
    // const obj = {
    //   store_id :this.storeId,
    //   season_id:17,
    //   order_window_id:13,
    //   division_id:this.devisionId,
    //   product_type_id :this.category1Selected,
    //   rbu_id: this.category4Selected,
    //   gender_id: this.genderId,
    //   minPriceRange: 0,
    //   maxpriceRange: 10000
    // };
    // console.log('obj',obj)
    // this.getArticleDetailsApi(obj);
    // console.log('this.category1Selected.length', this.category1Selected.length);
    // console.log('this.category4Selected.length', this.category4Selected.length);
    // console.log('this.mandatoryArticleInput', this.mandatoryArticleInput);
    // console.log('this.devisionId', this.devisionId);
    // console.log('this.genderId', this.genderId);
    // console.log('this.suggestedArticleInput', this.suggestedArticleInput);

    //mandatory and suggested article code start

    // if (this.mandatoryArticleInput) {
    //   //if all four values are unselected and suggester is false 
    //   if ((this.devisionId == '' || this.devisionId==undefined)  && (this.genderId == '' || this.genderId==undefined) && this.category1Selected.length < 1 && this.category4Selected.length < 1 && (this.suggestedArticleInput==false || this.suggestedArticleInput==undefined)) {
    //     console.log("first if reached");

    //     // console.log('3')
    //     this.articleList = this.allArticlesList.filter(item => item.mandatoryArticle == 1)
    //     // this.common.openSnackBar('please Select all four field Gender,Division,Category1 and Category4','', 'danger-snackbar');
    //   }
    //   //if all four values are unselected and suggested is selected 
    //   else if((this.devisionId == '' || this.devisionId==undefined)  && (this.genderId == '' || this.genderId==undefined) && this.category1Selected.length < 1 && this.category4Selected.length < 1  && this.suggestedArticleInput==true){
    //     console.log("Second reached");
    //     let suggestedArticleList = this.allArticlesList.filter(item => item.suggestedArticle == 1);
    //     let mandatoryArticleList = this.allArticlesList.filter(item => item.mandatoryArticle == 1);
    //     suggestedArticleList.push.apply(suggestedArticleList, mandatoryArticleList);
    //     this.articleList = this.removeDuplicates(suggestedArticleList, 'articleId')
    //   }
    //   else {
    //     let mandatoryArticleList = this.allArticlesList.filter(item => item.mandatoryArticle == 1);
    //     let filterArticleList = this.allArticlesList.filter(item => item.divisionId == this.devisionId && item.genderId == this.genderId && this.category1Selected.includes(item.productTypeId) && this.category4Selected.includes(item.rbuId));
    //     filterArticleList.push.apply(filterArticleList, mandatoryArticleList);

    //     if (mandatoryArticleList.length < 1) {
    //       this.common.openSnackBar('No Mandatory Article Found ', '', 'danger-snackbar');
    //     }
    //     this.articleList = this.removeDuplicates(filterArticleList, 'articleId')
    //     // }
    //   }
    // }
    // else if (this.suggestedArticleInput) {
    //   //check all four is selected or not 
    //   if (this.devisionId == '' && this.genderId == '' && this.category1Selected.length < 1 && this.category4Selected.length < 1) {
    //     // console.log('3')
    //     this.articleList = this.allArticlesList.filter(item => item.suggestedArticle == 1)
    //     // this.common.openSnackBar('please Select all four field Gender,Division,Category1 and Category4','', 'danger-snackbar');
    //   }
    //   else {
    //     // if(this.devisionId=='' || this.genderId=='' || this.category1Selected.length<1 || this.category4Selected.length<1 ){
    //     //   // console.log('1')
    //     //   this.common.openSnackBar('please Select all four field Gender,Division,Category1 and Category4','', 'danger-snackbar');
    //     // }
    //     // else{
    //     // console.log('2')
    //     let suggestedArticleList = this.allArticlesList.filter(item => item.suggestedArticle == 1);
    //     let filterArticleList = this.allArticlesList.filter(item => item.divisionId == this.devisionId && item.genderId == this.genderId && this.category1Selected.includes(item.productTypeId) && this.category4Selected.includes(item.rbuId));
    //     filterArticleList.push.apply(filterArticleList, suggestedArticleList);

    //     if (suggestedArticleList.length < 1) {
    //       this.common.openSnackBar('No Suggested Article Found ', '', 'danger-snackbar');
    //     }
    //     this.articleList = this.removeDuplicates(filterArticleList, 'articleId')
    //     // }
    //   }
    // }
    // else {
    //   if (this.devisionId == '' || this.genderId == '' || this.category1Selected.length < 1 || this.category4Selected.length < 1) {
    //     // console.log('4')
    //     this.common.openSnackBar('please Select all four field Gender,Division,Category1 and Category4', '', 'danger-snackbar');
    //   }
    //   else {
    //     // console.log('5')
    //     this.articleList = this.allArticlesList.filter(item => item.divisionId == this.devisionId && item.genderId == this.genderId && this.category1Selected.includes(item.productTypeId) && this.category4Selected.includes(item.rbuId));
    //   }
    // }

    //mandatory and suggested article code end


    if (this.devisionId == '' || this.genderId == '' || this.category1Selected.length < 1 || this.category4Selected.length < 1) {
      // console.log('4')
      this.common.openSnackBar('please Select all four field Gender,Division,Category1 and Category4', '', 'danger-snackbar');
    }
    else {
      // console.log('5')
      this.articleList = this.allArticlesList.filter(item => item.divisionId == this.devisionId && this.genderId.includes(item.genderId) && this.category1Selected.includes(item.productTypeId) && this.category4Selected.includes(item.rbuId));
    }
    // console.log("filtered Article List", this.articleList);

    //filter article from allArticleList
    //create copy for filtering article list
    this.filteredArticleListArray = this.articleList
  }

  //get called change of quantity
  updateRightPannelAnalysis(index, size) {
    // console.log('this.articleList[index]', this.articleList[index]);
    //console.log('updateRightPannelAnalysis', this.articleDetailsAllData);
  //console.log('articleList', this.articleList);
    this.orderedArticles
    // console.log('size',size);
    let filterSelectedSizeDetails = this.articleList[index].storeData[0].size.find(item => item.size == size);
    // console.log('filterSelectedSizeDetails',filterSelectedSizeDetails);
    let checkifAlready;
    if (this.orderedArticles.length > 0) {
      checkifAlready = this.orderedArticles.find(item => item.article_id == this.articleList[index].articleId && item.size_code == size && item.ord_launch_month == this.articleList[index].launchMonth);
    }
    let obj = {
      order_id: parseInt(this.orderId),
      store_id: parseInt(this.storeId),
      article_id: this.articleList[index].articleId,
      ord_launch_month: this.articleList[index].launchMonth,
      size_code: filterSelectedSizeDetails.size,
      quantity: parseInt(filterSelectedSizeDetails.quantity),
      billing_value: this.articleList[index].billingValue,
      billing_value_total: math.number(this.articleList[index].billingValue) * math.number(filterSelectedSizeDetails.quantity),
      sgd_value: (math.number(this.articleList[index].billingValue) * this.sgd).toFixed(2),
      sgd_value_total: ((math.number(this.articleList[index].billingValue) * math.number(filterSelectedSizeDetails.quantity)) / this.sgd).toFixed(2),
      usd_value: (math.number(this.articleList[index].billingValue) * this.usd).toFixed(2),
      usd_value_total: ((math.number(this.articleList[index].billingValue) * math.number(filterSelectedSizeDetails.quantity)) / this.usd).toFixed(2),
      // created_user: userId,
      // created_date:new Date(),
      status: 1
      // created_date:new Date(),
      // type:3
    }
    // console.log('checkifAlready', checkifAlready);
    if (checkifAlready != undefined) {
      this.orderedArticles.splice(this.orderedArticles.findIndex(item => item.article_id == this.articleList[index].articleId && item.size_code == size && item.ord_launch_month == this.articleList[index].launchMonth), 1)
      this.orderedArticles.push(obj);
    }
    else {
      this.orderedArticles.push(obj);
    }
    // console.log('orderedArticles',this.orderedArticles);
    //update into allArticleList
    this.allArticlesList.find(item => item.articleId == this.articleList[index].articleId && item.launchMonth == this.articleList[index].launchMonth).storeData = this.articleList[index].storeData;
    // this.getUpdatedArticleList();
    this.calculateBookingValue();
    this.calculateCurrentAllocation(index);
    //this function will calculate current allocation division wise and total current allocation 
    this.calculatePriceRangeAnalysis(this.articleList[index].divisionId, this.articleList[index].priceRangeId);
    this.calculateBookingQtyTotal(index);
  }
  calculateBookingQtyTotal(index) {
    //console.log("ss", this.articleList[index]);
    let totalQuantity = this.articleList[index].storeData[0].size.reduce((a, { quantity }) => math.number(a) + math.number(quantity), 0);
    let objOrderSummary = {
      article_id: this.articleList[index].articleId,
      sku: this.articleList[index].sku,
      ord_launch_month: this.articleList[index].launchMonth,
      quantity: totalQuantity,
      billingValue: this.articleList[index].billingValue,
      totalPrice: (totalQuantity * this.articleList[index].billingValue).toFixed(2),
      totalUsd: ((totalQuantity * this.articleList[index].billingValue) * this.usd).toFixed(2),
      totalSgd: ((totalQuantity * this.articleList[index].billingValue) * this.sgd).toFixed(2),
      articleDescription: this.articleList[index].articleDescription
    };
    let checkifAlready;
    if (this.orderSummaryList.length > 0) {
      checkifAlready = this.orderSummaryList.find(item => item.article_id == this.articleList[index].articleId && item.ord_launch_month == this.articleList[index].launchMonth);
    }
    if (checkifAlready != undefined) {
      this.orderSummaryList.splice(this.orderSummaryList.findIndex(item => item.article_id == this.articleList[index].articleId && item.ord_launch_month == this.articleList[index].launchMonth), 1)
      this.orderSummaryList.push(objOrderSummary);
    }
    else {
      this.orderSummaryList.push(objOrderSummary);
    }
    this.calculateTotalQtyNew(this.orderSummaryList);
    let filtered = this.allArticlesList.find(item => item.articleId == this.articleList[index].articleId);
    filtered.storeData[0].size.forEach(item => {
      if (parseInt(item.quantity) > 0) {
        item.billingQuantityTotalValue = math.number(item.quantity) * math.number(this.articleList[index].billingValue);
        item.billingPrice = this.articleList[index].billingValue;
      }
      else {
        item.billingQuantityTotalValue = 0;
        item.billingPrice = 0;
      }
    })
  }
  //current allocation calculate based on category ,division and gender 
  calculateCurrentAllocation(index) {

    //filter article to calculate qty  
    let filterArtcile = this.allArticlesList.filter(item => item.divisionId === this.articleList[index].divisionId && item.genderId === this.articleList[index].genderId && item.productTypeId === this.articleList[index].productTypeId && item.rbuId === this.articleList[index].rbuId);
    //current edited article list all calculation
    let articleListQuantityTotal = []
    filterArtcile.forEach(item => {
      // console.log(item.storeData[0].size);
      if (item.storeData.length > 0) {
        const temp = item.storeData[0].size.reduce((prev, cur) => {
          return {
            quantity: math.number(prev.quantity) + math.number(cur.quantity),
            totalQuantity: math.number(prev.totalQuantity) + math.number(cur.totalQuantity),
            price: item.billingValue,
            totalPrice: math.number(prev.quantity) * math.number(item.billingValue),
          }
        });
        articleListQuantityTotal.push(temp)
      }

    });
     console.log('articleListQuantityTotal',articleListQuantityTotal);
    const totalQuantity = articleListQuantityTotal.reduce((a, { quantity }) => math.number(a) + math.number(quantity), 0);
    const totalPrice = articleListQuantityTotal.filter(({ quantity }) => quantity > 0).reduce((a, { price }) => math.number(a) + math.number(price), 0);
    const totalSku = articleListQuantityTotal.filter(({ quantity }) => quantity > 0).reduce((a) => math.number(a) + 1, 0);
    // console.log('totalQuantity',totalQuantity);
    // console.log('totalPrice',totalPrice);
    // console.log('totalSku',totalSku);

    const curAllocation = articleListQuantityTotal.reduce((a, { totalPrice }) => math.number(a) + math.number(totalPrice), 0);
    //to update curent allocation need to filter based on curent article index
    let filteredArticleArray = this.articleDetailsAllData.find(item => item.gender_id === this.articleList[index].genderId && item.division_id === this.articleList[index].divisionId && item.product_type_id === this.articleList[index].productTypeId && item.rbu_id === this.articleList[index].rbuId);
    filteredArticleArray.currentAllocation = curAllocation;
    filteredArticleArray.sku = totalSku;
    filteredArticleArray.quantity = totalQuantity;
    filteredArticleArray.totalPrice = totalPrice;
    //console.log('curAllocation',curAllocation);
    
    let x = parseFloat(this.grandTotalBookingValue);
    
    this.grandTotalBookingValue = parseFloat(this.grandTotalBookingValue) + curAllocation;
    //console.log('grandTotalBookingValue_Onchange',this.grandTotalBookingValue);
    
    //change color if current allocation exceeded with estimated allocation
    if (curAllocation > filteredArticleArray.price) {
      document.getElementById("currentAllocation_" + filteredArticleArray.allocation_id).style.color = "green";
    }
    else {
      document.getElementById("currentAllocation_" + filteredArticleArray.allocation_id).style.color = "red";
    }
  }
  //calculate division wise current allocation and current booking value
  calculateBookingValue() {
    let divisionWiseSum = []
    //divisionDropdown have all the division
    //console.log('devisionDropdown',this.devisionDropdown);
    this.devisionDropdown.forEach(val => {
      //will filter all curent allocation value based on division id
      let divisionWiseData = this.articleDetailsAllData.filter(item => item.division_id == val.id);
      //calulate sum of all curent allocation value based on division id
      //console.log('divisionWiseData',divisionWiseData);
      const totalAllocation = divisionWiseData.reduce((a, { currentAllocation }) => math.number(a) + math.number(currentAllocation), 0);
      //console.log('totalAllocation',totalAllocation);
      
      //set totalAllocation to currosponding division
      let x='total_billing_'+val.id;
      //console.log('this.storeWiseAnalysis[0][x]',this.storeWiseAnalysis[0][x]);
      this.currentBookingValueDivisionWise[val.id + this.storeWiseAnalysis[0].id] = formatNumber(this.storeWiseAnalysis[0][x], this.locale, '1.0-0');
      //push 
      //console.log('currentBookingValueDivisionWise',this.currentBookingValueDivisionWise);
      divisionWiseSum.push({ currentAllocation: totalAllocation })
    })
    // console.log( ' this.storeWiseAnalysis[0]',this.storeWiseAnalysis[0]);
    //total Current Booking Value    
    
    let tempCurrentBookingValue = Math.round(divisionWiseSum.reduce((a, { currentAllocation }) => math.number(a) + math.number(currentAllocation), 0));
    // this.currentBookingValue[this.storeWiseAnalysis[0].id] = divisionWiseSum.reduce((a, { currentAllocation }) => math.number(a) + math.number(currentAllocation), 0);
    // this.currentBookingValue[this.storeWiseAnalysis[0].id] = formatNumber(tempCurrentBookingValue, this.locale, '1.0-0');
    
    this.currentBookingValue = formatNumber(this.storeWiseAnalysis[0].billing_value_total, this.locale, '1.0-0');
    console.log('sgd',this.sgd);
    console.log('sgd',this.sgd);
    this.allTotalSgd = formatNumber(this.storeWiseAnalysis[0].billing_value_total * this.sgd, this.locale, '1.0-0');
    this.allTotalUsd = formatNumber(this.storeWiseAnalysis[0].billing_value_total * this.usd, this.locale, '1.0-0');

    this.grandTotalBookingValue = this.storeWiseAnalysis[0].billing_value_total;
    this.grandTotalSgd = (this.storeWiseAnalysis[0].billing_value_total * this.sgd).toFixed(2);
    this.grandTotalUsd = (this.storeWiseAnalysis[0].billing_value_total * this.usd).toFixed(2);

  }

  //price range calculate 
  calculatePriceRangeAnalysis(divisionId, priceRangeId) {
    let filterArticle = this.allArticlesList.filter(item => item.divisionId == divisionId && item.priceRangeId == priceRangeId)
    let calculateSum = []
    filterArticle.forEach(val => {
      if (val.storeData.length > 0) {
        const temp = val.storeData[0].size.reduce((prev, cur) => {
          return {
            quantity: math.number(prev.quantity) + math.number(cur.quantity),
            price: val.billingValue,
            totalPrice: math.number(prev.quantity) * math.number(val.billingValue),
            totalUsd: ((math.number(prev.quantity) * math.number(val.billingValue)) * this.usd).toFixed(2),
            totalSgd: ((math.number(prev.quantity) * math.number(val.billingValue)) * this.sgd).toFixed(2)
          }
        });
        calculateSum.push(temp)
      }
    })
    // console.log('calculateSum',calculateSum)
    const totalQuantity = calculateSum.reduce((a, { quantity }) => math.number(a) + math.number(quantity), 0);
    const totalPrice = calculateSum.reduce((a, { totalPrice }) => math.number(a) + math.number(totalPrice), 0);
    const totalUsd = calculateSum.reduce((a, { totalUsd }) => math.number(a) + math.number(totalUsd), 0);
    const totalSgd = calculateSum.reduce((a, { totalSgd }) => math.number(a) + math.number(totalSgd), 0);
    const totalSku = calculateSum.filter(({ quantity }) => quantity > 0).reduce((a) => math.number(a) + 1, 0);

    let selectedPriceRange = this.divisionWisePriceRange.find(item => item.divisionId === divisionId);
    selectedPriceRange.priceRange.find(item => item.id == priceRangeId).totalPrice = totalPrice;
    selectedPriceRange.priceRange.find(item => item.id == priceRangeId).totalUsd = totalUsd;
    selectedPriceRange.priceRange.find(item => item.id == priceRangeId).totalSgd = totalSgd;
    selectedPriceRange.priceRange.find(item => item.id == priceRangeId).quantity = totalQuantity;
    selectedPriceRange.priceRange.find(item => item.id == priceRangeId).sku = totalSku;
    // console.log('selectedPriceRange',selectedPriceRange);
    // this.calculateAllTotalSkuAndQty();
  }
  calculateAllTotalSkuAndQty() {
    // console.log('this.divisionWisePriceRange',this.divisionWisePriceRange);
    this.allTotalQty = 0;
    this.allTotalSku = 0;
    this.divisionWisePriceRange.forEach(val => {
      this.allTotalQty += val.priceRange.reduce((a, { quantity }) => math.number(a) + math.number(quantity), 0);
      this.allTotalSku += val.priceRange.reduce((a, { sku }) => math.number(a) + math.number(sku), 0);

    });
    // console.log(this.allTotalQty);

  }
  onPageLoadAnalysisCalculation() {
    //calculate current allocation
    // console.log('I have reched  ', this.articleDetailsAllData);
    // console.log('I have reched here and length is ', this.articleDetailsAllData.length)
    this.articleDetailsAllData.forEach(val => {
      let filterArtcile = this.allArticlesList.filter(item => item.divisionId === val.division_id && item.genderId === val.gender_id && item.productTypeId === val.product_type_id && item.rbuId === val.rbu_id);
      //current edited article list all calculation
      let articleListQuantityTotal = []
      filterArtcile.forEach(item => {
        if (item.storeData.length > 0) {
          const temp = item.storeData[0].size.reduce((prev, cur) => {
            return {
              quantity: math.number(prev.quantity) + math.number(cur.quantity),
              totalQuantity: math.number(prev.totalQuantity) + math.number(cur.totalQuantity),
              price: item.billingValue,
              totalPrice: math.number(prev.quantity) * math.number(item.billingValue),
              totalUsd: ((math.number(prev.quantity) * math.number(item.billingValue)) * this.usd).toFixed(2),
              totalSgd: ((math.number(prev.quantity) * math.number(item.billingValue)) * this.sgd).toFixed(2)
            }
          });
          articleListQuantityTotal.push(temp)
        }

      })
      //console.log('',articleListQuantityTotal);
      
      const curAllocation = articleListQuantityTotal.reduce((a, { totalPrice }) => math.number(a) + math.number(totalPrice), 0);
      const totalQuantity = articleListQuantityTotal.reduce((a, { quantity }) => math.number(a) + math.number(quantity), 0);
      const totalUsd = articleListQuantityTotal.reduce((a, { totalUsd }) => math.number(a) + math.number(totalUsd), 0);
      const totalSgd = articleListQuantityTotal.reduce((a, { totalSgd }) => math.number(a) + math.number(totalSgd), 0);
      const totalSku = articleListQuantityTotal.filter(({ quantity }) => quantity > 0).reduce((a) => math.number(a) + 1, 0);

      //to update curent allocation need to filter based on curent article index
      let filteredArticleArray = this.articleDetailsAllData.find(item => item.gender_id === val.gender_id && item.division_id === val.division_id && item.product_type_id === val.product_type_id && item.rbu_id === val.rbu_id);
      filteredArticleArray.currentAllocation = curAllocation || 0;
      filteredArticleArray.quantity = totalQuantity || 0;
      filteredArticleArray.sku = totalSku | 0;
      filteredArticleArray.totalPrice = curAllocation || 0;
      filteredArticleArray.totalSgd = totalSgd || 0;
      filteredArticleArray.totalUsd = totalUsd || 0;
      // filteredArticleArray.
      //change color if current allocation exceeded with estimated allocation
      if (curAllocation > filteredArticleArray.price) {
        document.getElementById("currentAllocation_" + filteredArticleArray.allocation_id).style.color = "green";
      }
      //hide after all calculation
      // else{
      //   document.getElementById("currentAllocation_"+filteredArticleArray.allocation_id).style.color = "red";
      // }
    })

    this.calculateBookingValue();
    
    //calculate price range 
    this.divisionWisePriceRange.forEach(val => {
      val.priceRange.forEach(val2 => {
        this.calculatePriceRangeAnalysis(val.divisionId, val2.id)
      })
    })
  }

  //get data coming from target entry screen
  getArticleDetails() {
    // console.log('this.orderNum', this.orderId);
    this.targetService.getOrderAlocations(this.orderId).subscribe(sResponse => {
      this.targetOrderList = sResponse.data;
      // console.log('from target screen data', sResponse.data);
      this.targetOrderList.forEach((val) => {
        //concatination all divisions details into one array
        this.articleDetailsAllData.push.apply(this.articleDetailsAllData, val.divisionBreak);
        //creating divisions
        let divObj = {
          id: val.division_id,
          name: val.division_name,
        }
        this.devisionDropdown.push(divObj);
        //pust id 
        this.divisionIdList.push(val.division_id);
        //divsion wise gender is declared hear
        this.divisionWiseGender[val.division_id] = val.divisionGender;
        val.divisionGender.forEach(val => {
          this.allGender.push(val)
        })
        this.genderDropdown = val.divisionGender
        this.formatDivisionDetail[val.division_id] = val.divisionBreak;
      })
      //sort the data
      
      
      this.articleDetailsAllData.sort((a, b) =>
        (a.divsionname > b.divsionname) ? 1 : (a.divsionname === b.divsionname) ? ((a.producttypename > b.producttypename) ? 1 : (a.producttypename === b.producttypename) ? ((a.rbuname > b.rbuname) ? 1 : -1) : -1) : -1)
    },
      sError => {
        this.common.apiError(sError);
      })
    // console.log(this.formatDivisionDetail);
    this.articleListDetails = this.articleDetailsAllData;
    //console.log('articleListDetails',this.articleListDetails);
    this.getArticleDetailsApi();
  }
  //get article list master data
  public getArticleDetailsApi() {

    const obj1 = {
      store_id: this.storeId,
      order_id: this.orderId,
      season_id: this.seasonId,
      order_window_id: this.orderWindowId,
      brand_id: this.brandId,
      accessPriority: this.accessPriority,
      countryId: this.countryId,
      ratio: this.ratio,
      franchiseId: this.franchiseId
    };
    // console.log('getArticleDetailsApi', obj1);
    // let filteredData=[]
    this.ordersService.getArticleDetails(obj1).subscribe(sResponse => {
      // console.log('getArticleDetails response', sResponse.data);

      if (!sResponse.status) {
        this.common.openSnackBar(sResponse.trace, '', 'danger-snackbar');
      }
      if (sResponse.data) {
        // console.log("all article list ", sResponse.data);
        this.allArticlesList = sResponse.data;
        //console.log( 'articleList',this.allArticlesList);
        
        //loop all article list
        this.allArticlesList.forEach(val => {
          //count total quantity of all sizes of each article's 
          // console.log('error');
          // console.log(val);
          if (val.storeData.length > 0) {
            let totalQuantity = val.storeData[0].size.reduce((a, { quantity }) => math.number(a) + math.number(quantity), 0);
            //check if quantity is greater that 0 then push into order summary
            if (totalQuantity > 0) {
              let objOrderSummary = {
                article_id: val.articleId,
                sku: val.sku,
                ord_launch_month: val.launchMonth,
                quantity: val.storeData[0].size.reduce((a, { quantity }) => math.number(a) + math.number(quantity), 0),
                billingValue: val.billingValue,
                totalPrice: (totalQuantity * val.billingValue).toFixed(2),
                totalUsd: ((totalQuantity * val.billingValue) * this.usd).toFixed(2),
                totalSgd: ((totalQuantity * val.billingValue) * this.sgd).toFixed(2),
                articleDescription: val.articleDescription
              }
              this.orderSummaryList.push(objOrderSummary);
            }
          }
          // console.log(this.divisionWisePriceRange);

          let filterPriceRangeDivisionWise = this.divisionWisePriceRange.filter(item => item.divisionId === val.division);
          //let priceRangeRow = filterPriceRangeDivisionWise[0].priceRange.filter(x => x.min <= val.amount && x.max >= val.amount);
          let priceRangeRow = filterPriceRangeDivisionWise[0].priceRange.filter(x => x.min <= val.localBillingValue && x.max >= val.localBillingValue);
          Object.assign(val, { priceRangeId: priceRangeRow[0] && priceRangeRow[0].id ? priceRangeRow[0].id : 0 })
        })
        console.log('this.orderSummaryList',this.orderSummaryList);
        
        this.calculateTotalQtyNew(this.orderSummaryList);
        this.spinner.hide();
        //filter selected division
        if (this.divisionIdList.length > 0) {
          this.divisionWisePriceRange = this.divisionWisePriceRange.filter(item => this.divisionIdList.includes(item.divisionId));
          // console.log(this.divisionWisePriceRange);
        }
        //fetch storename from first record this.articleList[0] to display storename in view
        this.storeList = this.allArticlesList[0].storeData;
        //
        this.ordersService.getStoreWiseAllocation(this.orderId).subscribe((sResponse: any) => {
           console.log('getStoreWiseAllocation', sResponse.data)
          this.storeWiseAnalysis = sResponse.data;
          this.currentStoreName = this.storeWiseAnalysis[0].store_name;
          this.copyStoreFromId = this.storeId;
          this.onPageLoadAnalysisCalculation();

        })
      }
      else {
        // console.log("no article found")
      }
    },
      sError => {
        this.common.apiError(sError);
      })
  }

  copyStore() {
    if (this.copyStoreToId == undefined) {
      this.common.openSnackBar('Please Select Store Id to Copy..', '', 'danger-snackbar');
    }
    else {
      let obj = {
        seasonId: this.seasonId,
        orderWindowId: this.orderWindowId,
        franchiseeId: this.franchiseId,
        order_id: this.orderId,
        copyStoreFromId: parseInt(this.storeId),
        copyStoreToId: parseInt(this.copyStoreToId),
        created_user: 1,
        created_date: new Date(),
      }
      //check already have ordered for this store
      let object = {
        seasonId: this.seasonId,
        orderWindowId: this.orderWindowId,
        franchiseeId: this.franchiseId,
        brandId: this.brandId,
        storeId: this.copyStoreToId
      }
      this.targetService.getOrder(object.seasonId, object.orderWindowId, object.franchiseeId, object.storeId, object.brandId).subscribe((sResponse: any) => {
        let data = sResponse.data;
        let storeData = this.franchiseStoreList.filter(item => item.store_id == this.copyStoreToId)
        
        if (data.length > 0) {
          //already 
          this.common.openConfirmDialog('Already Order Existing for "' + storeData[0].store_name + '" Store. Do you want to overwrite?')
            .afterClosed().subscribe(res => {
              if (res) {
                this.ordersService.copyStoreData(obj).subscribe(copyStoreData => {
                  // console.log('copystore', copyStoreData)
                  if (copyStoreData) {
                    this.common.openSnackBar('Successfully Copied!!!', '', 'success-snackbar');
                  }
                },
                  sError => {
                    this.common.apiError(sError);
                  })
              }
            });
        }
        else {

          this.common.openConfirmDialog('Do you want to copy from "' + this.currentStoreName + '" store to "' + storeData[0].store_name + '" store?')
            .afterClosed().subscribe(res => {
              if (res) {
                this.ordersService.copyStoreData(obj).subscribe(copyStoreData2 => {
                  // console.log('copystore', copyStoreData2)
                  if (copyStoreData2) {
                    this.common.openSnackBar('Successfully Copied!!!', '', 'success-snackbar');
                  }
                },
                  sError => {
                    this.common.apiError(sError);
                  })
              }
            });
        }
        // console.log('data',data);
      },
        sError => {
          this.common.apiError(sError);
        })
    }
  }
  indexTracker(index: number, row: any) {
    return index;
  }
  public getMasterPriceRange() {
    this.ordersService.getArticlePriceRangeDivisionWise().subscribe(data => {
      this.divisionWisePriceRange = data.data;
      // console.log('this.divisionWisePriceRange', this.divisionWisePriceRange);

    },
      sError => {
        this.common.apiError(sError);
      })
  }

  public calculateTotalQtyNew(orderSummaryList){
    //console.log('orderSummaryList',orderSummaryList)

    this.allTotalQty = 0;
    this.allTotalSku = orderSummaryList.length;
    this.allTotalQty += orderSummaryList.reduce((a, { quantity }) => math.number(a) + math.number(quantity), 0);
    console.log('this.allTotalQty',this.allTotalQty);
    // this.allTotalSku += val.priceRange.reduce((a, { sku }) => math.number(a) + math.number(sku), 0);

    
  }
}
