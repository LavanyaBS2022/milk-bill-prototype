import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArticleBookingComponent } from './article-booking.component';

describe('ArticleBookingComponent', () => {
  let component: ArticleBookingComponent;
  let fixture: ComponentFixture<ArticleBookingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArticleBookingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArticleBookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
