import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StoreSalesAnalysisComponent } from './store-sales-analysis.component';

describe('StoreSalesAnalysisComponent', () => {
  let component: StoreSalesAnalysisComponent;
  let fixture: ComponentFixture<StoreSalesAnalysisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StoreSalesAnalysisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StoreSalesAnalysisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
