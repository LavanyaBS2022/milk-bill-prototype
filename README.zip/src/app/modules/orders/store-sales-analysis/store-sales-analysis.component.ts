import { Component, OnInit, ViewChild, Inject, LOCALE_ID } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatDialogTitle, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { OrdersService } from './../../../shared/service/orders/orders.service';
import { Router } from '@angular/router';
import { Common } from '../../../shared/service/common/common';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { formatNumber } from '@angular/common';
import { saveAs } from 'file-saver';
import { DialogOrderHistoryComponent } from '../../../shared/components/dialog-order-history/dialog-order-history.component';
import { NgxSpinnerService } from "ngx-spinner";


@Component({
  selector: 'orderWindowPopUp',
  templateUrl: 'orderWindowPopUp.html',
  styleUrls: ['./orderwindow-popup.scss']
})
export class DialogOrderWindowPopUpComponent {
  constructor(
    public dialogRef:MatDialogRef<DialogOrderWindowPopUpComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  onNoClick(): void {
    this.dialogRef.close();
  }
}

@Component({
  selector: 'app-store-sales-analysis',
  templateUrl: './store-sales-analysis.component.html',
  styleUrls: ['./store-sales-analysis.component.scss']
})
export class StoreSalesAnalysisComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  displayedColumns: string[] = ['sNo', 'store_name', 'order_no', 'order_date', 'orderValue', 'totalSku', 'totalQuantity', 'order_status','set_target', 'Actions'];
  public orderReviewForm: FormGroup;
  public orderReviewId: any;
  public orderReviewData: any;
  public divisionWisePriceRange = [];
  public orderReviewAllocationData: any;
  public isDisplay: boolean = false;
  public showOrderMIS: boolean = false;
  public franchiseId;
  public orderWindowId;
  public seasonId;
  public brandId;
  public countryId;
  public orderWindowName;
  public storeList = new MatTableDataSource();

  constructor(private spinner:NgxSpinnerService,private orderSrv: OrdersService, @Inject(LOCALE_ID) private locale: string, private ordersService: OrdersService, private router: Router, public dialog: MatDialog, public common: Common, private formBuilder: FormBuilder) {

    // // console.log('franchiseId',this.franchiseId);
    let userDetails = this.common.getUserDetails();
    this.seasonId = userDetails.seasonId;
    this.orderWindowId = userDetails.orderWindowId;
    this.franchiseId = userDetails.franchiseId;
    this.brandId = userDetails.brandId;
    this.countryId=userDetails.countryId;
    this.orderWindowName=userDetails.orderWindowName;
    
    // console.log('franchiseId', this.franchiseId);
    // console.log('orderWindowId', this.orderWindowId);
    // console.log('seasonId', this.seasonId);
  }

  ngOnInit() {
    //Order MIS Form 
    this.orderReviewForm = this.formBuilder.group({
      orderID: [''],
      franchiseeName: [''],
      storeName: [''],
      location: [''],
      bookingValue: [''],
      season: [''],
      remarks: ['']
    });

    this.getStoreListData();
  }
  public get get() {
    return this.orderReviewForm.controls;
  }
  public getOrderReviewDetailsData(orderReviewId: any) {
    this.ordersService.getOrderReviewDetails(orderReviewId).subscribe((data) => {
      // console.log('TOTAL DATA:', data.data);
      this.orderReviewData = data.data.orderReviewPriceRange;
      // // console.log('Order Review Details Data:', this.orderReviewData);
      this.orderReviewForm.patchValue({
        orderID: this.orderReviewData[0].order_no,
        franchiseeName: this.orderReviewData[0].franchise_name,
        storeName: this.orderReviewData[0].store_name,
        location: this.orderReviewData[0].address,
        bookingValue: formatNumber(this.orderReviewData[0].current_allocation, this.locale, '1.0-0'),
        season: this.orderReviewData[0].season_name,
      });
      this.divisionWisePriceRange = JSON.parse(this.orderReviewData[0].price_range_json);
      // // console.log('Divisionwise Price RANGE:', this.divisionWisePriceRange);
      this.orderReviewAllocationData = data.data.orderAllocationData;
      this.showOrderMIS = true
      // // console.log('Order Allocation Data:', this.orderReviewAllocationData);
    },
      sError => {
        this.common.apiError(sError);
      });
    this.isDisplay = false;
  }

  onOrderReviewProcess(reviewStatusId) {
    this.orderReviewForm.value['review_status_id'] = reviewStatusId;
    const postData = JSON.parse(JSON.stringify(this.orderReviewForm.value));
    // // console.log('post data:', postData);    
    this.ordersService.postOrderReviewProcess(postData).subscribe((data) => {
      if (data.status) {
        this.router.navigate(['orders/listFranchiseeOrder']);
        this.common.openSnackBar(`Order No: ORD_${data.data[0].id} Approved !!!`, '', 'success-snackbar');
      } else {
        this.common.openSnackBar('Order Review Process Error', '', 'danger-snackbar');
      }
    },
      sError => {
        this.common.apiError(sError);
      });

  }
  public getStoreListData() {

    this.ordersService.getFranchiseStoreListNew(this.franchiseId, this.orderWindowId, this.seasonId, this.brandId).subscribe(
      sResponseModel => {
        //console.log('store sale data', sResponseModel)
        if (sResponseModel.data != false) {
          //console.log("store list data", sResponseModel.data);
          this.storeList.data = sResponseModel.data;
          this.storeList.sort = this.sort;
          this.storeList.paginator = this.paginator;
        }
        else {
          this.common.openSnackBar('No record found', '', 'danger-snackbar');
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }
  applyFilter(filterValue: string) {
    this.storeList.filter = filterValue.trim().toLowerCase();
  }


  getOrderStatusData(orderId) {
    if (orderId) {
      this.ordersService.getOrderHistoryStatus(orderId).subscribe((sResponse: any) => {
        const orderList = sResponse.data;
        if (orderList) {
          this.openOrderStatusViewDialog(orderList)
        } else {
          this.common.openSnackBar('No data to display !!', '', 'success-snackbar')
        }

      }, sError => {
        this.common.openSnackBar('Error while loading data !!', '', 'danger-snackbar')

      })
    }

  }

  openOrderStatusViewDialog(orderList) {
    const dialogRef = this.dialog.open(DialogOrderHistoryComponent, {
      maxWidth: '800px',
      width: '800px',
      data: orderList,
    })
  }

  //Commented Start
  //Rajendran Commented for Copy Store feature for Approved and Pending Order status also
  // public editStore(storeId, order_no, brand_id) {
  //   // // console.log(storeId,order_no)
  //   // const store_id = storeId;
  //   // const franchise_id = franchiseId;
  //   // this.router.navigate(['/orders/target-sales'], { queryParams: { store_id,franchise_id } });

  //   this.router.navigate(['orders/article-booking'], { queryParams: { orderId: order_no, storeId: storeId, brandId: brand_id } });

  //   // this.router.navigate(['/orders/target-sales'], { queryParams: { store_id,franchise_id } });
  // }
  // Comment End

  //Rajendran Modified Start for Asics Demo Feedback changes task
  public editStore(storeId, order_no, brand_id, order_status) {
    // console.log('order_status:', order_status);

    this.router.navigate(['orders/article-booking'], { queryParams: { orderId: order_no, storeId: storeId, brandId: brand_id, orderStatus: order_status } });
  }
  //Modified End

  public setTarget(storeId, franchiseId, brandId) {
    const store_id = storeId;
    const franchise_id = franchiseId;
    const brand_id = brandId;
    this.router.navigate(['/orders/target-sales'], { queryParams: { store_id, franchise_id, brand_id } });
  }

  //Rajendran Commented for Asics Demo Feedback changes task.//Comment Start
  // checkEditBtnVisibility(order_status, expected_gross_sell) {
  //   if (expected_gross_sell == '' || order_status == 'Approved' || order_status == 'Cancelled' || order_status == 'Pending for Review') {
  //     return false;
  //   }
  //   else {
  //     return true;
  //   }
  // }
  //Comment End

  //Rajendran Added for Copy Store option required for Review and Approved status order also
  checkEditBtnVisibility(order_status, expected_gross_sell) {
    // expected_gross_sell == '' ||
    if (order_status == 'Cancelled' || order_status == '') {
      return false;
    }
    else {
      return true;
    }
  }
  //Added End

  checkViewBtnVisibility(bookingBudget, order_status) {
    if (bookingBudget > 0 && order_status != 'Pending for Review') {
      return true;
    }
    else {
      return false;
    }
  }
  checkSetTargetBtnVisibility(order_status) {
    if (order_status == 'Approved' || order_status == 'Cancelled' || order_status == 'Rejected' || order_status == 'Pending for Review') {
      return false;
    }
    else {
      return true;
    }
  }

  downLoadOreders(orderId,storeId){
    //this.openDialog(orederId,storeId);
    let userDetails = this.common.getUserDetails();
    let fileType;
    if(userDetails.orderWindowType==1){
      fileType='footwareConsolidatedOrders'
    }else if(userDetails.orderWindowType==2){
      fileType='apparelEquipmentConsolidatedOrders'
    }
    let dataObj={
      fileType:fileType,
      seasonId:this.seasonId,
      orderWindowId:this.orderWindowId,
      brandId:this.brandId,
      franchiseId:this.franchiseId,
      orderId:orderId,
      storeId:storeId,
      countryId:this.countryId
    }
    console.log('dataobjec',dataObj);
    this.ordersService.exportSubmitedOrders(dataObj).subscribe((sResponse:any)=>{
      //console.log('response',sResponse);
      if (sResponse) {
       const fileName = this.orderWindowName.replace(/\s+/g,"_");

       saveAs(sResponse, fileName+'_Review' + '.xlsx');
       this.common.openSnackBar('File Downloaded!!!', '', 'success-snackbar');
       this.common.hideSpinner();
     }
   },sError => {
     this.common.openSnackBar('Error while loading data !!', '', 'danger-snackbar')
   });
    
  }

  openDialog(order_id,store_id): void {
    const dialogRef = this.dialog.open(DialogOrderWindowPopUpComponent, {
      disableClose: true,
      width: '800px',
      data: {
        fileType:'footwareConsolidatedOrders',
        orderId:order_id,
        storeId:store_id
      }
    });
    dialogRef.afterClosed().subscribe(result => {
     // console.log('The dialog was closed', result);
      let dataObj={
        fileType:result.fileType,
        seasonId:this.seasonId,
        orderWindowId:this.orderWindowId,
        brandId:this.brandId,
        franchiseId:this.franchiseId,
        orderId:result.orderId,
        storeId:result.storeId,
        countryId:this.countryId
      }
      console.log('dataobjec',dataObj);
      this.ordersService.exportSubmitedOrders(dataObj).subscribe((sResponse:any)=>{
         //console.log('response',sResponse);
         if (sResponse) {
          
          let fileTypeName = '';
          if(result.fileType == 'footwareConsolidatedOrders'){
            fileTypeName = 'Footwear Consolidated Orders';
          }
          else{
            fileTypeName = 'Apparel Equipment Consolidated Orders';
          }
          const fileName = this.orderWindowName.replace(/\s+/g,"_");

          saveAs(sResponse, fileName+'_Review' + '.xlsx');
          this.common.openSnackBar('File Downloaded!!!', '', 'success-snackbar');
          this.common.hideSpinner();
        }
      },sError => {
        this.common.openSnackBar('Error while loading data !!', '', 'danger-snackbar')
      });
      
    });
  }

  checkCancelBtnVisibility(order_status) {
    if (order_status == 'Approved' || order_status == 'Draft' || order_status == 'Rejected' || order_status == 'Pending for Review') {
      return true;
    }
    else {
      return false;
    }
  }
  cancelOrder(order_no){
    this.common.openConfirmDialog('Are you sure you want to cancel the order?')
    .afterClosed().subscribe(res => {
      if (res) {
        this.spinner.show();
        const ObjData={
          order_status:2,
          order_id:order_no
        }
        //console.log(ObjData);
        this.ordersService.saveOrderArticle(ObjData, 1).subscribe(sResponse => {
          //console.log('cancel Orde data', sResponse);
          this.spinner.hide();
          if (sResponse) {
            this.router.routeReuseStrategy.shouldReuseRoute = () => false;
            this.router.onSameUrlNavigation = 'reload';
            this.router.navigate(['/orders/store-sales-analysis']);
            this.common.openSnackBar('Order Canceled Successfully', '', 'success-snackbar');
            // console.log(data)
          }
          else {
            this.common.openSnackBar('Order Cancelelation Failed', '', 'danger-snackbar');
          }
        },
          sError => {
            this.common.apiError(sError);
          })
      }
    });
  }

  discardOrder(order_no,store_id){
    this.common.openConfirmDialog('Are you sure you want to discard the order?')
    .afterClosed().subscribe(res => {
      if (res) {
        this.spinner.show();
        const ObjData={
          order_id:order_no,
          store_id:store_id
        }
        //console.log(ObjData);
        this.ordersService.discardOrder(ObjData).subscribe((sResponse:any) => {
          console.log('discard Orde data', sResponse);
          this.spinner.hide();
          if (sResponse.data) {
            this.router.routeReuseStrategy.shouldReuseRoute = () => false;
            this.router.onSameUrlNavigation = 'reload';
            this.router.navigate(['/orders/store-sales-analysis']);
            this.common.openSnackBar('Order Discarded Successfully', '', 'success-snackbar');
          }
          else {
            this.common.openSnackBar('Order Discardation Failed', '', 'danger-snackbar');
          }
        },
          sError => {
            this.common.apiError(sError);
          })
      }
    });
  }

}
