import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AngularMaterialModule } from "../../angular.material.module";
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { OrdersRoutingModule } from './orders.routing.module';
import { SharedModule } from '../../shared/shared.module';
import { TargetSalesComponent } from './target-sales/target-sales.component';
import { ArticleBookingComponent, DialogOverviewExampleDialogComponent } from './article-booking/article-booking/article-booking.component';

import { ListFranchiseeOrderComponent } from "./order-list/list-franchisee-order/list-franchisee-order.component";
import { OrderReviewComponent,DialogWindowPopUpComponent } from "./order-review/order-review/order-review.component";
import { StoreSalesAnalysisComponent,DialogOrderWindowPopUpComponent } from "./store-sales-analysis/store-sales-analysis.component";
import { SuggestedArticleComponent } from "./suggested-article/suggested-article.component";

import { BrandAdminExportComponent } from "./order-details-export/brand-admin-export/brand-admin-export.component";
import { OrderArticlesDialogComponent } from './order-review/order-articles-dialog/order-articles-dialog.component';
//import { ImportOrdermasterComponent } from '../masters/import-ordermaster/import-ordermaster.component';
import { ImportConsolidateorderComponent } from '../masters/import-consolidateorder/import-consolidateorder.component';
import { ExportMasterComponent } from '../masters/export-master/export-master.component';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    AngularMaterialModule,
    OrdersRoutingModule,
    SharedModule
  ],
  entryComponents: [DialogOverviewExampleDialogComponent, OrderArticlesDialogComponent,DialogOrderWindowPopUpComponent,DialogWindowPopUpComponent],

  declarations: [
    TargetSalesComponent,
    ArticleBookingComponent,
    DialogOverviewExampleDialogComponent,
    ListFranchiseeOrderComponent,
    OrderReviewComponent,
    StoreSalesAnalysisComponent,
    SuggestedArticleComponent,
    OrderArticlesDialogComponent,
    BrandAdminExportComponent,
    DialogOrderWindowPopUpComponent,
    DialogWindowPopUpComponent,
    ImportConsolidateorderComponent,
    ExportMasterComponent
  ]
})
export class OrdersModule { }
