import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-order-articles-dialog',
  templateUrl: './order-articles-dialog.component.html',
  styleUrls: ['./order-articles-dialog.component.scss']
})
export class OrderArticlesDialogComponent implements OnInit {
  public articleList: any
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<OrderArticlesDialogComponent>) {
    if (data) {
      this.articleList = data;
    }
  }

  ngOnInit() {
  }

  onClose() {
    this.dialogRef.close();
  }

}
