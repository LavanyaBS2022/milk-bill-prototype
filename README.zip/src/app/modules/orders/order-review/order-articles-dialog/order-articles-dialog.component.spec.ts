import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderArticlesDialogComponent } from './order-articles-dialog.component';

describe('OrderArticlesDialogComponent', () => {
  let component: OrderArticlesDialogComponent;
  let fixture: ComponentFixture<OrderArticlesDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderArticlesDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderArticlesDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
