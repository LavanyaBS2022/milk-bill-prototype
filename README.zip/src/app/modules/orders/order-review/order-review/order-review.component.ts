import { Component, OnInit, Inject, LOCALE_ID } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { OrdersService } from './../../../../shared/service/orders/orders.service';
import { Common } from '../../../../shared/service/common/common';
import { MatSelectChange, MatOption, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { OrderArticlesDialogComponent } from '../order-articles-dialog/order-articles-dialog.component';

import { DecimalPipe, formatNumber } from "@angular/common";
import { saveAs } from 'file-saver';


@Component({
  selector: 'orderWindowPopUp',
  templateUrl: 'orderWindowPopUp.html',
  styleUrls: ['./orderwindow-popup.scss']
})
export class DialogWindowPopUpComponent {
  constructor(
    public dialogRef:MatDialogRef<DialogWindowPopUpComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  onNoClick(): void {
    this.dialogRef.close();
  }
}

@Component({
  selector: 'app-order-review',
  templateUrl: './order-review.component.html',
  styleUrls: ['./order-review.component.scss']
})
export class OrderReviewComponent implements OnInit {

  public orderReviewForm: FormGroup;
  public orderReviewId: any;
  public orderReviewData: any;
  public divisionWisePriceRange = [];
  public orderReviewAllocationData: any;
  public isDisplay: boolean = false;
  public orderReviewStatus: any;
  public userDetails: any;
  public boolUserType: boolean = false;
  public submitted: boolean = false;
  public isDisabled: boolean = false;
  public currentLoggedInUser;
  public currentLoggedInUserName;
  public isDisplayRejectionDDL = false;
  public franchiseEmail: any;
  public totalOrderQty: any;
  public brandAdminEmail: any;
  private orderReviewPriceRange: any
  private ordBrandId:any;
  private ordSeasonId:any;
  private ordOrderwindowId:any;
  private totOrderQty:any;
  public approveType;
  public rejectType;
  public orderWindowType:any;
  public franchiseId;
  public storeId;
  public countryId;
  public orderWindowName;

  constructor(@Inject(LOCALE_ID) private locale: string, public dialog: MatDialog, private formBuilder: FormBuilder, public route: ActivatedRoute, public orderService: OrdersService, public router: Router, public common: Common) {
    this.userDetails = this.common.getUserDetails();
    // console.log('this.userDetails', this.userDetails);
    this.currentLoggedInUser = this.userDetails.user_id
    this.currentLoggedInUserName = this.userDetails.name
    this.route.queryParams.subscribe(params => {
      this.orderReviewId = (atob(params.orderId));
      this.orderReviewStatus = (atob(params.orderStatus));
      this.ordBrandId = (atob(params.bid));
      this.ordSeasonId = (atob(params.sid));
      this.ordOrderwindowId = (atob(params.owid));
      this.orderWindowType= (atob(params.owtype));
      this.ordOrderwindowId = (atob(params.owid));
      this.orderWindowType= (atob(params.owtype));
      this.franchiseId= (atob(params.cusid));
      this.storeId= (atob(params.storeid));
      this.countryId= (atob(params.countryid));
      this.orderWindowName= (atob(params.owname));
      
    

      this.getOrderReviewDetailsData(this.orderReviewId);
    });
  }

  ngOnInit() {
    this.orderReviewForm = this.formBuilder.group({
      orderID: [''],
      franchiseeName: [''],
      storeName: [''],
      location: [''],
      bookingValue: [''],
      season: [''],
      remarks: [''],
      orderWindowName: [''],
      rejectedReasonItems: [''],
      actionItems: ['', Validators.required],
      totalOrderQty :  [''],
      totalFwQty :  [''],
      totalAPEQQty:  [''],
      totalFwSKU:  [''],
      totalAPEQSKU:  ['']
    });
  }

  public get get() {
    return this.orderReviewForm.controls;
  }

  onOrderReviewDialog(orderData: any) {
    this.orderService.getOrderReviewData(this.orderReviewPriceRange.season_id, this.orderReviewPriceRange.order_window_id, orderData.order_id, orderData.division_id, orderData.product_type_id, orderData.rbu_id, orderData.gender_id).subscribe((sResponseModel: any) => {
      // console.log(sResponseModel);
      const result = sResponseModel.data;
      if (result.length > 0) {
        const dailogRef = this.dialog.open(OrderArticlesDialogComponent, {
          maxWidth: '800px',
          width: '680px',
          data: result,
        })
      } else {
        this.common.openSnackBar('No data to display', '', 'success-snackbar');
      }

    }, sError => {

    })

  }

  public getOrderReviewDetailsData(orderReviewId: any) {
    this.orderService.getOrderReviewDetails(orderReviewId).subscribe((data) => {
      //console.log('TOTAL DATA:', data);
      // console.log(data);
      if(data.data){
        this.orderReviewData = data.data.orderReviewPriceRange;
        this.orderReviewPriceRange = this.orderReviewData[0];
        // // console.log('Order Review Details Data:', this.orderReviewData);
        this.orderReviewForm.patchValue({
          orderID: this.orderReviewData[0].order_no,
          franchiseeName: this.orderReviewData[0].franchise_name,
          storeName: this.orderReviewData[0].store_name,
          location: this.orderReviewData[0].address,
          bookingValue: formatNumber(this.orderReviewData[0].current_allocation, this.locale, '1.0-0'),
          season: this.orderReviewData[0].season_name,
          orderWindowName: this.orderReviewData[0].ow_name,
          totalOrderQty : this.orderReviewData[0].totalorderqty,
          totalFwQty :  this.orderReviewData[0].total_qty_fw,
          totalAPEQQty:  this.orderReviewData[0].total_qty_apeq,
          totalFwSKU:  formatNumber(this.orderReviewData[0].total_value_fw, this.locale, '1.0-0'),
          totalAPEQSKU:  formatNumber(this.orderReviewData[0].total_value_apeq, this.locale, '1.0-0')
        });
        // this.divisionWisePriceRange = JSON.parse(this.orderReviewData[0].price_range_json);
        // // console.log('Divisionwise Price RANGE:', this.divisionWisePriceRange);
        this.orderReviewAllocationData = data.data.orderAllocationData;
        this.totalOrderQty= this.orderReviewData[0].totalorderqty;
        // // console.log('Order Allocation Data:', this.orderReviewAllocationData);
      }
      else{
        this.common.openSnackBar('No Data Found','', 'danger-snackbar');
      }
      
    },
    sError => {
      this.common.apiError(sError);
    });
     
    //console.log(this.orderReviewStatus);
    
    if (this.userDetails.userType == 1) {
      this.isDisplay = false;
      this.boolUserType = true;
      this.brandAdminEmail = this.userDetails.email
    }
    else if (this.userDetails.userType == 2) {
      this.isDisplay = true;
    }
    if ((this.orderReviewStatus == "Pending for Review" || this.orderReviewStatus == "Approved by Sales") && this.userDetails.roleId[0] != '5f3f65a09c0ed02bbc9e478f') {
      this.boolUserType = true;
      this.approveType=4;
      this.rejectType=5;
    }else if(this.orderReviewStatus == "Pending Review From Sales" && this.userDetails.roleId[0] == '5f3f65a09c0ed02bbc9e478f'){
      this.boolUserType = true;
      this.approveType =7;
      this.rejectType=8;
    }
    else {
      this.boolUserType = false;
    }
  }

  onOrderReviewProcess(reviewStatusId) {
    // // console.log("Action Items Value:", this.get.actionItems.value);
     console.log('review ID:', reviewStatusId);
     //return;
     
    // // console.log('this.orderReviewForm.get("rejectedReasonItems").value:', this.orderReviewForm.get("rejectedReasonItems").value)

    // if ((reviewStatusId == 5 || reviewStatusId == 8) && this.orderReviewForm.get("rejectedReasonItems").value == "") {
    //    //console.log('reached rejected if');
    //   this.submitted = true;
    //   return this.orderReviewForm.controls["rejectedReasonItems"].setErrors({ reqValidateError: "Rejected Reason is required." });
    // }

    // this.get.rejectedReasonItems.setValidators([Validators.required]);
    // // console.log('Form is InValid or Not', this.orderReviewForm.invalid);
    // // console.log('OnSubmit err:', this.get.rejectedReasonItems.errors);

    this.submitted = true;
    if (this.orderReviewForm.invalid) {
      return;
    }
    else {
      this.orderReviewForm.value['review_status_id'] = reviewStatusId;

      if ((reviewStatusId == 5 || reviewStatusId == 8) && this.orderReviewForm.get("remarks").value.trim() == "") {
        this.submitted = true;
        return this.orderReviewForm.controls["remarks"].setErrors({ emptyValidateError: "Remarks is required." });
      }
      if ((reviewStatusId == 4 || reviewStatusId == 7)&& this.orderReviewForm.get("remarks").value.trim() == "") {
        this.submitted = false;
      }

      this.franchiseEmail = this.orderReviewData[0].email;
      this.totalOrderQty = this.orderReviewData[0].totalorderqty
      const postData = JSON.parse(JSON.stringify(this.orderReviewForm.value));
      Object.assign(postData, { o_id: parseInt(this.orderReviewId), user_id: this.currentLoggedInUser, user_name: this.currentLoggedInUserName, franchiseEmail: this.franchiseEmail, brandAdminEmail: this.brandAdminEmail, totalorderqty: this.totalOrderQty });
      console.log('post data:', postData);
      // return;

      this.orderService.postOrderReviewProcess(postData).subscribe((data) => {
        if (data.status) {
          this.router.navigate(['orders/listFranchiseeOrder']);
          if (reviewStatusId == 4)
            this.common.openSnackBar(`Order No: ORD_${data.data[0].id} Approved !!!`, '', 'success-snackbar');
          if (reviewStatusId == 5)
            this.common.openSnackBar(`Order No: ORD_${data.data[0].id} Rejected !!!`, '', 'danger-snackbar');
        } else {
          this.common.openSnackBar('Order Review Process Error', '', 'danger-snackbar');
        }
      },
        sError => {
          this.common.apiError(sError);
        });

    }

  }

  public onRejectChanged(event: MatSelectChange) {
    const selectedData = {
      text: (event.source.selected as MatOption).viewValue,
      value: event.source.value
    };
    // // console.log(selectedData);
    // // console.log("Selected Value:", selectedData.value);
    // // console.log("Selected Text:", selectedData.text);
    this.orderReviewForm.patchValue({ remarks: selectedData.text });
  }

  public onActionChanged(actionValue) {
    if (actionValue === 5) {
      this.isDisplayRejectionDDL = true;
      // this.orderReviewForm.controls["rejectedReasonItems"].setErrors({ required: "Rejected Reason is required" });
      // // console.log('err:', this.get.rejectedReasonItems.errors);
    }
    else if (actionValue === 4) {
      this.isDisplayRejectionDDL = false;
      this.orderReviewForm.patchValue({ remarks: '' });
      // this.get.rejectedReasonItems.setValidators([Validators.required]);
    }
  }

  // public callClick(value) {
  //   // console.log('click Value:', value);
  // }

  downLoadOreders(){
    console.log(this.orderWindowType);
    let fileType;
    if(this.orderWindowType==1){
      fileType='footwareConsolidatedOrders'
    }else if(this.orderWindowType==2){
      fileType='apparelEquipmentConsolidatedOrders'
    }
    let dataObj={
      fileType:fileType,
      seasonId:this.ordSeasonId,
      orderWindowId:this.ordOrderwindowId,
      brandId:this.ordBrandId,
      franchiseId:this.franchiseId,
      orderId:this.orderReviewId,
      storeId:this.franchiseId,
      countryId:this.countryId
    }
    //console.log('dataobjec',dataObj);
    this.orderService.exportSubmitedOrders(dataObj).subscribe((sResponse:any)=>{
      //console.log('response',sResponse);
      if (sResponse) {
       const fileName = this.orderWindowName.replace(/\s+/g,"_");

       saveAs(sResponse, fileName+'_Consolidated_Orders_Review' + '.xlsx');
       this.common.openSnackBar('File Downloaded!!!', '', 'success-snackbar');
       this.common.hideSpinner();
     }
   },sError => {
     this.common.openSnackBar('Error while loading data !!', '', 'danger-snackbar')
   });
  }

  // openDialog(): void {
  //   const dialogRef = this.dialog.open(DialogWindowPopUpComponent, {
  //     disableClose: true,
  //     width: '800px',
  //     data: {
  //       fileType:'footwareConsolidatedOrders',
  //       orderId:this.orderReviewId,
  //       seasonId:this.ordSeasonId,
  //       orderWindowId:this.ordOrderwindowId,
  //       brandId:this.ordBrandId,
  //     }
  //   });
  //   dialogRef.afterClosed().subscribe(result => {
  //     console.log('The dialog was closed', result);
      
  //     let dataObj={
  //       fileType:result.fileType,
  //       seasonId:result.seasonId,
  //       orderWindowId:result.orderWindowId,
  //       brandId:result.brandId,
  //       orderId:result.orderId,
  //     }
  //     console.log('dataobjec',dataObj);
  //     this.orderService.exportSubmitedOrders(dataObj).subscribe((sResponse:any)=>{
  //        console.log('response',sResponse);
  //        if (sResponse) {
          
  //         let fileTypeName = '';
  //         if(result.fileType == 'footwareConsolidatedOrders'){
  //           fileTypeName = 'Footwear Consolidated Orders';
  //         }
  //         else{
  //           fileTypeName = 'Apparel Equipment Consolidated Orders';
  //         }
  //         const fileName = fileTypeName;

  //         saveAs(sResponse, fileName + '.xlsx');
  //         this.common.openSnackBar('File Downloaded!!!', '', 'success-snackbar');
  //         this.common.hideSpinner();
  //       }
  //     },sError => {
  //       this.common.openSnackBar('Error while loading data !!', '', 'danger-snackbar')
  //     });
      
  //   });

  // }

}
