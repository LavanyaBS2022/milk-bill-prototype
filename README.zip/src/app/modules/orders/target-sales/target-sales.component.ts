import { Component, OnInit } from '@angular/core';
import { TargetService } from '../../../shared/service/orders/target/target.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { MastersService } from './../../../shared/service/masters/masters.service';
import * as math from 'mathjs';
import { create, all } from 'mathjs/number'
import { Common } from '../../../shared/service/common/common';
@Component({
  selector: 'app-target-sales',
  templateUrl: './target-sales.component.html',
  styleUrls: ['./target-sales.component.scss']
})
export class TargetSalesComponent implements OnInit {
  public divisionList = [];
  public bakdivisionList = [];
  public divisionwiseContent = [];
  public genderList = [];
  public businessUnitList = [];
  public productTypeList = [];
  public divisionWiseGender = [];
  public bakdivisionWiseGender = [];
  public formatDivisionDetail = [];
  public targetOrderList = [];
  public expectedGrossSale: any;
  public divisionCount: number;
  public divisionWisegenderCount = [];
  public divisionForm: FormGroup;
  public targetValue;
  public divisionStatus_price: boolean = false;
  public divisionStatus_percentage: boolean = false;
  public divGenderStatus_price: boolean = false;
  public divGenderStatus_percentage = false;
  public detaildivStatus_price: boolean = false;
  public detaildivStatus_percentage: boolean = false;
  public orderNumber: string;
  public orderId: number;
  public orderAllocation = [];
  public alocation_data: number;
  public newList = [];
  public bakformatDivisionDetail = [];
  // public currentOrderWindowId;
  // public currentSeasonId;
  public orderWindowId;
  public seasonId;
  public storeId;
  public franchiseId;
  public brandId;
  public storeName;
  public orderStatus;
  public franchiseTypeId;
  public franchiseName: string;
  public locationName: string;
  public regionName: string;
  constructor(private targetService: TargetService, private fb: FormBuilder, public router: Router, public route: ActivatedRoute, private mastersService: MastersService, public common: Common) {
    this.route.queryParams.subscribe(params => {
      this.storeId = params.store_id;
      this.franchiseId = params.franchise_id
      this.brandId = params.brand_id;
      // this.getEditFranchiseData(this.storeId);
      let userDetails = this.common.getUserDetails();
      this.seasonId = userDetails.seasonId;
      this.orderWindowId = userDetails.orderWindowId;
      this.franchiseTypeId = userDetails.accessPriority;
    });
  }
  getEditFranchiseData(storeId) {
    // // console.log('storeId',storeId);
    this.mastersService.getlistFranchiseStoreById(storeId).subscribe((data) => {
      this.storeName = data.data[0].store_name
    });
  }
  ngOnInit() {
    this.getOrder();


  }
  resetPage() {
    this.divisionWiseGender = [];
    this.formatDivisionDetail = [];
  }

  targetDeatails() {

    this.targetService.getTragetDetails(this.seasonId, this.orderWindowId, this.brandId, this.franchiseTypeId).subscribe(sResponse => {
      this.targetOrderList = sResponse.data;
      this.targetOrderList.forEach((val, key) => {
        // console.log(val);

        //creating divisions
        let divObj = {
          id: val.division_id,
          name: val.division_name,
          short_name: val.short_name,
          percentage: val.percentage,
          price: val.price
        }
        this.divisionList.push(divObj);
        let newDivObj = { ...divObj };
        this.bakdivisionList.push(newDivObj);
        // // console.log(this.divisionList);


        //divsion wise gender is declared hear
        this.divisionWiseGender[val.division_id] = val.divisionGender;

        this.bakdivisionWiseGender[val.division_id] = val.divisionGender;

        this.formatDivisionDetail[val.division_id] = val.divisionBreak;

        this.divisionWisegenderCount[val.division_id] = val.divisionGender_count;

      })
      //// console.log(this.divisionWiseGender);
      this.divisionCount = this.divisionList.length;


    },
      sError => {
        this.common.apiError(sError);
      });

    this.targetService.getTragetDetails(this.seasonId, this.orderWindowId, this.brandId, this.franchiseTypeId).subscribe((sResponse: any) => {
      this.newList = sResponse.data;
      this.newList.forEach((val1, key) => {
        this.bakdivisionWiseGender[val1.division_id] = val1.divisionGender;
        this.bakformatDivisionDetail[val1.division_id] = val1.divisionBreak;
      });
    },
      sError => {
        this.common.apiError(sError);
      });
  }

  getOrderAllocation(orderNo) {
    this.targetService.getOrderAlocations(orderNo).subscribe((sResponse: any) => {
      this.targetOrderList = sResponse.data;
      this.targetOrderList.forEach((val, key) => {
        //// console.log(val);


        //creating divisions
        let divObj = {
          id: val.division_id,
          name: val.division_name,
          short_name: val.short_name,
          percentage: val.percentage,
          price: val.price,
          allocation_id: val.allocation_id
        }

        let newDivObj = { ...divObj };
        this.divisionList.push(divObj);
        this.bakdivisionList.push(newDivObj);

        //// console.log(this.divisionList);


        //divsion wise gender is declared hear
        this.divisionWiseGender[val.division_id] = val.divisionGender;

        this.formatDivisionDetail[val.division_id] = val.divisionBreak;

        this.divisionWisegenderCount[val.division_id] = val.divisionGender_count;

      });
      this.divisionCount = this.divisionList.length;
      //// console.log(this.divisionWiseGender);

    },
      sError => {
        this.common.apiError(sError);
      });

    this.targetService.getOrderAlocations(orderNo).subscribe((sResponse: any) => {
      this.newList = sResponse.data;
      this.newList.forEach((val1, key) => {
        this.bakdivisionWiseGender[val1.division_id] = val1.divisionGender;
        this.bakformatDivisionDetail[val1.division_id] = val1.divisionBreak;
      });
    },
      sError => {
        this.common.apiError(sError);
      });

  }



  saveOrderDetail() {
    let sessionId = this.seasonId;
    let orderWindowId = this.orderWindowId;
    let franchaiseId = this.franchiseId;
    let storeId = this.storeId;
    let brandId = this.brandId;
    let userId = 1;
    let obj = {
      userId: userId,
      season_id: sessionId,
      order_window_id: orderWindowId,
      franchise_id: franchaiseId,
      store_id: storeId,
      brand_id: brandId,
      expected_gross_sell: this.targetValue
    }
    if (this.orderId) {
      Object.assign(obj, { orderId: this.orderId });
    }
    // // console.log('this.orderId',this.orderId);
    this.targetService.saveOreder(obj).subscribe((sResponse: any) => {

      if (sResponse.data) {
        if (!this.orderId && !sResponse.data.insert) {
          this.getOrder();
        }
        //from this sushma added
        else {
          if (sResponse.data.insertedOrderId != undefined) {
            this.orderId = sResponse.data.insertedOrderId;
            this.orderNumber = 'ORD_' + sResponse.data.insertedOrderId;
          }

        }
        //till this sushma added

      }
    },
      sError => {
        this.common.apiError(sError);
      });
  }

  getOrder() {
    let sessionId = this.seasonId;
    let orderWindowId = this.orderWindowId;
    let franchaiseId = this.franchiseId;
    let storeId = this.storeId;
    this.targetService.getOrder(sessionId, orderWindowId, franchaiseId, storeId, this.brandId).subscribe((sResponse: any) => {

      if (sResponse.data) {
        this.orderNumber = (sResponse.data[0].order_no) ? sResponse.data[0].order_no : '';
        this.orderId = (sResponse.data[0].id) ? sResponse.data[0].id : '';
        this.alocation_data = (sResponse.data[0].allocation_data) ? sResponse.data[0].allocation_data : '';
        this.targetValue = (sResponse.data[0].expected_gross_sell) ? sResponse.data[0].expected_gross_sell : '';

        this.storeName = sResponse.data[0].store_name;
        this.franchiseName = sResponse.data[0].franchise_name;
        this.locationName = sResponse.data[0].location;
        this.regionName = sResponse.data[0].regionname;

        if (this.alocation_data) {
          this.getOrderAllocation(this.orderId);
        } else {
          // console.log('I got called 1');
          this.targetDeatails();
        }
      } else {
        // console.log('I got called 2');
        this.targetDeatails();
      }

    },
      sError => {
        this.common.apiError(sError);
      });
  }

  saveOrderAllocation() {
    let userId = 1;
    let obj;
    this.orderAllocation = [];
    console.log(this.divisionList);


    this.divisionList.forEach((val, key) => {
      let obj = {
        order_id: this.orderId,
        division_id: val.id,
        gender_id: 0,
        rbu_id: 0,
        product_type_id: 0,
        percentage: val.percentage,
        amount: val.price,
        created_user: userId,
        created_date: new Date(),
        type: 1
      }
      if (this.alocation_data) {
        delete obj['created_user'];
        delete obj['created_date'];
        Object.assign(obj, { id: val.allocation_id, updated_user: userId });
      }
      this.orderAllocation.push(obj);

    })
    console.log(this.divisionList);

    this.divisionWiseGender.forEach((divisionGender, key) => {
      divisionGender.forEach(v => {
        obj = {
          order_id: this.orderId,
          division_id: key,
          gender_id: v.id,
          rbu_id: 0,
          product_type_id: 0,
          percentage: v.percentage,
          amount: v.price,
          created_user: userId,
          created_date: new Date(),
          type: 2
        }
        if (this.alocation_data) {
          delete obj['created_user'];
          delete obj['created_date'];
          Object.assign(obj, { id: v.allocation_id, updated_user: userId });
        }
        this.orderAllocation.push(obj);
      })
    })

    this.formatDivisionDetail.forEach((formatDiv) => {
      formatDiv.forEach(fv => {
        obj = {
          order_id: this.orderId,
          division_id: fv.division_id,
          gender_id: fv.gender_id,
          rbu_id: fv.rbu_id,
          product_type_id: fv.product_type_id,
          percentage: fv.percentage,
          amount: fv.price,
          created_user: userId,
          created_date: new Date(),
          type: 3
        }
        if (this.alocation_data) {
          delete obj['created_user'];
          delete obj['created_date'];
          Object.assign(obj, { id: fv.allocation_id, updated_user: userId });
        }
        this.orderAllocation.push(obj);
      })
    })
    console.log(this.orderAllocation);
    console.log(this.formatDivisionDetail);
    let finalObj = { allocationData: this.orderAllocation };
    let dotype;

    // // console.log('alocation_data',this.alocation_data);
    if (this.alocation_data === 1) {
      dotype = 2;
    } else {
      dotype = 1;
    }


    this.targetService.saveOrderAllocation(finalObj, dotype).subscribe((sResponse: any) => {
      this.router.navigate(['orders/article-booking'], { queryParams: { orderId: this.orderId, storeId: this.storeId, brandId: this.brandId } });
    },
      sError => {
        this.common.apiError(sError);
      });
  }

  targetOrderCalc() {
    //calc of divsion
    let division_price = math.divide(this.targetValue, this.divisionCount);
    let division_percentage = math.evaluate(division_price / this.targetValue * 100);
    this.divisionList.forEach(val => {
      val.percentage = division_percentage;
      val.price = division_price;
    });


    //calc for divisionwise gender
    let gender_percentage;
    let gender_price;
    //// console.log(this.divisionList);
    this.divisionWiseGender.forEach((specificDivs, key) => {
      let divs = this.divisionList.find(t => t.id === key);
      specificDivs.forEach(v => {
        gender_price = math.divide(divs.price, this.divisionWisegenderCount[key]);
        gender_percentage = math.evaluate(gender_price / divs.price * 100);
        v.price = gender_price;
        v.percentage = gender_percentage;
      });
    });

    //calc for detailDivision

    let detaidiv_percentage;
    let detaildiv_price;
    this.formatDivisionDetail.forEach((formatDivs, key) => {
      let divs = this.divisionList.find(t => t.id === key);
      formatDivs.forEach(fv => {
        let genders = this.divisionWiseGender[fv.division_id].find(t => t.id === fv.gender_id);
        //// console.log(genders);
        detaildiv_price = math.divide(genders.price, genders.divisionBreak_count);
        //detaidiv_percentage = math.evaluate(detaildiv_price * 100 / this.targetValue);
        detaidiv_percentage = math.evaluate(detaildiv_price / this.targetValue * 100);
        fv.price = detaildiv_price;
        fv.percentage = detaidiv_percentage;
        // // console.log(genders);


      })
    });


    //// console.log(this.formatDivisionDetail);
    //// console.log(this.divisionWiseGender);

    this.saveOrderDetail();

  }

  reorderCalc(type?: any, divId?: any, genderId?: any) {
    if (type === 'div') {
      this.divisionList = [...this.bakdivisionList];
    }
    if (type === 'div_gen') {

      this.divisionWiseGender[divId] = [...this.bakdivisionWiseGender[divId]];
    }
    //// console.log(divId);
    if (type === 'format_divs') {
      //// console.log(this.formatDivisionDetail[divId]);
      this.formatDivisionDetail[divId].forEach((val, key) => {
        if (val.gender_id == genderId) {
          this.formatDivisionDetail[divId][key] = { ...this.bakformatDivisionDetail[divId][key] };

        }
      });
    }

  }


  normaliseDivision(flg?: any) {
    // const mathjs = create(all);
    // mathjs.config({
    //   precision: 64
    // });

    let div_sum = this.divisionList.reduce((prev, cur) => {
      return {
        price: math.number(prev.price) + math.number(cur.price),
        percentage: math.number(prev.percentage) + math.number(cur.percentage)
      }
    });
    let division_price;
    let division_percentage;
    //// console.log(div_sum);
    let div_sum_price = math.round(div_sum.price, 2);
    let div_sum_percentage = math.round(div_sum.percentage, 15);
    let s = { price: div_sum_price, percentage: div_sum_percentage }
    //// console.log(s);

    this.divisionList.forEach(val => {
      if ((div_sum_percentage > 100 || div_sum_percentage < 100) && div_sum_percentage > 0) {
        division_percentage = this.checkIsNaN(math.evaluate(val.percentage / div_sum_percentage * 100));
        division_price = math.evaluate(this.targetValue * division_percentage / 100);

      } else if ((div_sum_price > this.targetValue || div_sum_price < this.targetValue) && div_sum_price > 0) {
        division_price = this.checkIsNaN(math.evaluate(val.price / div_sum_price * this.targetValue));
        division_percentage = math.evaluate(division_price * 100 / this.targetValue);

      } else if (div_sum_price == 0 || div_sum_percentage == 0) {
        this.reorderCalc('div');
      } else {

        if (this.divisionStatus_percentage == true) {

          division_percentage = math.evaluate(val.percentage / div_sum_percentage * 100);
          division_price = math.evaluate(this.targetValue * division_percentage / 100);

        } else if (this.divisionStatus_price == true) {
          division_price = math.evaluate(val.price / div_sum_price * this.targetValue);
          division_percentage = math.evaluate(division_price * 100 / this.targetValue);

        } else {
          division_price = val.price;
          division_percentage = val.percentage;
        }
      }
      val.price = division_price;
      val.percentage = division_percentage;

    });
    this.divisionStatus_percentage = false;
    this.divisionStatus_price = false;
    //// console.log(div_sum);

    //normalise division gender
    let gender_percentage;
    let gender_price;
    let gen_sum;
    this.divisionWiseGender.forEach((specificDivs, key) => {
      let divs = this.divisionList.find(t => t.id === key);
      gen_sum = specificDivs.reduce((prev, cur) => {
        return {
          price: math.number(prev.price) + math.number(cur.price),
          percentage: math.number(prev.percentage) + math.number(cur.percentage)
        }
      });
      //// console.log(gen_sum);
      let gen_sum_percentage = math.round(gen_sum.percentage, 2);
      let gen_sum_price = math.round(gen_sum.price, 15);
      let k = { price: gen_sum_price, percentage: gen_sum_percentage }
      // // console.log(k);

      specificDivs.forEach(v => {
        if ((gen_sum_percentage > 100 || gen_sum_percentage < 100) && gen_sum_percentage > 0) {
          gender_percentage = this.checkIsNaN(math.evaluate(v.percentage / gen_sum_percentage * 100));
          gender_price = this.checkIsNaN(math.evaluate(divs.price * gender_percentage / 100));
        } else if ((gen_sum_price > math.round(divs.price) || gen_sum_price < math.round(divs.price)) && gen_sum_price > 0) {
          gender_price = this.checkIsNaN(math.evaluate(v.price / gen_sum_price * divs.price));
          gender_percentage = this.checkIsNaN(math.evaluate(gender_price * 100 / divs.price));
        } else if (gen_sum_price == 0 || gen_sum_percentage == 0) {
          this.reorderCalc('div_gen', divs.id)
        } else {
          if (this.divGenderStatus_percentage == true) {
            gender_percentage = math.evaluate(v.percentage / gen_sum_percentage * 100);
            gender_price = math.evaluate(divs.price * gender_percentage / 100);
          } else if (this.divGenderStatus_price == true) {
            gender_price = math.evaluate(v.price / gen_sum_price * divs.price);
            gender_percentage = math.evaluate(this.targetValue * division_percentage / 100);
          } else {
            gender_price = v.price;
            gender_percentage = v.percentage;
          }

        }
        v.price = gender_price
        v.percentage = gender_percentage
      });
    });
    this.divGenderStatus_price = false;
    this.divGenderStatus_percentage = false;


    //normalise detail division

    let detaidiv_percentage;
    let detaildiv_price;
    let detail_sum_price;
    let detail_sum_percentage;
    this.formatDivisionDetail.forEach((formatDivs, key) => {
      let divs = this.divisionList.find(t => t.id === key);
      //// console.log(key);
      let divisionwisePercentage = math.divide(divs.percentage, this.divisionWisegenderCount[key]);
      //// console.log(divisionwisePercentage);


      detail_sum_price = formatDivs.reduce(function (acc, val) {
        var o = acc.filter(function (obj) {
          return obj.gender_id == val.gender_id;
        }).pop() || { gender_id: val.gender_id, price: 0 };


        o.price += math.number(val.price);
        acc.push(o);
        return acc;
      }, []).filter(function (itm, i, a) {
        return i == a.indexOf(itm);
      });

      detail_sum_percentage = formatDivs.reduce(function (acc, val) {
        var o = acc.filter(function (obj) {
          return obj.gender_id == val.gender_id;
        }).pop() || { gender_id: val.gender_id, percentage: 0 };


        o.percentage += math.number(val.percentage);
        acc.push(o);
        return acc;
      }, []).filter(function (itm, i, a) {
        return i == a.indexOf(itm);
      });


      // detail_sum.percentage = math.round(detail_sum.percentage, 10);
      // detail_sum.price=math.round(detail_sum.price, 10);
      //// console.log(detail_sum_price);
      //// console.log(detail_sum_percentage);

      //// console.log(math.round(detail_sum.percentage,10));


      formatDivs.forEach(fv => {
        let genders = this.divisionWiseGender[fv.division_id].find(t => t.id === fv.gender_id);
        let filterPrice = detail_sum_price.find(t => t.gender_id === fv.gender_id);
        let filterPercentage = detail_sum_percentage.find(t => t.gender_id === fv.gender_id);



        let roundedPercentage = math.round(filterPercentage.percentage, 2);
        let roundedPrice = math.round(filterPrice.price, 15);
        //// console.log(genders);
        //// console.log(filterPercentage);

        // // console.log(roundedPercentage);

        //// console.log(divisionwisePercentage);

        if ((roundedPrice > genders.price || roundedPrice < genders.price) && roundedPrice != 0) {
          detaildiv_price = this.checkIsNaN(math.evaluate(fv.price / roundedPrice * genders.price));
          detaidiv_percentage = this.checkIsNaN(math.evaluate(detaildiv_price * 100 / this.targetValue));
        } else if ((roundedPercentage > divisionwisePercentage || roundedPercentage < divisionwisePercentage) && roundedPercentage !== 0) {
          detaidiv_percentage = this.checkIsNaN(math.evaluate(fv.percentage / roundedPercentage * divisionwisePercentage));
          detaildiv_price = this.checkIsNaN(math.evaluate(this.targetValue * detaidiv_percentage / 100));
        } else if ((roundedPercentage == 0 && genders.percentage > 0) || (roundedPrice == 0 && genders.price > 0)) {

          this.reorderCalc('format_divs', divs.id, genders.id);
        } else {
          detaidiv_percentage = fv.percentage;
          detaildiv_price = fv.price;
        }

        fv.percentage = detaidiv_percentage;
        fv.price = detaildiv_price;;

      });
    });
    this.detaildivStatus_price = false;
    this.divGenderStatus_percentage = false;
    //// console.log(this.formatDivisionDetail);
    //// console.log(this.divisionWiseGender);
    //// console.log(this.divisionWisegenderCount);

    for (let i = 0; i <= flg; i++) {
      this.normaliseDivision();
    }

  }

  checkIsNaN(val) {
    return isNaN(val) ? 0 : val;
  }

  findChange(flg: any, divid?: any, inputValue?: any, genderId?: any, rbuId?: any, productId?: any) {
    if (flg === 'div_price') {
      this.divisionStatus_price = true;
      let fdiv = this.divisionList.find(t => t.id === divid);
      fdiv.price = inputValue;
    }
    if (flg === 'div_percentage') {
      this.divisionStatus_percentage = true;
      let fdiv = this.divisionList.find(t => t.id === divid);
      fdiv.percentage = inputValue;
      // // console.log(fdiv);
      //// console.log(inputValue);


    }
    if (flg == 'gen_percentage') {
      this.divGenderStatus_percentage = true;

      let fdiv = this.divisionWiseGender[divid].find(t => t.id === genderId);
      fdiv.percentage = inputValue;
      //// console.log(fdiv);
    }
    if (flg == 'gen_price') {
      this.divGenderStatus_price = true;
      let fdiv = this.divisionWiseGender[divid].find(t => t.id === genderId);
      fdiv.price = inputValue;
    }
    if (flg == 'detaildiv_percentage') {
      this.detaildivStatus_percentage = true;
      let fdiv = this.formatDivisionDetail[divid].find(t => t.gender_id === genderId && t.rbu_id === rbuId && t.product_type_id === productId);
      fdiv.percentage = inputValue;
      //// console.log(this.formatDivisionDetail[divid]);
      //// console.log(fdiv);


    }
    if (flg == 'dataildiv_price') {
      this.detaildivStatus_price = true;
      this.detaildivStatus_percentage = true;
      let fdiv = this.formatDivisionDetail[divid].find(t => t.gender_id === genderId && t.rbu_id === rbuId && t.product_type_id === productId);
      fdiv.price = inputValue;
    }
  }
}
