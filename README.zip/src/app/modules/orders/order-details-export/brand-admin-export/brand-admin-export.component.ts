import { Component, OnInit } from '@angular/core';
import { FormGroup, NgForm, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MastersService } from '../../../../shared/service/masters/masters.service';
import { ActivatedRoute } from '@angular/router';
import { Common } from '../../../../shared/service/common/common';
import { saveAs } from 'file-saver';
import { OrdersService } from "../../../../shared/service/orders/orders.service";
import { ReportsService } from "../../../../shared/service/reports/reports.service";

@Component({
  selector: 'app-brand-admin-export',
  templateUrl: './brand-admin-export.component.html',
  styleUrls: ['./brand-admin-export.component.scss']
})
export class BrandAdminExportComponent implements OnInit {

  public brandAdminExportFilterForm: FormGroup;

  private userDetails: any;
  private submitted: boolean;
  public seasonList = [];
  public orderWindowList = [];
  public brandList = [];
  public divisionList = [];
  public genderList = [];
  public category1List = [];
  public category4List = [];
  

  public seasonId: any = '';
  public orderWindowId: any = '';
  public brandId: any = '';
  
  public countryId: any;
  public franchiseName: any;
  public franchiseCode: any;

  constructor(private formBuilder: FormBuilder, private masterService: MastersService, public orderService: OrdersService, private common: Common, private reportService: ReportsService) { }

  public text: any = 'Show Filter';
  public changeText(): void {
    if (this.text === 'Collapse Filter') {
      this.text = 'Show Filter';
    } else {
      this.text = 'Collapse Filter';
    }
  }
  step = 0;
  setStep(index: number) {
    this.step = index;
  }
  nextStep() {
    this.step++;
  }
  prevStep() {
    this.step--;
  }

  ngOnInit() {
    this.userDetails = this.common.getUserDetails();
    // console.log('this.userDetails:', this.userDetails);
    this.generateArticleListFormFilter();
    // this.patchgenerateArticleListFormFilter();
    this.getSeasons();
    this.getBrandListSeasonOwWise();
  }

  generateArticleListFormFilter() {
    this.brandAdminExportFilterForm = new FormGroup({
      seasonId: new FormControl('', Validators.required),
      orderWindowId: new FormControl('', Validators.required),
      divisionId: new FormControl(''),
      brandId: new FormControl(''),
      genderId: new FormControl(''),
      category1Id: new FormControl(''),
      category4Id: new FormControl(''),
      mType: new FormControl('',Validators.required),
       
    });
  }

  patchgenerateArticleListFormFilter() {
    this.brandAdminExportFilterForm.patchValue({
      seasonId: '0',
      orderWindowId: '0',
      brandId: '0'
    });
  }

  public get get() {
    return this.brandAdminExportFilterForm.controls;
  }

  getSeasons() {
    this.masterService.getlistSeason().subscribe((sRespone: any) => {
      console.log('seasons', sRespone.data);
      this.seasonList = sRespone.data;
    },
      sError => {
        this.common.apiError(sError);
      });
  }

  getOrderWindowList() {
    const onlyActive = 0;
    this.masterService.getOrderWindowSeasonList(onlyActive).subscribe((data) => {
      console.log('getOrderWindowList', data.data);
      let result = data.data;
      const seasonId = this.get.seasonId.value;
      console.log('seasonId',seasonId)
      this.orderWindowList = result.filter(item => item.season_id == seasonId);
      // console.log('orderWindowList', this.orderWindowList);
    },
      sError => {
        this.common.apiError(sError);
      });
  }

  getBrandListSeasonOwWise() {
    this.reportService.getReportFilterMasterData('brand').subscribe(sResponseModel => {
      // console.log('Brand Drop Down Data:', sResponseModel.data);
      if (sResponseModel.data) {
        this.brandList = sResponseModel.data;
        // console.log('this.brandList',this.brandList);
      }
    },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public getDivisionListSeasonOwWise() {
    this.masterService.getDivisionListSeasonOwWise(this.get.seasonId.value, this.get.orderWindowId.value).subscribe(
      sResponseModel => {
        // console.log('Division DropDown Data:', sResponseModel.data);
        if (sResponseModel.data) {
          this.divisionList = sResponseModel.data;
        }
      },
      sError => {
        this.common.apiError(sError);
      });
  }

  public getGenderListSeasonOwWise() {
    this.masterService.getGenderListSeasonOwWise(this.get.seasonId.value, this.get.orderWindowId.value, this.get.divisionId.value).subscribe(
      sResponseModel => {
        // console.log('Gender DropDown Data:', sResponseModel.data);
        if (sResponseModel.data) {
          this.genderList = sResponseModel.data;
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public getCategory1ListSeasonOwWise() {
    this.masterService.getCategory1ListSeasonOwWise(this.get.seasonId.value, this.get.orderWindowId.value, this.get.divisionId.value, this.get.genderId.value).subscribe(
      sResponseModel => {
        // console.log('Category1 DropDown Data:', sResponseModel.data);
        if (sResponseModel.data) {
          this.category1List = sResponseModel.data;
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public getCategory4ListSeasonOwWise() {
    this.masterService.getCategory4ListSeasonOwWise(this.seasonId, this.orderWindowId, this.get.divisionId.value, this.get.genderId.value, this.get.category1Id.value).subscribe(
      sResponseModel => {
        // console.log('Category4 DropDown Data:', sResponseModel.data);
        if (sResponseModel.data) {
          this.category4List = sResponseModel.data;
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }


  brandAdminExportOrdersDetails() {
    this.submitted = true;
    this.common.showSpinner();
    if (this.brandAdminExportFilterForm.valid) {
      let accessMapForm = this.brandAdminExportFilterForm.value;
      // console.log('form',accessMapForm);
      
      this.orderService.exportOrdersDetailsBrandAdmin(accessMapForm).subscribe((sResponse: any) => {
        // console.log(sResponse);
        if (sResponse) {
          
          let fileTypeName = '';
          if(accessMapForm.mType == 'footwareConsolidatedOrders'){
            fileTypeName = 'Footwear Consolidated Orders';
          }
          else{
            fileTypeName = 'Apparel Equipment Consolidated Orders';
          }
          const fileName = fileTypeName;

          saveAs(sResponse, fileName + '.xlsx');
          this.common.openSnackBar('File Downloaded!!!', '', 'success-snackbar');
          this.common.hideSpinner();
        }
      },
      sError => {
        // console.log("error", sError);
        this.common.openSnackBar('Could not Downloaded File!!!', '', 'danger-snackbar');
        this.common.hideSpinner();
        this.common.apiError(sError);
      });  
    }
    else{
      this.common.openSnackBar('Please select All the Mandatory Fields', '', 'danger-snackbar');
      this.common.hideSpinner();
    }
    
  }


}
