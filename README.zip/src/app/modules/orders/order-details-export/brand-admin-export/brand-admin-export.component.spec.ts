import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrandAdminExportComponent } from './brand-admin-export.component';

describe('BrandAdminExportComponent', () => {
  let component: BrandAdminExportComponent;
  let fixture: ComponentFixture<BrandAdminExportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrandAdminExportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrandAdminExportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
