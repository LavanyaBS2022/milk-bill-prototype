import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-suggested-article',
  templateUrl: './suggested-article.component.html',
  styleUrls: ['./suggested-article.component.scss']
})
export class SuggestedArticleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
