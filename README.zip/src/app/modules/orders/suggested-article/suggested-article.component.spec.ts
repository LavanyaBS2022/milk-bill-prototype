import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuggestedArticleComponent } from './suggested-article.component';

describe('SuggestedArticleComponent', () => {
  let component: SuggestedArticleComponent;
  let fixture: ComponentFixture<SuggestedArticleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuggestedArticleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuggestedArticleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
