import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardService } from '../../shared/service/guard/auth-guard.service';

// Import Containers
import {
    AdminLayoutComponent,
    FullLayoutComponent,
    SimpleLayoutComponent
} from '../../containers';
import { TargetSalesComponent } from './target-sales/target-sales.component';
import { ArticleBookingComponent } from './article-booking/article-booking/article-booking.component';

import { ListFranchiseeOrderComponent } from "./order-list/list-franchisee-order/list-franchisee-order.component";
import { CanActivate } from '@angular/router/src/utils/preactivation';
import { OrderReviewComponent } from "./order-review/order-review/order-review.component";
import { StoreSalesAnalysisComponent } from "./store-sales-analysis/store-sales-analysis.component";
import { SuggestedArticleComponent } from "./suggested-article/suggested-article.component";

import { BrandAdminExportComponent } from "./order-details-export/brand-admin-export/brand-admin-export.component";
import { ExportMasterComponent } from '../masters/export-master/export-master.component';
import { ImportConsolidateorderComponent } from '../masters/import-consolidateorder/import-consolidateorder.component';

const routes: Routes = [
    {
        path: 'target-sales',
        component: TargetSalesComponent,
        data: {
            title: 'Target Sales',
            module: 'Orders',
            permission: 'targetSales'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'article-booking',
        component: ArticleBookingComponent,
        data: {
            title: 'article booking',
            module: 'Orders',
            permission: 'orderEntry'
        },
        canActivate: [AuthGuardService]
    },

    {
        path: 'listFranchiseeOrder',
        component: ListFranchiseeOrderComponent,
        data: {
            title: 'Order List',
            module: 'Orders',
            permission: 'orderList'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'orderReview',
        component: OrderReviewComponent,
        data: {
            title: 'Order Review',
            module: 'Orders',
            permission: 'orderReview'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'store-sales-analysis',
        component: StoreSalesAnalysisComponent,
        data: {
            title: 'Store Sales Analysis',
            module: 'Orders',
            permission: 'storeSalesAnalysis'
        },
        canActivate: [AuthGuardService]
        // canActivate: [AuthGuardService]
    },
    {
        path: 'suggested-article',
        component: SuggestedArticleComponent,
        data: {
            title: 'Suggested Article',
            module: 'Orders',
            permission: 'storeSalesAnalysis'
        },
        canActivate: [AuthGuardService]
        // canActivate: [AuthGuardService]
    },

    {
        path: 'brandAdminExport',
        component: BrandAdminExportComponent,
        data: {
            title: 'Order Details Export',
            module: 'Orders',
            permission: 'orderBrandAdminExport'
        },
        // canActivate: [AuthGuardService]        
    },

    {
        path: 'exportMaster',
        component: ExportMasterComponent,
        data: {
            title: 'exportMaster',
            module: 'Masters',
            permission: 'OrderSheetExport'
        },
        canActivate: [AuthGuardService]
    },
    {
        path: 'importConsolidateOrder',
        component: ImportConsolidateorderComponent,
        data: {
            title: 'importConsolidateOrder',
            module: 'Masters',
            permission: 'importConsolidateOrder'
        },
        canActivate: [AuthGuardService]
    },


];

@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ],
    exports: [
        RouterModule
    ]
})

export class OrdersRoutingModule { }
