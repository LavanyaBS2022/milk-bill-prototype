import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';
import { OrdersService } from './../../../../shared/service/orders/orders.service';
import { Router } from '@angular/router';
import { Common } from '../../../../shared/service/common/common';
import { DatePipe } from "@angular/common";
import { MastersService } from '../../../../shared/service/masters/masters.service';
import { NgxSpinnerService } from "ngx-spinner";
import * as _ from 'lodash';

@Component({
  selector: 'app-list-franchisee-order',
  templateUrl: './list-franchisee-order.component.html',
  styleUrls: ['./list-franchisee-order.component.scss']
})
export class ListFranchiseeOrderComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  public orderList_datasource = new MatTableDataSource();
  public status = '';
  public orderList: any;
  public maxDate;
  public minDate;
  seasonList: any;
  orderWindowList: any;
  selectedSeason: any;
  selectedWindow: any;
  activeSeason: any;
  selectedOrder:any;
  public userDetails: any;
  public currentLoggedInUser;
  public currentLoggedInUserName;
  public roleId;
  public userId;
  public customerTypeId;
  orderListDisplayedColumns: string[] = ['orderno', 'franchiseename', 'storename', 'orderdate', 'season', 'totalSku', 'totalQuantity', 'bookingbudget', 'status'];

  constructor(private spinner:NgxSpinnerService, private masterSrv: MastersService, private orderService: OrdersService, public router: Router, public common: Common, private OrderDate: DatePipe) { 
    this.userDetails = this.common.getUserDetails();
    // console.log('this.userDetails', this.userDetails);
    this.currentLoggedInUser = this.userDetails.user_id
    this.currentLoggedInUserName = this.userDetails.name
    this.roleId=this.userDetails.roleId;
    this.userId=this.userDetails.user_id;
    if(this.userDetails.roleId[0] == '5f3f65a09c0ed02bbc9e478f'){
      this.customerTypeId=2;
    }else{
      this.customerTypeId=1;
    }
   
  }

  ngOnInit() {
    // this.getListFranchiseeOrder();
    this.getSeasonListData();
    // this.getOrderWindowListData();
    // console.log('Date Now:', new Date());
    // console.log('Order Date:', this.OrderDate.transform(Date.now(), "dd-MM-yyyy"));
  }

  public getOrderWindowListData() {

    const onlyActive = 0;
    this.masterSrv.getOrderWindowSeasonList(onlyActive).subscribe((data) => {
       //console.log('getOrderWindowList', data.data);
      if (data.status) {
        // this.orderWindowList = data.data;
        // console.log('this.selectedSeason',this.selectedSeason);
        this.orderWindowList = data.data.filter(x => x.season_id == this.selectedSeason.id);
        this.selectedOrder = 0;
        this.getListFranchiseeOrder();
      }
      else {
        this.common.openSnackBar('No Data Found', '', 'danger-snackbar');
      }
    },
      sError => {
        this.common.apiError(sError);
      });
  }

  public getSeasonListData() {
    this.masterSrv.getlistSeason().subscribe(
      sResponseModel => {
        if (sResponseModel.status) {
          this.seasonList = sResponseModel.data
          const activeSeasonList =  this.seasonList.filter(item => item.active_season == 1);
          this.selectedSeason = activeSeasonList[0];
          this.getOrderWindowListData();
        }
        else {
          this.common.openSnackBar('No season found', '', 'danger-snackbar');
        }
      },
      sError => {
        this.common.apiError(sError);
      });
  }

  applyFilter1(event) {
    console.log(event.value);
    if (event.value) {
      this.orderList_datasource.data = this.orderList.filter(d => (d.season_id == event.value.season_id && d.order_window_id == event.value.id));
    } else {
      this.orderList_datasource.data = this.orderList;
    }
  }

  applyFilter(event, input?) {
    let filterValue;
    if (input == 'select') {
      filterValue = event.value;
    } else if (input == 'frm') {
      this.minDate = new Date(event.value);
    } else if (input == 'to') {
      this.maxDate = new Date(event.value);
    } else {
      filterValue = event.target.value;
    }
    // console.log('frm',this.minDate);
    //console.log('to',this.maxDate);
    //console.log('orderlist',this.orderList);
    if (filterValue || filterValue == '') {
      this.orderList_datasource.filter = filterValue.trim().toLowerCase();
    } else if (this.minDate && this.minDate != '') {
      this.orderList_datasource.data = this.orderList.filter(d => {
        let dt = new Date(d.created_date);
        return dt >= this.minDate;
      });
    } else if (this.maxDate && this.maxDate != '') {
      this.orderList_datasource.data = this.orderList.filter(d => {
        let dt = new Date(d.created_date);
        return dt <= this.maxDate;
      });
    } else if (this.minDate && this.maxDate) {
      this.orderList_datasource.data = this.orderList.filter(d => {
        let dt = new Date(d.created_date);
        return dt >= this.minDate && dt <= this.maxDate;
      });
    }
  }

  public getListFranchiseeOrder() {
    // console.log('this.selectedSeason',this.selectedSeason);
    // console.log('this.selectedOrder',this.selectedOrder);
    const seasonId = (this.selectedSeason)?this.selectedSeason.id:0;
    const orderWindowId = (this.selectedOrder == 0)?0:this.selectedOrder.id;

    console.log('seasonId',seasonId);
    console.log('orderWindowId',orderWindowId);

    this.orderService.getListFranchiseeOrder(seasonId,orderWindowId,this.roleId,this.userId).subscribe(
      sResponseModel => {
         //console.log("Order List Data:", sResponseModel.data);
        if (sResponseModel.data) {
          this.orderList_datasource.data = sResponseModel.data;
          this.orderList = sResponseModel.data;
          this.orderList_datasource.paginator = this.paginator;
        }
        else {
          this.orderList_datasource.data = [];
          this.orderList = [];
          this.common.openSnackBar('No Order found', '', 'danger-snackbar');
        }
      },
      sError => {
        this.common.apiError(sError);
      }
    );
  }

  public OrderReview(id, status,seasonId,orderwindowId,brandId,franchiseId,storeId,countryId) {
    const orderId = btoa(id);
    const orderStatus = btoa(status);
    const sid= btoa(seasonId);
    const owid= btoa(orderwindowId);
    const bid= btoa(brandId);
    const cusid=btoa(franchiseId);
    const storeid=btoa(storeId);
    const countryid=btoa(countryId);
    let  owdata=_.find(this.orderWindowList,{id:orderwindowId});
    const owtype=btoa(owdata.ow_type);
    const owname=btoa(owdata.name);
    //console.log(orderwindowId+"--"+owtype);
    
    //console.log(owdata);
    
    this.router.navigate(['/orders/orderReview'], { queryParams: { orderId, orderStatus,sid,owid,bid,owtype,cusid,storeid,countryid,owname } });
  }
  checkRevertBtnVisibility(order_status) {
    if (order_status == 'Approved' || order_status == 'Rejected' ) {
      return true;
    }
    else {
      return false;
    }
  }
  revertStatus(o_id){
    this.common.openConfirmDialog('Are you sure you want to revert status?')
        .afterClosed().subscribe(res => {
          if (res) {
            this.spinner.show();
            const postData= 
            { 
              review_status_id : 3,
              o_id: parseInt(o_id), 
              user_id: this.currentLoggedInUser, 
              user_name: this.currentLoggedInUserName, 
            };
            this.orderService.postOrderReviewProcess(postData).subscribe((data) => {
              this.spinner.hide();
              if (data.status) {
                // this.router.navigate(['orders/listFranchiseeOrder']);
                this.router.routeReuseStrategy.shouldReuseRoute = () => false;
                this.router.onSameUrlNavigation = 'reload';
                this.router.navigate(['/orders/listFranchiseeOrder']);

                this.common.openSnackBar(`Order Status Reverted Successfuly for ORD_${o_id}  !!!`, '', 'success-snackbar');
              } else {
                this.common.openSnackBar('Order Action Process Error', '', 'danger-snackbar');
              }
            },
            sError => {
                this.common.apiError(sError);
            }); 
          }
        });
        
  }
}


