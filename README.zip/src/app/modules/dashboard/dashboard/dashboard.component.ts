import { Component, OnInit, Inject } from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from "@angular/router";
import { MatTableDataSource, MatPaginator, MatSort, MatTabChangeEvent } from "@angular/material";
import { DashboardService } from "../../../shared/service/dashboard/dashboard.service";
import { MastersService } from "../../../shared/service/masters/masters.service";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Common } from './../../../shared/service/common/common';
import { ReportsService } from '../../../shared/service/reports/reports.service';
import * as _ from 'lodash';
import { saveAs } from 'file-saver';
import { HttpParams } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { DialogOrderWindowComponent } from '../../../shared/components/dialog-order-window/dialog-order-window.component';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  public seasonId: any;
  public orderWindowId: any;
  public orderStatus: any;
  public totalOrderAmount: any;
  public totalNoOfFranchisee: number;
  public totalArticles: number;
  public totalOrderQty: any;
  public orderByFranchiseeTypeData = [];
  public category1WiseTotalOrderData = [];
  public orderByGenderData = [];
  public orderByCountryData = [];
  public orderByTop5MoqArticleData = [];
  public orderByTop5GenderwiseData = [];
  public totalOrderbyMen: any;
  public totalOrderbyWomen: any;
  public totalOrderbyUnisex: any;
  public totalOrderbyKids: any;
  // Pie
  public pieChartLabels: string[] = [];
  public pieChartData: any[] = [];
  public pieChartType = 'pie';
  // bar chart
  public barChartLabels: string[] = [];
  public barChartData: any[] = [];
  public barChartType = 'bar';
  public barChartLegend = true;
  // Order by Country PIE Chart
  public pieChartOrderbyCountryLabels: string[] = [];
  public pieChartOrderbyCountryData: any = [];
  public pieChartOrderbyCountryType = 'pie';
  // Order by Gender PIE chart
  public pieChartOrderbyGenderLabels: string[] = [];
  public pieChartOrderbyGenderData: any = [];
  public pieChartOrderbyGenderType = 'pie';
  // Horizontal bar chart
  public hBarTop5MoqArticleChartLabels: string[] = [];
  public hBarTop5MoqArticleChartData: any[] = [];
  public horizontalBarChartType = 'horizontalBar';
  public horizontalBarChartLegend = true;

  public hBarTop5MenChartData: any = [];
  public hBarTop5MenChartDataApeq: any = [];
  public hBarTop5WomenChartData: any = [];
  public hBarTop5WomenChartDataApeq: any = [];
  public hBarTop5UnisexChartData: any = [];
  public hBarTop5UnisexChartDataApeq: any = [];
  public hBarTop5KidsChartData: any = [];

  public hBarTop5MenChartLabels: string[] = [];
  public hBarTop5MenChartLabelsApeq: string[] = [];
  public hBarTop5WomenChartLabels: string[] = [];
  public hBarTop5WomenChartLabelsApeq: string[] = [];
  public hBarTop5UnisexChartLabels: string[] = [];
  public hBarTop5UnisexChartLabelsApeq: string[] = [];
  public hBarTop5KidsChartLabels: string[] = [];
  public orderWindowSeasonList = [];
  public orderWindowIdSelected: any;
  public userDetails;

  public boolBarChartData: boolean = false;
  public boolPieChartData: boolean = false;
  public boolPieChartOrderbyCountryData: boolean = false;
  public boolPieChartOrderbyGender: boolean = false;
  public hBarboolTop5MoqArticleChartData: boolean = false;
  public hBarboolTop5MenChartData: boolean = false;
  public hBarboolTop5MenChartDataApeq: boolean = false;
  public hBarboolTop5WomenChartData: boolean = false;
  public hBarboolTop5WomenChartDataApeq: boolean = false;
  public hBarboolTop5UnisexChartData: boolean = false;
  public hBarboolTop5UnisexChartDataApeq: boolean = false;
  public hBarboolTop5KidsChartData: boolean = false;
  public brandList = [];
  public brandId;
  public franchiseId: any;
  public roleId;
  public userId;
  selectedCountry: any;
  public orderWindowType:any;

  public labelCustomerStore: string;

  // for reports
  public activityreports: any = [];
  public activityReportsKeys: any = [];
  public monthlyReports: any = [];
  public orderSummary: any = [];
  public cloneOrderSummary: any = [];
  public orderAnalysis: any = [];
  public countries: any = [];
  public genderFlex: any = '';
  public franchiseList: any;

  constructor(private formBuilder: FormBuilder, public route: ActivatedRoute, public dashboardService: DashboardService, public router: Router, private mastersService: MastersService, public dialog: MatDialog, public common: Common, public reportSrv: ReportsService, private datePipe: DatePipe) {
    this.route.queryParams.subscribe(params => {
      // this.seasonId = (atob(params.seasonId));  //Need to UnComment after OrderWindow form
      // this.orderWindowId = (atob(params.orderWindowId));
      // this.orderStatus = (atob(params.orderStatus));
      // this.orderStatus = 1;
      this.userDetails = this.common.getUserDetails();
      // this.franchiseList = this.userDetails.sales_customer.length > 0 ? this.userDetails.sales_customer.toString() : '';
      if (this.userDetails.userType == 1) {
        this.genderFlex = 33;
      } else {
        this.genderFlex = 50;
      }
      // console.log('this.userDetails', this.userDetails);

      // if (this.userDetails.franchiseId > 0 && !this.userDetails.seasonId && !this.userDetails.orderWindowId) {
      if (this.userDetails.franchiseId > 0 && !this.userDetails.seasonId && !this.userDetails.orderWindowId) {
        // this.getBrandList(this.userDetails.franchiseId);
        this.generatePopUp();

        //set to userDeatils
        this.mastersService.getlistFranchiseById(this.userDetails.franchiseId).subscribe(data => {
          let userDetails = this.common.getUserDetails();
          userDetails.countryId = data.data[0].country_id;
          userDetails.accessPriority = data.data[0].franchise_type;
          userDetails.franchiseDetails = data.data[0];
          // console.log("user details", userDetails);
          this.common.setUserDetails(userDetails);
        },
          sError => {
            this.common.apiError(sError);
          });
      }
      else if (this.userDetails.franchiseId > 0 && this.userDetails.seasonId && this.userDetails.orderWindowId && this.userDetails.brandId) {
        // console.log('fffffffffffff');
        
        //This else if block will execute for once Franchise Logged in, then page reload or on click of Dashboard module will call. 
        this.seasonId = this.userDetails.seasonId;
        this.orderWindowId = this.userDetails.orderWindowId;
        this.brandId = this.userDetails.brandId;
        this.franchiseId = this.userDetails.franchiseId;
        this.roleId=0;
        this.userId=0;

        this.getTotalOrderAmount();
        this.getCategory1WiseTotalOrder();
        this.getOrdersbyFranchiseeType();
        this.getOrdersbyGender();
        this.getOrdersbyCountry();
        this.getOrdersbyTop5MoqArticle();
        this.getOrdersbyTop5Gender();
        this.getActivityReport();
      }
      else {
        this.seasonId = this.userDetails.activeSeason;
        this.orderWindowId = 0;
        this.brandId = 0;
        this.franchiseId = 0;
        this.roleId=this.userDetails.roleId;
        this.userId=this.userDetails.user_id;

        //console.log('seasonId',this.seasonId);
        
        if (this.seasonId) {
          this.getTotalOrderAmount();
          this.getCategory1WiseTotalOrder();
          this.getOrdersbyFranchiseeType();
          this.getOrdersbyGender();
          this.getOrdersbyCountry();
          this.getOrdersbyTop5MoqArticle();
          this.getOrdersbyTop5Gender();
          this.getActivityReport();
        }
      }
    });
  }
  // public getBrandList(franchiseId) {
  //   this.mastersService.getBrandListByFranchiseId(franchiseId, 1).subscribe(
  //     sResponseModel => {
  //       if (sResponseModel.status) {
  //         this.brandList = sResponseModel.data;
  //         // console.log('getBrandListByFranchiseId', sResponseModel.data);
  //       }
  //       else{
  //         this.common.openSnackBar('No Brand Found For Logged In Customer','', 'danger-snackbar');
  //       }
  //     }, sError => {
  //       // // console.log('Dashboard Total Order Amount Error', sError);
  //       this.common.apiError(sError);
  //     }
  //   );
  // }
  public barChartOptions: any = {
    scaleShowVerticalLines: false,
    responsive: true,
    barThickness: 10
  };

  public barChartColors: Array<any> = [
    { backgroundColor: '#008ffb' },
    { backgroundColor: '#00e396' },
    { backgroundColor: '#feb019' }
  ];

  public horizontalBarChartOptions: any = {
    scaleShowVerticalLines: false,
    responsive: true,
    barThickness: 10
  };

  public horizontalBarChartColors: Array<any> = [
    { backgroundColor: '#0D98FF' },
    { backgroundColor: '#0450C2' }
  ];


  // events
  public chartClicked(e: any): void {
    // // console.log(e);
  }

  public chartHovered(e: any): void {
    // // console.log(e);
  }

  ngOnInit() {

  }



  getActivityReport(): void {
    this.reportSrv.getActivityReport(this.seasonId, this.orderWindowId, this.franchiseId, this.brandId,this.roleId,this.userId).subscribe(sResponseModel => {
     // console.log('Reports',sResponseModel.data);
      
      if (sResponseModel.data) {
        this.activityreports = _.groupBy(sResponseModel.data, o => (o.div_name))
         //console.log('activityreports',this.activityreports);
        this.activityReportsKeys = Object.keys(this.activityreports)
        //console.log('activityReportsKeys',this.activityReportsKeys);
        
      }
    },
      sError => {
        this.common.apiError(sError);
      });
  }

  getActivityExcelReport(): void {
    const fileType = "activityreport"
    const date = this.datePipe.transform(new Date(), 'dd-MMM-yyyy')
    this.reportSrv.getActivityExcelReport(this.seasonId, this.orderWindowId, this.franchiseId, this.brandId).subscribe(sResponse => {
      if (sResponse) {
        saveAs(sResponse, fileType.toUpperCase() + '-' + date + '.xlsx');
      }
    },
      sError => {
        this.common.apiError(sError);
      });
  }


  private onTabChanged(event: MatTabChangeEvent): void {

    switch (event.index) {
      case 0: {
        // Activity Report
        //   this.getActivityReport();
        this.getActivityReport();
        break;
      }

      case 1: {
        // Order Summary

        this.getOrderSummary();
        this.getCountryList();
        break;
      }

      case 2: {
        // Monthly wise report
        //  this.getMonthlyWiseReport();
        this.getOrderAnalysis();
        break;
      }

      case 3: {
        // Order Analysis

        break;
      }

      default: {
        // Activity Report
        this.getActivityReport();
        break
      }

    }
  }

  private getMonthlyWiseReport(): void {
    this.reportSrv.getMonthlyWiseReport(this.seasonId, this.orderWindowId, this.franchiseId, this.brandId).subscribe(sResponseModel => {
      if (sResponseModel.data) {
        this.monthlyReports = this.sortByMonth(sResponseModel.data);
      }
    },
      sError => {
        this.common.apiError(sError);
      });
  }


  private sortByMonth(monthReports): any[] {
    var months = ["january", "february", "march", "april", "may", "june",
      "july", "august", "september", "october", "november", "december"];
    monthReports.sort((a, b) => {
      return months.indexOf(a.ord_launch_month.toLowerCase())
        - months.indexOf(b.ord_launch_month.toLowerCase());
    });
    return monthReports;
  }

  private getOrderSummary(): void {
    this.reportSrv.getOrderSummary(this.seasonId, this.orderWindowId, this.franchiseId, this.brandId,this.roleId,this.userId).subscribe(sResponseModel => {
     // console.log('ordersummery',sResponseModel.data);
      
      if (sResponseModel.data) {
        this.orderSummary = sResponseModel.data;
        this.cloneOrderSummary = _.cloneDeep(this.orderSummary)
        //sconsole.log('clone',this.cloneOrderSummary);
        
      }
    },
      sError => {
        this.common.apiError(sError);
      });
  }



  private getOrderAnalysis(): void {
    this.reportSrv.getOrderAnalysis(this.seasonId, this.orderWindowId, this.franchiseId, this.brandId,this.roleId,this.userId).subscribe(sResponseModel => {
      //console.log('orderAnalysis',sResponseModel.data);
      
      if (sResponseModel.data) {
        this.orderAnalysis = sResponseModel.data;
      }
    },
      sError => {
        this.common.apiError(sError);
      });
  }

  public getCountryList(): void {
    this.mastersService.getCountry().subscribe(sResponseModel => {
      this.countries = sResponseModel.data;
      let userDetails = this.common.getUserDetails();
      if (userDetails.franchiseId > 0 && userDetails.countryId) {
        this.countries = _.filter(this.countries, (o) => o.id == userDetails.countryId)
        this.selectedCountry = this.countries[0].name
      }

    },
      sError => {
        this.common.apiError(sError);
      });
  }

  public getTotalOrderAmount() {
    this.dashboardService.getTotalOrderAmount(this.seasonId, this.orderWindowId, this.brandId, this.franchiseId,this.roleId,this.userId).subscribe(
      sResponseModel => {
        console.log('Dashboard Total Order Data:', sResponseModel);
        if (sResponseModel.data.length > 0) {

          if (this.userDetails.franchiseId > 0) {
            this.totalOrderAmount = sResponseModel.data[0][0].totalorderamount === "" ? 0 : sResponseModel.data[0][0].totalorderamount;
            this.totalNoOfFranchisee = sResponseModel.data[1][0].totalfranchisee;
            this.labelCustomerStore = 'Store';
          }
          else {
            this.totalOrderAmount = sResponseModel.data[0][0].totalsgdvalue === "" ? 0 : sResponseModel.data[0][0].totalsgdvalue;
            this.totalNoOfFranchisee = sResponseModel.data[1][0].totalfranchisee;
            this.labelCustomerStore = 'Customer';
          }
          this.totalArticles = sResponseModel.data[2][0].totalarticles;
          this.totalOrderQty = sResponseModel.data[3][0].totalorderqty === "" ? 0 : sResponseModel.data[3][0].totalorderqty;
        }
      }, sError => {
        // // console.log('Dashboard Total Order Amount Error', sError);
        this.common.apiError(sError);
      }
    );
  }

  /**getCategory1WiseTotalOrder or (getProductTypeWiseTotalOrder)
   * Dashboard Total Order Vertical Bar Chart
   */
  public getCategory1WiseTotalOrder() {
    this.dashboardService.getCategory1WiseTotalOrder(this.seasonId, this.orderWindowId, this.brandId, this.franchiseId,this.roleId,this.userId).subscribe(
      sResponseModel => {
        // console.log('Dashboard Category_1 wise Total Order Data:', sResponseModel.data);
        if (sResponseModel.data.length > 0) {
          let tempBarData = [];
          let tempBarQtyData = [];
          let tempBarSkuData = [];
          this.category1WiseTotalOrderData = sResponseModel.data;
          this.category1WiseTotalOrderData.forEach(key => {
            this.barChartLabels.push(key.category_1);
            tempBarQtyData.push(key.total_qty);
            tempBarData.push((this.userDetails.franchiseId > 0) ? key.total_amount : key.totalsgdvalue);
            tempBarSkuData.push(key.sku);
          });
          this.barChartData = [{ data: tempBarQtyData, label: 'Total Qty' },
          { data: tempBarData, label: 'Total Amount' },
          { data: tempBarSkuData, label: 'Total SKU' }];
          this.boolBarChartData = true;
        }
      }, sError => {
        // // console.log('Dashboard Category_1 wise Total Order Error', sError);
        this.common.apiError(sError);
      }
    );
  }

  /** getOrdersbyFranchiseeType
   * Dashboard Franchisee Type Total Order PIE Chart
   */
  public getOrdersbyFranchiseeType() {
    this.dashboardService.getOrdersbyFranchiseeType(this.seasonId, this.orderWindowId, this.brandId, this.franchiseId,this.roleId,this.userId).subscribe(
      sResponseModel => {
        // console.log('Dashboard Franchisee Type Total Order Data:', sResponseModel.data);
        if (sResponseModel.data.length > 0) {
          this.orderByFranchiseeTypeData = sResponseModel.data;
          this.orderByFranchiseeTypeData.forEach(key => {
            this.pieChartLabels.push(key.franchisee_type);
            this.pieChartData.push((this.userDetails.franchiseId > 0) ? key.total_amount : key.totalsgdvalue);
            this.boolPieChartData = true;
          });
        }
      }, sError => {
        // // console.log('Dashboard Franchisee Type Total Order Error', sError);
        this.common.apiError(sError);
      }
    );
  }

  /**
   * getOrdersByGender
   */
  public getOrdersbyGender() {
    this.dashboardService.getOrdersbyGender(this.seasonId, this.orderWindowId, this.brandId, this.franchiseId,this.roleId,this.userId).subscribe(
      sResponseModel => {
        // console.log('Dashboard Order by Gender Data:', sResponseModel.data);
        if (sResponseModel.data.length > 0) {
          this.orderByGenderData = sResponseModel.data;
          // console.log(this.orderByGenderData)
          this.orderByGenderData.forEach(key => {
            if (key.gender === 'MEN')
              this.totalOrderbyMen = (this.userDetails.franchiseId > 0) ? key.total_amount : key.totalsgdvalue;
            if (key.gender === 'WOMEN')
              this.totalOrderbyWomen = (this.userDetails.franchiseId > 0) ? key.total_amount : key.totalsgdvalue;
            if (key.gender === 'UNISEX')
              this.totalOrderbyUnisex = (this.userDetails.franchiseId > 0) ? key.total_amount : key.totalsgdvalue;
            if (key.gender === 'KIDS')
              this.totalOrderbyKids = (this.userDetails.franchiseId > 0) ? key.total_amount : key.totalsgdvalue;
          });
          this.boolPieChartOrderbyGender = true;
          this.pieChartOrderbyGenderLabels = ['MEN', 'WOMEN', 'KIDS', 'UNISEX'];
          this.pieChartOrderbyGenderData = [this.totalOrderbyMen, this.totalOrderbyWomen, this.totalOrderbyKids, this.totalOrderbyUnisex];
        }
      }, sError => {
        // // console.log('Dashboard Order by Gender Error', sError);
        this.common.apiError(sError);
      }
    );
  }

  /**
   * getOrdersbyCountry
   */
  public getOrdersbyCountry() {
    this.dashboardService.getOrdersbyCountry(this.seasonId, this.orderWindowId, this.brandId, this.franchiseId,this.roleId,this.userId).subscribe(
      sResponseModel => {
        // console.log('Dashboard Order by Country Data:', sResponseModel.data);
        if (sResponseModel.data.length > 0) {
          this.orderByCountryData = sResponseModel.data;
          const reducer = (accumulator, currentValue) => accumulator + currentValue;
          let total_sum = this.orderByCountryData.map(amt => Number(amt.total_amount)).reduce(reducer);
          this.orderByCountryData.forEach(key => {
            this.pieChartOrderbyCountryLabels.push(key.country);
            // let percentVal = Math.round((key.total_amount / total_sum) * 100) + '%';
            // this.pieChartOrderbyCountryData.push(percentVal);
            this.pieChartOrderbyCountryData.push((Math.round((key.total_amount / total_sum) * 100)));
            this.boolPieChartOrderbyCountryData = true;
          });
        }
      }, sError => {
        // // console.log('Dashboard Order by Country Error', sError);
        this.common.apiError(sError);
      }
    );
  }

  /**
   * getOrdersbyTop5MoqArticle
   */
  public getOrdersbyTop5MoqArticle() {
    this.dashboardService.getOrdersByTop5MoqArticle(this.seasonId, this.orderWindowId, this.brandId, this.franchiseId,this.roleId,this.userId).subscribe(
      sResponseModel => {
        // console.log('Dashboard Order by Top5 Moq Article Data:', sResponseModel.data);
        if (sResponseModel.data.length > 0) {
          let tempHorizontalBarQtyData = [];
          let tempHorizontalBarMoqData = [];
          this.orderByTop5MoqArticleData = sResponseModel.data;
          this.orderByTop5MoqArticleData.forEach(key => {
            this.hBarTop5MoqArticleChartLabels.push(key.article_description);
            tempHorizontalBarMoqData.push(key.moq);
            tempHorizontalBarQtyData.push(key.qty);
          });
          this.hBarTop5MoqArticleChartData = [{ data: tempHorizontalBarMoqData, label: 'MOQ' }, { data: tempHorizontalBarQtyData, label: 'Total Qty' }];
          this.hBarboolTop5MoqArticleChartData = true;
        }
      }, sError => {
        // // console.log('Dashboard Order by Top5 Moq Article Error', sError);
        this.common.apiError(sError);
      }
    );
  }

  /**
   * getOrdersbyTop5Gender
   */
  public getOrdersbyTop5Gender() {
    this.dashboardService.getOrdersbyTop5Gender(this.seasonId, this.orderWindowId, this.brandId, this.franchiseId,this.roleId,this.userId).subscribe(
      sResponseModel => {
        // console.log('Dashboard Order by Top5 Genderwise Data:', sResponseModel.data);
        if (sResponseModel.data.length > 0) {
          this.orderByTop5GenderwiseData = sResponseModel.data;

          if (this.orderByTop5GenderwiseData[0] != false) {
            const tempHorizontalBarAmtData = [];
            const tempHorizontalBarQtyData = [];
            this.orderByTop5GenderwiseData[0].forEach(key => {
              this.hBarTop5MenChartLabels.push(key.article_description);
              tempHorizontalBarQtyData.push(key.total_qty);
              tempHorizontalBarAmtData.push((this.userDetails.franchiseId > 0) ? key.total_price : key.totalsgdvalue);
            });
            this.hBarTop5MenChartData = [{ data: tempHorizontalBarQtyData, label: 'Total Qty' }, { data: tempHorizontalBarAmtData, label: 'Total Amount' }];
            //console.log(this.hBarTop5MenChartData);

            this.hBarboolTop5MenChartData = true;
          }

          if (this.orderByTop5GenderwiseData[4] != false) {
            const tempHorizontalBarAmtData = [];
            const tempHorizontalBarQtyData = [];
            this.orderByTop5GenderwiseData[4].forEach(key => {
              this.hBarTop5MenChartLabelsApeq.push(key.article_description);
              tempHorizontalBarQtyData.push(key.total_qty);
              tempHorizontalBarAmtData.push((this.userDetails.franchiseId > 0) ? key.total_price : key.totalsgdvalue);
            });
            this.hBarTop5MenChartDataApeq = [{ data: tempHorizontalBarQtyData, label: 'Total Qty' }, { data: tempHorizontalBarAmtData, label: 'Total Amount' }];
            //console.log(this.hBarTop5MenChartData);

            this.hBarboolTop5MenChartDataApeq = true;
          }

          if (this.orderByTop5GenderwiseData[1] != false) {
            const tempHorizontalBarAmtData = [];
            const tempHorizontalBarQtyData = [];
            this.orderByTop5GenderwiseData[1].forEach(key => {
              this.hBarTop5WomenChartLabels.push(key.article_description);
              tempHorizontalBarQtyData.push(key.total_qty);
              tempHorizontalBarAmtData.push((this.userDetails.franchiseId > 0) ? key.total_price : key.totalsgdvalue);
            });
            this.hBarTop5WomenChartData = [{ data: tempHorizontalBarQtyData, label: 'Total Qty' }, { data: tempHorizontalBarAmtData, label: 'Total Amount' }];
            this.hBarboolTop5WomenChartData = true;
          }

          if (this.orderByTop5GenderwiseData[5] != false) {
            const tempHorizontalBarAmtData = [];
            const tempHorizontalBarQtyData = [];
            this.orderByTop5GenderwiseData[5].forEach(key => {
              this.hBarTop5WomenChartLabelsApeq.push(key.article_description);
              tempHorizontalBarQtyData.push(key.total_qty);
              tempHorizontalBarAmtData.push((this.userDetails.franchiseId > 0) ? key.total_price : key.totalsgdvalue);
            });
            this.hBarTop5WomenChartDataApeq = [{ data: tempHorizontalBarQtyData, label: 'Total Qty' }, { data: tempHorizontalBarAmtData, label: 'Total Amount' }];
            this.hBarboolTop5WomenChartDataApeq = true;
          }

          if (this.orderByTop5GenderwiseData[2] != false) {
            const tempHorizontalBarAmtData = [];
            const tempHorizontalBarQtyData = [];
            this.orderByTop5GenderwiseData[2].forEach(key => {
              this.hBarTop5UnisexChartLabels.push(key.article_description);
              tempHorizontalBarQtyData.push(key.total_qty);
              tempHorizontalBarAmtData.push((this.userDetails.franchiseId > 0) ? key.total_price : key.totalsgdvalue);
            });
            this.hBarTop5UnisexChartData = [{ data: tempHorizontalBarQtyData, label: 'Total Qty' }, { data: tempHorizontalBarAmtData, label: 'Total Amount' }];
            this.hBarboolTop5UnisexChartData = true;
          }

          if (this.orderByTop5GenderwiseData[6] != false) {
            const tempHorizontalBarAmtData = [];
            const tempHorizontalBarQtyData = [];
            this.orderByTop5GenderwiseData[6].forEach(key => {
              this.hBarTop5UnisexChartLabelsApeq.push(key.article_description);
              tempHorizontalBarQtyData.push(key.total_qty);
              tempHorizontalBarAmtData.push((this.userDetails.franchiseId > 0) ? key.total_price : key.totalsgdvalue);
            });
            this.hBarTop5UnisexChartDataApeq = [{ data: tempHorizontalBarQtyData, label: 'Total Qty' }, { data: tempHorizontalBarAmtData, label: 'Total Amount' }];
            this.hBarboolTop5UnisexChartDataApeq = true;
          }

          if (this.orderByTop5GenderwiseData[3] != false) {
            const tempHorizontalBarAmtData = [];
            const tempHorizontalBarQtyData = [];
            this.orderByTop5GenderwiseData[3].forEach(key => {
              this.hBarTop5KidsChartLabels.push(key.article_description);
              tempHorizontalBarQtyData.push(key.total_qty);
              tempHorizontalBarAmtData.push((this.userDetails.franchiseId > 0) ? key.total_price : key.totalsgdvalue);
            });
            this.hBarTop5KidsChartData = [{ data: tempHorizontalBarQtyData, label: 'Total Qty' }, { data: tempHorizontalBarAmtData, label: 'Total Amount' }];
            this.hBarboolTop5KidsChartData = true;
          }
        }
      }, sError => {
        // // console.log('Dashboard Order by Top5 Genderwise Error', sError);
        this.common.apiError(sError);
      }
    );
  }

  public resetCharts() {
    this.barChartLabels = [];
    this.barChartData = [];
  }

  public generatePopUp() {
  //console.log(this.userDetails);
    const onlyActive = 1;
    this.mastersService.getOrderWindowSeasonList(onlyActive).subscribe((data) => {
      console.log('generatePopUp', data);
      if (data.status) {
        this.mastersService.getBrandListByFranchiseId(this.userDetails.franchiseId, 1).subscribe(
          sResponseModel2 => {
            if (sResponseModel2.status) {
              this.brandList = sResponseModel2.data;
               //console.log('getBrandListByFranchiseId', data.data);
              this.orderWindowSeasonList = data.data;
              this.openDialog();
            }
            else {
              this.common.openSnackBar('No Brand Found For Logged In Customer', '', 'danger-snackbar');
              window.localStorage.removeItem('mean-token');
              this.router.navigate(["login"]);
            }
          }, sError => {
            // // console.log('Dashboard Total Order Amount Error', sError);
            this.common.apiError(sError);
          }
        );
      }
      else {
        this.common.openSnackBar('No Order Window Found For Logged In Customer', '', 'danger-snackbar');
        window.localStorage.removeItem('mean-token');
        this.router.navigate(["login"]);
      }
    }, sError => {
      this.common.apiError(sError);
    });
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(DialogOrderWindowComponent, {
      disableClose: true,
      width: '600px',
      data: {
        orderWindowSeasonList: this.orderWindowSeasonList,
        orderWindowIdSelected: this.orderWindowIdSelected,
        brandList: this.brandList,
        brandId: this.brandId,
        isInit: true,
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed', result);
      let filterSelectedData = this.orderWindowSeasonList.filter(item => item.id == result.orderWindowIdSelected);
       console.log('filterSelectedData', filterSelectedData);
      // localStorage.setItem("order-window-id", filterSelectedData[0].id);
      // localStorage.setItem("season-id", filterSelectedData[0].season_id);
      let userDetails = this.common.getUserDetails();
      userDetails.orderWindowId = filterSelectedData[0].id;
      userDetails.seasonId = filterSelectedData[0].season_id;
      userDetails.brandId = parseInt(result.brandId);
      userDetails.seasonName = filterSelectedData[0].season_name;
      userDetails.orderWindowName = filterSelectedData[0].name;
      userDetails.orderWindowType = filterSelectedData[0].ow_type;
      //Object.assign(userDetails,{orderWindowType:filterSelectedData[0].ow_type});
      //console.log('userDetailsggggggg',userDetails);
      
      this.seasonId = filterSelectedData[0].season_id;
      this.orderStatus = 4;
      this.orderWindowId = filterSelectedData[0].id
      this.orderWindowType = filterSelectedData[0].ow_type
      this.common.setUserDetails(userDetails);
      this.common.openSnackBar('Welcome to ASICS Ordering System', '', 'success-snackbar')

      this.seasonId = userDetails.seasonId;
      this.orderWindowId = userDetails.orderWindowId;
      this.brandId = userDetails.brandId;
      this.franchiseId = userDetails.franchiseId;

      this.router.navigateByUrl("/dashboard");
      window.location.reload();

      // this.getTotalOrderAmount();
      // this.getCategory1WiseTotalOrder();
      // this.getOrdersbyFranchiseeType();
      // this.getOrdersbyGender();
      // this.getOrdersbyCountry();
      // this.getOrdersbyTop5MoqArticle();
      // this.getOrdersbyTop5Gender();
      // this.getActivityReport();
      // // console.log('userDetails', userDetails);
      // this.router.navigateByUrl("/orders/store-sales-analysis");

    });

  }

  public onCountryChanged(value) {
    if (value) {
      this.orderSummary = this.cloneOrderSummary.filter(order => { return order.country_name == value });
    }
  }



  onExportClicked(fileType?: any, filterKey?: any, filterValue?: any) {
    this.common.exportAsExcelFileParams(this.seasonId, this.orderWindowId, this.brandId, this.franchiseId, fileType, filterKey, filterValue)
  }

  getStatus(statusCode): string {
    switch (statusCode) {
      case 1: {
        return 'Draft';
      }
      case 2: {
        return 'Cancelled';
      }
      case 3: {
        return 'Pending for review'
      }
      case 4: {
        return 'Approved';
      }
      case 5: {
        return 'Rejected';
      }
    }
  }

  getObject(data, keys) {
    const result = [];
    data.forEach((o) => {
      keys.forEach((key) => {
        if (!o.key) {
          //  o.key =type o.type o.default
        }
      })
    })
  }
}

